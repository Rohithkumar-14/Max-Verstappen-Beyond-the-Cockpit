# Deployment

The project is a static Vite multi-page build. No API keys, database, runtime environment variables or backend are required.

1. Use Node 22.12+ and run `npm ci`.
2. Run `npm run check`, `npm test`, then `npm run build`.
3. Publish the complete `dist/` directory, including `index.html`, `garage.html`, assets, portraits, fonts, images and models.
4. Driver URLs use hashes (`/#/driver/lando-norris`), so static hosts do not need SPA rewrite rules. The garage is `/garage.html`.
5. Test direct profile links, refresh, image paths and garage fallback on the deployed domain.

The existing Sites project identity is retained in `.openai/hosting.json`; it is not an API credential. Use the Sites source workflow to push/package the exact checked commit and deploy its archive. Audience is separate from deployment: an owner-private deployment is not publicly shareable. The master prompt requests public access; confirm the resulting access setting and deployment state before claiming a public release.

For another static host, upload `dist/` or configure build command `npm run build` and output directory `dist`. No secrets are required.

## Release audience — 27 October 2026
Native Sites access update confirmed `access_mode: public` for the existing project. Public target URL: https://f1-beyond-the-cockpit.lemonybirch9.chatgpt.site . The Max-only production build is published through the source workflow; the native deployment result and subsequent browser check determine which source version is live. No localhost or terminal.local address is a public deployment.

Native publication of the Max-only build succeeded on27October2026(version2, source0a537d49bf78da014bd11d78a2c45c60d131909b). The following site read confirmed public audience. Browser control timed out on the hosted-page visit and on its diagnostics; executor HTTP returned403. Public deployment is confirmed by native service, while independent hosted browser/asset verification remains outstanding. The final metadata/documentation synchronization does not change the checked application build.
