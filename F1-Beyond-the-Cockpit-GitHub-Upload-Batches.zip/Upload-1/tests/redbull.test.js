import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import {Box3,DataTexture,DoubleSide,PerspectiveCamera,Raycaster,Vector3} from 'three';
import {loadCar} from '../src/scene/loadCar.js';
import {REDBULL_DESKTOP,REDBULL_MOBILE,selectRedBullAsset,finishRedBullMaterial} from '../src/scene/carAsset.js';
import {attachDashboard,SCREEN_MATERIAL} from '../src/scene/dashboard.js';
import {journeyPose} from '../src/max/cameraPath.js';
import {geometryOnlyGLB} from './helpers/glbGeometry.js';
const evidence=JSON.parse(await readFile(new URL('../docs/evidence/rb22-optimized.json',import.meta.url)));
let car,dashboard;
for(const asset of [REDBULL_DESKTOP,REDBULL_MOBILE])test(`${asset.budget} RB22 retains textures, geometry and licensed provenance`,async()=>{
 const bytes=await readFile(new URL(`../public${asset.url}`,import.meta.url));
 const record=evidence.outputs.find(output=>asset.url.endsWith(output.file));assert.equal(bytes.length,record.bytes);assert.equal(createHash('sha256').update(bytes).digest('hex'),record.sha256);
 const length=bytes.readUInt32LE(12),doc=JSON.parse(bytes.subarray(20,20+length));
 assert.equal(doc.images.length,26);assert.ok(doc.asset.copyright.includes('CC BY 4.0'));
 assert.equal(doc.meshes.flatMap(m=>m.primitives).reduce((sum,p)=>sum+doc.accessors[p.indices].count/3,0),281075);
 assert.ok(record.images.every(image=>image.width<= (asset===REDBULL_MOBILE?1024:2048)&&image.height<= (asset===REDBULL_MOBILE?1024:2048)));
 const original=global.fetch;global.fetch=async()=>new Response(geometryOnlyGLB(bytes),{headers:{'content-type':'model/gltf-binary'}});
 try{const loaded=await loadCar({asset,finishMaterial:finishRedBullMaterial});if(asset===REDBULL_DESKTOP)car=loaded;}finally{global.fetch=original;}
});
test('phone and constrained devices select the smaller texture budget',()=>{
 assert.equal(selectRedBullAsset({width:390}),REDBULL_MOBILE);assert.equal(selectRedBullAsset({width:1400,memory:4}),REDBULL_MOBILE);assert.equal(selectRedBullAsset({width:1400,saveData:true}),REDBULL_MOBILE);assert.equal(selectRedBullAsset({width:1400,memory:8}),REDBULL_DESKTOP);
});
test('Simply Lovely is a panel on the actual LCD, facing the driver, with depth testing',()=>{
 assert.ok(car);car.updateMatrixWorld(true);dashboard=attachDashboard(car,{createTexture:()=>new DataTexture(new Uint8Array([255,255,255,255]),1,1)});car.updateMatrixWorld(true);
 assert.equal(dashboard.screen.material.name,SCREEN_MATERIAL);assert.equal(dashboard.panel.parent,dashboard.screen);
 const centre=dashboard.panel.getWorldPosition(new Vector3());assert.ok(centre.distanceTo(new Vector3(.00018,.6559,.4209))<.005,centre.toArray().join(','));
 assert.equal(dashboard.panel.material.depthTest,true);assert.equal(dashboard.panel.material.toneMapped,false);
 dashboard.setOpacity(1);assert.ok(dashboard.panel.visible);assert.equal(dashboard.panel.material.opacity,1);dashboard.setOpacity(0);assert.equal(dashboard.panel.visible,false);
});
for(const mobile of [false,true])test(`RB22 camera rail clears real surfaces; portrait=${mobile}`,()=>{
 car.traverse(node=>{if(node.material)node.material.side=DoubleSide;});
 const ray=new Raycaster();let previous=new Vector3(...journeyPose(0,mobile).position);
 for(let i=1;i<=1000;i++){
  const next=new Vector3(...journeyPose(i/1000,mobile).position),direction=next.clone().sub(previous),length=direction.length();
  if(length>1e-8){ray.set(previous,direction.normalize());ray.near=0;ray.far=length+.0001;const hits=ray.intersectObject(car,true);assert.equal(hits.length,0,`camera collision at ${i/1000}: ${hits[0]?.object.material.name}`);}
  previous=next;
 }
});
test('cockpit sightline hits the LCD panel; text is upright and fits phone view',()=>{
 dashboard.setOpacity(1);car.updateMatrixWorld(true);
 for(const [width,height] of [[1440,900],[390,844],[320,740],[320,844],[360,900],[844,390]]){
  const pose=journeyPose(.66,width/height<.9,width/height),camera=new PerspectiveCamera(38,width/height,.1,60);camera.position.fromArray(pose.position);camera.lookAt(new Vector3(...pose.target));camera.updateMatrixWorld(true);
  const ray=new Raycaster(camera.position,new Vector3(...pose.target).sub(camera.position).normalize(),.1,2),hits=ray.intersectObject(car,true);
  assert.equal(hits[0]?.object.name,'dashboard-simply-lovely',`${width} cockpit blocked by ${hits[0]?.object.material.name}`);
  const positions=dashboard.panel.geometry.attributes.position;for(let i=0;i<positions.count;i++){const point=new Vector3().fromBufferAttribute(positions,i).applyMatrix4(dashboard.panel.matrixWorld).project(camera);assert.ok(Math.abs(point.x)<1&&Math.abs(point.y)<1,`${width} clips dashboard text`);}
  const centre=dashboard.panel.getWorldPosition(new Vector3()),up=dashboard.panel.localToWorld(new Vector3(0,.01,0)).project(camera),right=dashboard.panel.localToWorld(new Vector3(.01,0,0)).project(camera),middle=centre.project(camera);assert.ok(up.y>middle.y&&right.x>middle.x,'Dashboard text orientation');
 }
 dashboard.setOpacity(0);
});
test('RB22 endpoint contains the complete car on desktop and phone',()=>{
 const bounds=new Box3().setFromObject(car);
 for(const [width,height] of [[1440,900],[390,844],[320,740],[320,844],[360,900],[844,390],[768,1024]]){
  const pose=journeyPose(1,width/height<.9,width/height),camera=new PerspectiveCamera(38,width/height,.1,60);camera.position.fromArray(pose.position);camera.lookAt(new Vector3(...pose.target));camera.updateMatrixWorld(true);
  for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]){const point=new Vector3(x,y,z).project(camera);assert.ok(Math.abs(point.x)<1&&Math.abs(point.y)<1,`${width}x${height} clips RB22`);}
 }
});
test('phone drawing areas retain complete reveal with margins after HUD space is reserved',()=>{
 const bounds=new Box3().setFromObject(car);
 for(const [width,height] of [[320,740],[390,844],[430,932],[768,1024]]){
  const drawingHeight=width<=650?height-246:height,aspect=width/drawingHeight;
  const pose=journeyPose(1,aspect<.9,aspect),camera=new PerspectiveCamera(38,aspect,.1,60);camera.position.fromArray(pose.position);camera.lookAt(new Vector3(...pose.target));camera.updateMatrixWorld(true);
  for(const x of [bounds.min.x,bounds.max.x])for(const y of [bounds.min.y,bounds.max.y])for(const z of [bounds.min.z,bounds.max.z]){const point=new Vector3(x,y,z).project(camera);assert.ok(Math.abs(point.x)<.85&&Math.abs(point.y)<.85,`${width} reveal needs clear margins`);}
 }
});
