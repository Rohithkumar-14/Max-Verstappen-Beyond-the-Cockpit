# F1 — Beyond the Cockpit

A Max Verstappen fan website with a scroll-driven 3D Red Bull RB22 introduction, career milestones and a season-by-season results explorer.

Built with **Vite, vanilla JavaScript, Three.js and GSAP ScrollTrigger**. No backend, API keys or paid services are required to run the included source.

Published website: https://f1-beyond-the-cockpit.rohithkumar140607.chatgpt.site

## Included features

- Textured RB22 model, reversible camera journey and “SIMPLY LOVELY” on the actual steering-wheel display.
- Responsive mobile framing, skip control, reduced-motion mode and static WebGL fallback.
- Helmeted cinematic reveal followed by a separate, proportionally framed white-suit photograph.
- Five photographic milestones (2015, 2016, 2021, 2023, 2024), with a section-contained sticky lion and four gently glittering stars.
- Layered Red Bull garage wall sign, local Michroma/Space Grotesk typography and retained display font.
- 2015–2026 season selector, championship indicators, summary statistics, expandable race results and filters.
- Preserved secondary driver archive and garage study.

## Requirements

- **Node.js 22.12.0 or newer** and its bundled npm. Use a current supported Node version satisfying this minimum.
- Internet access for the initial dependency installation. Application assets and statistics are bundled locally.
- A modern browser; the cinematic 3D scene needs WebGL2. Content remains usable when WebGL is unavailable.

Check the installation with `node --version` and `npm --version`.

## Run locally on Windows

1. Extract the entire ZIP into a new folder. Do not merge it into an older project.
2. Open PowerShell or Command Prompt in the extracted folder containing `package.json`.
3. Run:

```powershell
npm.cmd ci
npm.cmd run dev
```

Open the localhost URL printed by Vite. Keep the terminal running; press **Ctrl+C** to stop the server. Use `npm.cmd` in PowerShell to avoid execution-policy issues with `npm.ps1`.

Do not open `index.html` by double-clicking it: the JavaScript modules require the Vite server.

On macOS/Linux, the equivalent commands are `npm ci` and `npm run dev`.

## Checks and production build

```powershell
npm.cmd run check
npm.cmd test
npm.cmd run build
```

- `check`: JavaScript syntax checks, not ESLint or TypeScript.
- `test`: Node test suite, including source import analysis, data, camera geometry, assets, dashboard and garage sign checks.
- `build`: generates the production website in `dist/`.

To inspect a production build locally:

```powershell
npx.cmd vite preview --host 127.0.0.1
```

Open the URL it prints. Development QA pages are intentionally excluded from production output.

## Pages and diagnostic routes

| Route | Purpose |
| --- | --- |
| `/` | Main Max Verstappen experience |
| `/explorer.html` | Preserved secondary driver archive |
| `/garage.html` | Earlier garage study |
| `/qa/car-review.html` | Development-only actual WebGL camera review; requires WebGL2 |
| `/qa/asset-review.html` | Asset decoding checks, separate from GPU visual verification |
| `/qa/responsive.html` | Same-origin viewport layout harness |
| `/qa/max-motion.html` | DOM-only shared animation controller checks |
| `/?static=1` | Force static experience |
| `/?reduce=1` | Exercise reduced-motion application branch |

## Upload the source to GitHub

Upload the **extracted project files**, rather than only the ZIP, so GitHub can display and track the source.

### Recommended: Git

Install Git from its official distribution, create an empty repository on GitHub, and leave its automatic README/licence/.gitignore options unchecked. This project already contains a README and .gitignore.

Open a terminal in the extracted project root and run:

```powershell
git init
git add .
git commit -m "Add approved F1 Beyond the Cockpit website"
git branch -M main
git remote add origin https://github.com/Rohithkumar-14/YOUR-REPOSITORY.git
git push -u origin main
```

Replace `YOUR-REPOSITORY` with the repository name you created. Authenticate using GitHub's supported sign-in flow; do not put a password or token inside the remote URL. Git may ask you to configure your commit name/email before the commit. Use the identity you want shown on GitHub, including its private noreply email option if preferred.

The supplied model files fit GitHub's standard individual-file limits; Git LFS is not required for these files.

### Alternative: GitHub website

Create an empty repository, choose **uploading an existing file** (or **Add file → Upload files**), and drag in the extracted contents. Keep folders intact and put `package.json` at the repository root, not inside another project folder. Browser upload has file-count and per-file limits; use multiple batches or Git if an upload is rejected. Ensure `.gitignore` is included; hidden files can be easy to miss when dragging folders.

Do not upload `node_modules/`, `dist/`, credentials, caches or the ZIP itself as a substitute for the extracted source. The archive excludes these items and the original Sites hosting identity.

## Host the website

A GitHub repository stores source code; uploading it does not automatically publish the website.

For an origin-root static host, use:

- Install command: `npm ci`
- Build command: `npm run build`
- Publish/output directory: `dist`

Upload the complete build output, including the local models, images and fonts. No runtime environment variables are required. GitHub Pages under `/repository-name/` needs additional base-path and root-relative asset-path configuration; this source currently targets an origin root. Do not assume merely enabling Pages will serve this Vite source correctly.

## Source layout

```text
index.html          Main experience
explorer.html       Secondary driver archive
garage.html         Earlier garage study
src/max/            Main content, camera and animation
src/scene/          Renderer, model loader, dashboard and environment
src/data/           Bundled statistics and season data
src/app/            Preserved archive interface
public/             Locally bundled models, photographs, logos and fonts
qa/                 Development review routes
tests/              Automated test suite
scripts/            Syntax checks and optional data/asset preparation
docs/               Credits, source evidence, implementation and QA history
```

## Data and championships

The season explorer contains a **dated snapshot verified on 31 October 2026**, not a live results feed. The 2026 season is incomplete. Selected-season championship stars use the verified history in the dataset. The four decorative stars above the achievements lion describe the overall career chapter, not a title count for each milestone year.

Season statistics distinguish race starts from entries and Grand Prix points from weekend points including Sprints. See [data sources](docs/DATA_SOURCES.md) and the bundled evidence before changing totals. Biography/career headline totals retain their separately labelled 26 October snapshot; they are not automatically refreshed by season selection.

Python refresh and model-preparation scripts are optional maintenance tools, not prerequisites for running the site. Their external inputs/tooling are described in [the technical guide](docs/TECHNICAL_GUIDE.md). Review refreshed data manually and rerun tests before publication.

## Credits and rights

This is an independent fan project; no official affiliation or endorsement is implied. **There is no blanket licence covering all project assets.** Retain asset-specific attribution, licence notices and visible credits when sharing the source.

- RB22 model: Dave Love SketchFab (@Tyler_Dave), CC BY 4.0; local optimised adaptations and source details are recorded in [the asset register](docs/ASSET_REGISTER.md).
- Archived podium portrait: Steffen Prößdorf, crop by Bagumba, CC BY-SA 4.0; see [portrait credits](docs/PORTRAIT_CREDITS.md).
- Michroma, Space Grotesk and Barlow: SIL Open Font License notices are bundled. Michroma is a radio-inspired alternative, **not the official F1 font**.
- User-supplied photographs, lion and Oracle Red Bull Racing logo: original usage/redistribution rights remain unverified. User supply does not establish an open licence; visible watermarks and rights disclosures are retained. Review the documented rights before further redistribution or commercial use.
- Earlier models and the generated concept background have separate provenance records. Dependency licences remain with the installed packages.

See `docs/licenses/`, `public/fonts/*OFL.txt` and the asset register for exact sources and adaptation notices.

## Validation and known limits

The approved review version passed 50 automated tests, syntax checks and the production build. Desktop, narrow-phone and phone-landscape layouts were checked in the cloud browser, including the sticky lion/stars, distinct portraits and season filtering. See [the test log](docs/TEST_LOG.md) for historical evidence and the final clean-archive validation entry.

**GPU visuals remain unverified in this environment:** the available browser cannot create WebGL2. Geometry, material, asset-decoding and DOM animation tests do not certify the rendered garage wall, cinematic shots, dashboard readability or real-phone performance. Inspect `/qa/car-review.html` on capable hardware before making those claims. Windows commands are documented; validation in this environment runs on Linux.

Further implementation details and preserved historical notes: [Technical guide](docs/TECHNICAL_GUIDE.md).
