import { Box3, Group, Vector3 } from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';

export const CAR_ASSET = Object.freeze({
  url: '/models/ground-effect-racer.glb', quality: 'placeholder', license: 'CC0-1.0',
  source: 'https://3dassets.dev/assets/grand-prix-circuit-and-open-wheel-ground-effect-racer-02c3b491',
});

export function disposeObject(root) {
  const geometries = new Set();
  const materials = new Set();
  const textures = new Set();
  root.traverse((node) => {
    if (node.geometry) geometries.add(node.geometry);
    for (const material of [node.material].flat().filter(Boolean)) {
      materials.add(material);
      for (const value of Object.values(material)) if (value?.isTexture) textures.add(value);
    }
  });
  textures.forEach((texture) => texture.dispose());
  materials.forEach((material) => material.dispose());
  geometries.forEach((geometry) => geometry.dispose());
  root.removeFromParent();
}

export async function loadCar({ signal, onProgress, simulateFailure = false, asset = CAR_ASSET, finishMaterial }) {
  if (simulateFailure) throw new Error('Model failure deliberately injected for QA.');
  const response = await fetch(asset.url, { signal });
  if (!response.ok) throw new Error(`Car download failed: HTTP ${response.status}.`);
  if (response.headers.get('content-type')?.includes('text/html')) throw new Error('Car URL returned HTML instead of a GLB.');
  const total = Number(response.headers.get('content-length')) || null;
  let buffer;
  if (response.body?.getReader) {
    const reader = response.body.getReader();
    const chunks = [];
    let loaded = 0;
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value); loaded += value.length;
      onProgress?.(loaded, total);
    }
    const bytes = new Uint8Array(loaded);
    let offset = 0;
    for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.length; }
    buffer = bytes.buffer;
  } else { buffer = await response.arrayBuffer(); }
  signal?.throwIfAborted();
  const gltf = await new GLTFLoader().parseAsync(buffer, '/models/');
  if (signal?.aborted) { disposeObject(gltf.scene); signal.throwIfAborted(); }
  const bounds = new Box3().setFromObject(gltf.scene);
  const size = bounds.getSize(new Vector3());
  if (!Number.isFinite(size.z) || size.z <= 0) {
    disposeObject(gltf.scene); throw new Error('Car model has invalid geometry bounds.');
  }
  // Normalize length to 5.4 scene units. The supplied asset points nose +Z.
  const root = new Group();
  root.name = asset.name ?? 'shared-neutral-car';
  const center = bounds.getCenter(new Vector3());
  gltf.scene.position.sub(new Vector3(center.x, bounds.min.y, center.z));
  root.add(gltf.scene); root.scale.setScalar(5.4 / size.z);
  root.traverse((node) => {
    if (!node.isMesh) return;
    node.castShadow = false; node.receiveShadow = false;
    for (const material of [node.material].flat().filter(Boolean)) {
      if (finishMaterial) { finishMaterial(material); continue; }
      if (material.name === 'paint') {
        material.color.set('#626d76'); material.metalness = 0.72; material.roughness = 0.3;
      }
      if (material.name === 'accent') material.color.set('#8a9aa6');
      material.envMapIntensity = 1.1;
    }
  });
  console.info('[Garage] Car GLB loaded.', { bytes: buffer.byteLength, size: size.toArray(), quality: asset.quality });
  return root;
}
