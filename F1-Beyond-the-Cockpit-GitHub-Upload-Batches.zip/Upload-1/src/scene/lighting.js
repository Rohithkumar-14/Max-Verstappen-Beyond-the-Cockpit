import { AmbientLight, DirectionalLight, HemisphereLight, Mesh, MeshBasicMaterial, BoxGeometry } from 'three';

export function addLighting(scene) {
  scene.add(new AmbientLight('#9bb9d1', 0.22));
  scene.add(new HemisphereLight('#d4e7fa', '#0a0e16', 0.7));
  const key = new DirectionalLight('#e2efff', 3.0);
  key.position.set(-3, 6, -1); scene.add(key);
  const fill = new DirectionalLight('#8ba3cc', 1.15);
  fill.position.set(5, 2.5, -4); scene.add(fill);
  const rim = new DirectionalLight('#79e6f9', 3.8);
  rim.position.set(1, 3, 4); scene.add(rim);
  const violet = new DirectionalLight('#8983c6', 0.6);
  violet.position.set(-5, 1.5, 2); scene.add(violet);
  // Architectural strips, no bloom or realtime shadows.
  for (const x of [-3.6, 3.6]) {
    const strip = new Mesh(new BoxGeometry(0.025, 0.018, 14), new MeshBasicMaterial({ color: '#40758a' }));
    strip.position.set(x, 0.008, 0); scene.add(strip);
  }
  for (const x of [-4.7, 4.7]) {
    const strip = new Mesh(new BoxGeometry(0.025, 3.1, 0.025), new MeshBasicMaterial({ color: '#2a5366' }));
    strip.position.set(x, 1.55, 6.6); scene.add(strip);
  }
}
