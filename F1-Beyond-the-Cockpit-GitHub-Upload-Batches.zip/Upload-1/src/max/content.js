import {getSeason,championshipLabel,seasonSummary,seasonOptions} from './seasons.js';
import drivers from '../data/drivers.json' with {type:'json'};
import { escapeHTML as e } from '../app/domain.js';
export const max = drivers.find(driver=>driver.id==='max-verstappen');
export const maxPortrait = {src:'/portraits/max-white-suit.webp',alt:'Max Verstappen in a white racing suit standing on a white Red Bull car'};
let selectedYear=2026;
export const milestones = [
 {year:'2015',title:'A new generation.',detail:'A Formula 1 debut with Toro Rosso at just 17 years old.',image:{src:'/images/milestones/max-2015.webp',width:1600,height:1065,alt:'Max Verstappen driving the Toro Rosso in his debut Formula 1 season',caption:'2015 / THE FIRST CHAPTER · PHOTO: JAMEY PRICE (WATERMARK)'}},
 {year:'2016',title:'An immediate statement.',detail:'Victory at the Spanish Grand Prix on his first race weekend with Red Bull Racing.',image:{src:'/images/milestones/max-2016.webp',width:452,height:678,alt:'Max Verstappen lifting the trophy on the 2016 Spanish Grand Prix podium',caption:'2016 / THE FIRST VICTORY',portrait:true}},
 {year:'2021',title:'World champion.',detail:'The first Drivers’ Championship, beginning a run of four consecutive titles.',image:{src:'/images/milestones/max-2021.webp',width:1400,height:998,alt:'Max Verstappen kneeling beside his Red Bull after the 2021 Abu Dhabi Grand Prix',caption:'2021 / THE FIRST WORLD TITLE'}},
 {year:'2023',title:'Nineteen victories.',detail:'A record-setting season with 19 Grand Prix wins.',image:{src:'/images/milestones/max-2023.webp',width:1400,height:788,alt:'Max Verstappen celebrating on his Red Bull at Abu Dhabi in 2023',caption:'2023 / A SEASON FOR THE RECORDS'}},
 {year:'2024',title:'Four in succession.',detail:'A fourth consecutive Drivers’ World Championship, completing the 2021–2024 run.',image:{src:'/images/milestones/max-2024.webp',width:1400,height:933,alt:'Max Verstappen beside the World Champion 2024 sign in Las Vegas',caption:'2024 / FOUR IN SUCCESSION'}},
];
export function selectResults(rows,filter){return rows.filter(row=>filter==='all'||filter==='win'&&row.position==='1'||filter==='podium'&&['1','2','3'].includes(row.position)||filter==='dnf'&&row.position==='DNF');}
function stat(label,value,animated=false){return `<div class="stat"><strong aria-label="${e(`${value} ${label}`)}"><span aria-hidden="true" ${animated?`data-counter="${value}"`:''}>${value}</span></strong><span class="label">${label}</span></div>`;}
export function populateContent({simulatePortraitFailure=false}={}){
 document.querySelector('#biography').textContent=max.bio;
 document.querySelector('#career-stats').innerHTML=[['World championships',max.career.championships],['Grand Prix victories',max.career.wins],['Podiums',max.career.podiums],['Pole positions',max.career.poles]].map(([label,value])=>stat(label,value,true)).join('');
 document.querySelector('#season-stats').innerHTML=[['Championship position',max.season.position],['Total points',max.season.points],['Grand Prix wins',max.season.wins],['Podiums',max.season.podiums],['Pole positions',max.season.poles],['Grand Prix races',max.season.races]].map(([label,value])=>stat(label,value)).join('');
 document.querySelector('#career-timeline').innerHTML=milestones.map(item=>`<article class="timeline-item"><span class="timeline-year">${item.year}</span><div><h3>${e(item.title)}</h3><p>${e(item.detail)}</p>${item.image?`<figure class="milestone-photo${item.image.portrait?' milestone-photo-portrait':''}"><div class="milestone-image-mask"><img src="${item.image.src}" alt="${e(item.image.alt)}" width="${item.image.width}" height="${item.image.height}" loading="lazy" decoding="async"></div><figcaption>${e(item.image.caption)}</figcaption></figure>`:''}</div></article>`).join('');
 document.querySelectorAll('.milestone-photo img').forEach(image=>{image.addEventListener('error',()=>{image.closest('figure').hidden=true;},{once:true});});
 const p=maxPortrait;
 document.querySelector('#max-portrait').innerHTML=`<div class="portrait-pending" role="img" aria-label="Max Verstappen portrait unavailable"><strong aria-hidden="true">MV</strong><span>AUTHENTIC PORTRAIT<br>UNAVAILABLE</span></div>${p?.src?`<img src="${simulatePortraitFailure?'/portraits/missing-qa.webp':e(p.src)}" alt="${e(p.alt)}" width="736" height="1308" loading="lazy" decoding="async">`:''}`;
 const credit='White-suit Max photograph supplied by the site owner; proportionally WebP compressed without changing the composition. Photographer, event date and original usage licence were not supplied or independently verified.';
 document.querySelector('#portrait-credit').innerHTML=credit;
 const img=document.querySelector('#max-portrait img');
 if(img){const loaded=()=>{img.previousElementSibling.hidden=true;};img.addEventListener('load',loaded,{once:true});img.addEventListener('error',()=>{img.hidden=true;img.previousElementSibling.hidden=false;},{once:true});if(img.complete&&img.naturalWidth)loaded();}
 document.querySelector('#stats-source').href=max.sourceUrl;
 document.querySelector('#results-source').href=max.resultsUrl;
 document.querySelector('#credit-content').innerHTML=`<p>Driver, team, race number, biography, career milestones and statistics: <a href="${max.sourceUrl}" target="_blank" rel="noopener">Formula 1’s Max Verstappen profile</a>. Results: <a href="${max.resultsUrl}" target="_blank" rel="noopener">official 2026 result table</a>. Retrieved 26 October 2026. No live updates are implied.</p><p>${credit}</p><p>The helmeted photograph appears only in the cinematic reveal. Supplied by the site owner; resized and compressed. Its original photographer, date and usage licence were not supplied or independently verified.</p><p>Season archive: official Formula 1 driver results and championship standings, with Jolpica structured race records for starts, Grand Prix points and grid-based pole counts. Verified 31 October 2026. Per-season source links appear in On the Record. Historical summaries reconcile to the official career totals.</p><p>3D model: <a href="https://sketchfab.com/3d-models/2026-redbull-rb22-0a3d24a58e0549d591a5a48c22eec383" target="_blank" rel="noopener">“2026 Redbull RB22” by Dave Love SketchFab (@Tyler_Dave)</a>, <a href="https://creativecommons.org/licenses/by/4.0/" target="_blank" rel="noopener">CC BY 4.0</a>. Supplied by the site owner. Adapted with optimized textures, quantized normals, material tuning and a custom steering-wheel display. Creator preview used as the static fallback. A third-party model, not an official Red Bull asset or an independently verified engineering representation. Historical generic models remain in the source archive. Fonts: Barlow Condensed, Michroma and Space Grotesk; local SIL OFL 1.1 licence files retained. Michroma is a radio-inspired alternative, not the official F1 font. Garage wall logo supplied by the site owner; original usage rights unverified, no endorsement implied.</p><p>2015, 2016, 2021, 2023 and 2024 milestone photographs and orange lion logo supplied by the site owner; resized and compressed for display. Original photographer credits and licences were not supplied or independently verified.</p>`;
 const selector=document.querySelector('#season-selector');
 if(selector){selector.innerHTML=seasonOptions();selector.value=String(selectedYear);renderSeason(selectedYear);}
 else renderResults('all');
}
export function renderSeason(year){
 const season=getSeason(year);if(!season)return;selectedYear=season.year;
 document.querySelector('#selected-season-title').textContent=`${selectedYear} SEASON`;
 document.querySelector('#selected-season-team').textContent=season.teams.join(' / ');
 document.querySelector('#selected-season-stats').innerHTML=seasonSummary(season).map(([label,value])=>stat(label,value??'—')).join('');
 const label=championshipLabel(season);
 document.querySelector('#championship-badge').innerHTML=`<img src="/images/max-lion.webp" width="80" height="80" alt=""><div><span class="championship-stars" aria-hidden="true">${'★'.repeat(season.championships)}</span><span class="championship-label">${e(label)}</span></div>`;
 document.querySelector('#season-context').textContent=`${season.complete?'Completed season':'Ongoing season snapshot'} · Verified ${season.verifiedAt}. ${season.notes.join(' ')}`;
 document.querySelector('#results-source').href=season.sourceUrl;
 document.querySelector('#season-standings-source').href=season.standingsUrl;
 document.querySelector('#season-method-source').href=season.structuredSourceUrl;
 document.querySelector('.results-table caption').textContent=`Max Verstappen ${selectedYear} race results`;
 const filter=document.querySelector('#result-filter');filter.value='all';renderResults('all');
 const panel=document.querySelector('#season-panel');
 if(panel.animate&&!matchMedia('(prefers-reduced-motion: reduce)').matches&&!document.body.classList.contains('static-mode')){panel.getAnimations().forEach(animation=>animation.cancel());panel.animate([{opacity:.45,transform:'translateY(6px)'},{opacity:1,transform:'translateY(0)'}],{duration:320,easing:'ease-out'});}
}
export function renderResults(filter){
 const season=getSeason(selectedYear);const all=season?.raceResults??max.raceResults;const rows=selectResults(all,filter);
 document.querySelector('#result-count').textContent=`${selectedYear} / ${rows.length} OF ${all.length} PUBLISHED RESULTS`;
 document.querySelector('#result-rows').innerHTML=rows.length?rows.map(row=>`<tr><th scope="row">${e(row.grandPrix)}<span class="result-team">${e(row.team??'')}</span></th><td>${e(row.date)}</td><td ${row.position==='1'?'class="win"':''}>${e(row.position)}${row.started===false?'<span class="result-team">Did not start</span>':''}</td><td>${row.racePoints??'—'}</td><td>${row.points??'—'}</td></tr>`).join(''):'<tr><td colspan="5">No published results match this filter.</td></tr>';
}
