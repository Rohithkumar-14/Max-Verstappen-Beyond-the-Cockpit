import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync,existsSync} from 'node:fs';
import {resolveRoute,filterDrivers,neighbors,metric,escapeHTML} from '../src/app/domain.js';
const drivers=JSON.parse(readFileSync(new URL('../src/data/drivers.json',import.meta.url)));
test('22 unique verified drivers across 11 paired teams, each with a source and valid route',()=>{
 assert.equal(drivers.length,22);assert.equal(new Set(drivers.map(d=>d.id)).size,22);assert.equal(new Set(drivers.map(d=>d.number)).size,22);
 const teams=new Set(drivers.map(d=>d.team));assert.equal(teams.size,11);
 for(const team of teams)assert.equal(drivers.filter(d=>d.team===team).length,2);
 for(const d of drivers){assert.equal(resolveRoute(`#/driver/${d.id}`,drivers).driver,d);assert.match(d.sourceUrl,/^https:\/\/www.formula1.com\/en\/drivers\//);assert.equal(d.season.year,2026);assert.equal(d.verifiedAt,'2026-10-26');}
 assert.equal(drivers.find(d=>d.id==='lando-norris').number,1);assert.equal(drivers.find(d=>d.id==='max-verstappen').number,3);
});
test('previous/next driver round trips and wraps at either end',()=>{for(const d of drivers){const n=neighbors(drivers,d.id);assert.equal(neighbors(drivers,n.next.id).previous.id,d.id);assert.equal(neighbors(drivers,n.previous.id).next.id,d.id);}});
test('search handles names, numbers, teams, no results and team combinations',()=>{assert.equal(filterDrivers(drivers,'hamilton')[0].id,'lewis-hamilton');assert.equal(filterDrivers(drivers,'44')[0].id,'lewis-hamilton');assert.equal(filterDrivers(drivers,'','Ferrari').length,2);assert.equal(filterDrivers(drivers,'Norris','Ferrari').length,0);assert.equal(filterDrivers(drivers,'missing').length,0);});
test('invalid routes are safe, unknown stats differ from zero and HTML is escaped',()=>{assert.equal(resolveRoute('#/driver/unknown',drivers).page,'missing');assert.equal(resolveRoute('#/',drivers).page,'home');assert.equal(metric(null),'—');assert.equal(metric(0),'0');assert.equal(escapeHTML('<img onerror="x">'),'&lt;img onerror=&quot;x&quot;&gt;');});
test('every integrated portrait has a local file and attribution metadata',()=>{const portraits=JSON.parse(readFileSync(new URL('../src/data/portraits.json',import.meta.url)));for(const d of drivers){const p=portraits[d.id];if(!p?.src)continue;assert.ok(existsSync(`public${p.src}`),d.id);assert.ok(p.author&&p.license&&p.sourceUrl&&p.licenseUrl,d.id);}});
test('race rows retain source URLs, valid values and explicit discrepancy notes',()=>{let count=0;for(const d of drivers){assert.match(d.resultsUrl,/^https:\/\/www.formula1.com\/en\/results\/2026\/drivers\//);assert.ok(Array.isArray(d.sourceNotes));for(const r of d.raceResults){assert.ok(r.grandPrix&&r.date&&r.team&&r.position);assert.equal(typeof r.points,'number');assert.ok(r.points>=0);count++;}}assert.equal(count,383);assert.ok(drivers.find(d=>d.id==='arvid-lindblad').sourceNotes.length);});
