# Future seated 3D driver system — planned, not implemented

## Shared representation
One reusable, appropriately licensed driver body with a seated race-car pose, helmet, suit, boots and gloves may be used as a generic occupant. It must never be described as a particular person's scanned body or likeness. No face generation or random facial likeness is planned. Driver-specific helmet/suit textures and any team marks require their own rights.

## Proposed loading boundary
A future loadDriverRepresentation({ carRoot, seatAnchor, assets, signal, budget }) module returns either a 3D root with a dispose() function or a portrait representation and a reason. Metadata includes source URL, creator, license, portrait attribution, and whether the representation is generic or an authorized likeness. This is an interface proposal, not shipped API functionality.

## Fit requirements
The car must provide or have manually calibrated seat, pelvis, head and steering-wheel anchors. Fit the driver locally under the car root, not in unrelated world coordinates. Check pelvis in seat, reclined torso, helmet below/behind halo, legs inside the footwell, and gloved hands on the steering wheel. The current asset's cockpit and occupant-like white geometry are too simplified for this work. Its named wheel pivots do not establish a usable seat anchor. Do not infer driver fit from the exterior bounding box.

A pre-posed static driver is simpler than live IK/physics. A rig may be used to author the pose offline and then baked. No facial animation or full-body motion system is required.

## Fallback behavior
Use the high-quality, correctly identified and licensed portrait from driver data if the driver asset is absent, times out, fails validation, has unverified permissions, cannot fit the cockpit, or exceeds a measured device budget. Do not start a 3D driver load on a known low-performance device by default; begin with the portrait. A real-time performance threshold must be chosen after testing, not invented now.

A portrait is an HTML image outside the canvas, with alt text, attribution and a neutral missing-image treatment. Failed image loading falls back to text identity; it does not break navigation. No portrait or driver body is acquired or integrated in Phase 1.

## Exact next implementation sequence
1. Replace the car placeholder with a licensed high-detail neutral GLB; pass static visual and performance checks on desktop and phone.
2. Record seat/head/steering anchors and confirm cockpit clearance from proposed camera views.
3. Append side and cockpit camera keyframes to the existing shared timeline, keeping camera and look-at targets synchronized; test forward and reverse.
4. Clear a suitable seated driver asset and portrait rights in ASSET_REGISTER.md.
5. Implement the reusable representation loader, align the driver to the seat anchors, and test mesh intersections, visibility, cost and disposal.
6. Add the reveal and portrait fallback tests. Only then connect verified driver identity data; do not build all 22 profiles as part of this asset test.
