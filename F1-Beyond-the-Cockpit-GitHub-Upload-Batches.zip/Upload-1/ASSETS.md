# Asset requirements and sourcing

## Priority assets
1. One realistic F1-style car model with a license permitting intended use.
2. Clean model with camera access to rear, side, cockpit, and full-car angles.
3. Optional separate meshes for wheels, wings, suspension, cockpit, and bodywork.
4. Driver portraits or a rigged driver model only if rights and quality are suitable.
5. Garage environment or a simple custom-built environment.
6. Team logos, liveries, and sponsor marks only when usage rights permit them.

## Formats and checks
- Preferred model format: `.glb` / `.gltf`.
- Keep polygon count and texture sizes reasonable for browsers.
- Verify origin, scale, orientation, materials, separate meshes, and license.
- Test the model in a minimal Three.js scene before designing the camera path around it.

## Realism rule
Do not label a generic or older model as an accurate 2026 team car. Use “F1-inspired” until the model and livery are verified.

## Asset record
For each asset, record file name, format, creator/source URL, license, required attribution, allowed use, file size, limitations, and fallback.

## Fallback
If no suitable model exists, use matched licensed renders to prototype a 2.5D journey. Document that the camera cannot reveal unseen angles.
