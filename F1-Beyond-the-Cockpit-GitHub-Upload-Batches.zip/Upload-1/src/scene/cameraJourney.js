import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { CAMERA_PATH, cameraLayout } from './cameraConfig.js';

gsap.registerPlugin(ScrollTrigger);

export function createCameraJourney({ section, stage, onProgress }) {
  const travel = { progress: 0 };
  let timeline;
  const context = gsap.context(() => {
    timeline = gsap.timeline({
      scrollTrigger: {
        trigger: section, pin: stage, start: 'top top',
        end: () => `+=${CAMERA_PATH[cameraLayout(stage.clientWidth)].scrollDistance}`,
        scrub: 0.45, anticipatePin: 1, invalidateOnRefresh: true,
      },
    });
    timeline.to(travel, { progress: 1, duration: 1, ease: 'sine.inOut', onUpdate: () => onProgress(travel.progress) });
  }, section);
  return { dispose() { context.revert(); } };
}
