import {createScene} from '/src/scene/createScene.js';
import {loadCar} from '/src/scene/loadCar.js';
import {selectRedBullAsset,finishRedBullMaterial} from '/src/scene/carAsset.js';
import {attachDashboard} from '/src/scene/dashboard.js';
import {cinematicState} from '/src/max/cinematicSequence.js';
import {journeyPose} from '/src/max/cameraPath.js';
let scene;
const output=document.getElementById('status');
const progress=document.getElementById('progress');
function setPose(p){scene.setProgress(p);scene.setDashboardCue(cinematicState(p*.82).cockpitCueOpacity);progress.value=p;output.textContent=`Renderer initialized. Inspect the actual car visually. Camera progress ${p}; position ${scene.camera.position.toArray().map(v=>v.toFixed(3)).join(',')}. Not automatically visually verified.`;}
try{
 scene=createScene(document.getElementById('viewport'),{poseProvider:journeyPose,fitWholeCar:false,brandedGarage:true});
 const car=await loadCar({asset:selectRedBullAsset({width:innerWidth,memory:navigator.deviceMemory??8,saveData:new URLSearchParams(location.search).get('budget')==='mobile'}),finishMaterial:finishRedBullMaterial});scene.setCar(car,{dashboard:attachDashboard(car)});setPose(0);
 document.querySelectorAll('#views button').forEach(button=>{button.disabled=false;button.addEventListener('click',()=>setPose(Number(button.dataset.p)));});progress.disabled=false;progress.addEventListener('input',()=>setPose(Number(progress.value)));
}catch(error){scene?.dispose();output.textContent=`RENDERING BLOCKED: ${error.message} No stage has been visually verified. Use a WebGL2-capable browser to capture opening, bodywork, cockpit and full car.`;}
window.addEventListener('pagehide',()=>scene?.dispose());
