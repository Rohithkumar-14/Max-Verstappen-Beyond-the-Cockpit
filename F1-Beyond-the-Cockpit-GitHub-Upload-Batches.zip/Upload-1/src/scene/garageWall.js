import {BoxGeometry,Group,Mesh,MeshBasicMaterial,MeshStandardMaterial,PlaneGeometry} from 'three';
export const WALL_LOGO_URL='/images/oracle-redbull-racing.webp';
export const WALL_LOGO_ASPECT=1000/474;
// All dimensions are world units. The car remains in z [-2.7, 2.7].
// This architecture sits on the +Z garage wall, facing the rear camera (-Z).
export function createGarageWall(){
 const group=new Group();group.name='redbull-garage-architecture';group.position.x=-2.2;
 const wallMaterial=new MeshStandardMaterial({color:'#101927',roughness:.82,metalness:.2});
 const panelMaterial=new MeshStandardMaterial({color:'#090f19',roughness:.48,metalness:.5});
 const frameMaterial=new MeshStandardMaterial({color:'#364352',roughness:.35,metalness:.75});
 const blueMaterial=new MeshBasicMaterial({color:'#315b93',toneMapped:false});
 const redMaterial=new MeshBasicMaterial({color:'#8f2537',toneMapped:false});
 const box=(name,size,position,material)=>{const mesh=new Mesh(new BoxGeometry(...size),material);mesh.name=name;mesh.position.set(...position);group.add(mesh);return mesh;};
 box('garage-wall',[18,6,.12],[0,3,7.25],wallMaterial);
 // Layered recess, backing plate and floating sign face, with visible air gaps.
 box('recess-surround',[7.05,3.85,.18],[0,2.95,7.04],frameMaterial);
 box('recess-shadow',[6.86,3.65,.2],[0,2.95,6.91],panelMaterial);
 box('blue-backlight-top',[6.5,.025,.03],[0,4.64,6.78],blueMaterial);
 box('red-backlight-bottom',[6.5,.025,.03],[0,1.26,6.78],redMaterial);
 box('sign-face',[6.4,3.2,.12],[0,2.95,6.73],panelMaterial);
 for(const x of [-3.3,3.3]){
  box('vertical-frame',[.045,3.52,.12],[x,2.95,6.74],frameMaterial);
  box('edge-light',[.018,2.9,.025],[x*.99,2.95,6.66],blueMaterial);
 }
 for(const x of [-6.1,6.1]){
  box('wall-rib',[.14,5.4,.22],[x,2.7,7.05],frameMaterial);
  box('wall-rib-inset',[.025,3.5,.035],[x-.12,2.8,6.9],blueMaterial);
 }
 for(const x of [-2.9,2.9])for(const y of [1.6,4.3])box('mounting-cap',[.055,.055,.04],[x,y,6.65],frameMaterial);
 // Supplied mark is kept in its original aspect ratio and colours.
 const logo=new Mesh(new PlaneGeometry(5.3,5.3/WALL_LOGO_ASPECT),new MeshBasicMaterial({transparent:true,alphaTest:.02,depthTest:true,depthWrite:false,toneMapped:false}));
 logo.name='oracle-redbull-wall-logo';logo.position.set(0,2.95,6.658);logo.rotation.y=Math.PI;logo.visible=false;group.add(logo);
 return {group,logo,setLogo(texture){logo.material.map=texture;logo.material.needsUpdate=true;logo.visible=true;}};
}
