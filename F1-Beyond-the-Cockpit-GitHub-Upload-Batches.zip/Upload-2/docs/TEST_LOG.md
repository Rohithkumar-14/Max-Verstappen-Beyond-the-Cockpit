# Phase 1 test log

Date: 2026-10-26. Prototype status: PIPELINE/PLACEHOLDER, not realism-approved.

## Commands actually executed

| Command | Result |
| --- | --- |
| npm dependency installation | Passed; exact versions subsequently pinned and lockfile updated |
| npm run dev through sites-preview | Started Vite successfully at the exact returned internal preview URL |
| npm run check | Passed: JavaScript syntax in source, tests and scripts |
| npm test | 12 passed, 0 failed |
| npm run build | Passed; final build repeated after layout changes |
| Existing lint/type-check | Not configured in the original project; no ESLint/TypeScript pass claimed |

Nonfatal build warning: bundled Three.js/GSAP JS is about 739 KB minified / 203 KB gzip, exceeding Vite's 500 KB chunk advisory. No post-processing or extra decoder is shipped. No performance target is claimed from these size figures. Npm also reports the host's unknown http-proxy config warning.

## Automated checks actually executed

- Real included GLB parsed using Three.js GLTFLoader; valid bounds and four named wheel assemblies.
- Metallic-roughness materials and lack of external image dependencies verified from the GLB.
- Loader consumed a real GLB byte response, reported progress, centered X/Z, grounded Y and normalized length to 5.4.
- Deliberate model failure, HTTP 404, HTML returned at model URL and AbortSignal cancellation reject usefully.
- Camera bounds and camera-outside-car clearance checked at 101 positions each for 1440x900, 390x844, 320x740, 844x390 and 768x1024.
- Forward/reverse camera pose determinism and endpoint clamping checked.

Initial framing tests failed on portrait layouts. Automatic bounds-based fitting was added. The final run passed all 12 tests. These are geometry/projection checks, NOT rendered 3D screenshots or FPS tests.

## Browser checks actually performed with cua_repl

| Check | Observed result |
| --- | --- |
| Normal page at desktop viewport, approximately 1363x936 | Local poster, error message, retry and project notes visible; no horizontal overflow |
| WebGL unavailable | Actual browser context creation is disabled; page caught it, showed fallback and created no long pin |
| Explicit WebGL failure query | Fallback and retry remained usable; repeated retry did not add canvases/pins or crash |
| Main Skip button | Moved to project notes and focused #milestone |
| Keyboard skip link | First Tab focused skip link; Return navigated to notes and focused the target |
| Return to garage via keyboard | Returned to hero and focused #skip; fallback progress remained 0, pin count 0 |
| Phone 320x740 and 390x844 layouts | Inspected via same-origin iframe viewport harness; no horizontal overflow; actual content widths 305 and 375 with scrollbar |
| Tablet 768x1024 layout | Resized iframe and checked no horizontal overflow; content width 753 |
| Landscape 844x390 layout | Inspected compact layout in iframe, no horizontal overflow; content width 829 |
| DOM-only ScrollTrigger integration | Real shared cameraJourney module pinned once; forward scroll increased progress to about 0.4474; backward decreased it to about 0.1850 |
| Timeline disposal in DOM harness | Skip removed pin spacer (1 to 0), released native scroll and focused #end |
| Console inspection | Expected caught diagnostic warnings in unavailable/injected states; no observed uncaught application errors. Unrelated browser-extension metadata errors are excluded. |

Initial browser preview was blocked by Vite's allowed-host check. Added only the exact internal preview host to vite.config.js and restarted preview. Initial small-screen fallback overlays were adjusted after visual inspection. docs/evidence/desktop-fallback.jpg captures the final tested fallback, not a GPU-rendered garage.

## Unperformed or blocked checks — do not mark passed

- **Static GPU rendering and actual 3D scroll camera:** blocked because this cloud browser has WebGL disabled. Static scene visual gate remains open. GLB parsing and DOM timeline tests do not substitute for rendered scene validation.
- **Convincing realistic car:** NOT met. Included asset is an explicitly labeled simplified licensed placeholder. A high-detail neutral asset is still required.
- **Real desktop/phone frame rates, GPU memory and weak-device behavior:** not measured; DPR caps and demand rendering are implementation measures, not proven performance results.
- **OS-level prefers-reduced-motion and static 3D toggle on a working renderer:** implemented but not end-to-end tested; no browser media-emulation capability was available. No forced-motion or long pin was observed in the fallback path.
- **WebGL context-loss recovery after a successful render:** implemented with poster/retry but not exercisable without working WebGL.
- **Slow-network loading and 15-second timeout in browser:** not exercised. Unit tests cover loader progress/errors/abort, not real network throttling.
- **Successful model-failure-to-retry recovery in browser:** cannot reach model loading without WebGL. HTTP/parse-path behavior was exercised at loader level only.
- **No-JavaScript browser mode, screen reader testing, Safari/Firefox, real touch devices and physical orientation changes:** not performed. Source poster, local stylesheet and notes are present without JS; that is not a browser test pass.
- **Cockpit approach, seated driver, portrait fallback, 22 profiles/data:** intentionally not implemented in Phase 1.

## Required validation before accepting the first milestone

Run npm ci and npm run dev in a WebGL 2-capable browser on a desktop and a phone. Verify the static rear composition first. Check smooth forward/reverse scrolling, both endpoint compositions, intermediate framing, resize, skip, static toggle, reduced motion, context loss and failed model requests. Replace the placeholder and repeat. Record actual device/browser and measured frame times before claiming performance success.

# Max-only continuation — 27 October 2026

The new attachment superseded the22-driver primary product while implementation was underway. Preserved explorer source/page/data, original scene and tests, assets and all prior archives. Created checkpoint commit e5d604c before Max-only changes. No Antigravity-specific files or additional user-supplied Max photo were found in the inspected working tree.

## Automated checks
- `npm run check`: passed after Max modules were added.
- `npm test`:23 passed,0 failed in the latest run. Original12 tests retained.
- New checks cover sourced Max identity/18results/filter counts, duplicate race exclusion, weekend-point sum versus snapshot, four-stage camera continuity/clearance/clamping, chapter reversibility and full-car endpoint projection at1440x900,390x844,320x740,844x390 and768x1024.
- Initial Max tests exposed missing Node JSON import attributes, then narrow-screen/full-car clipping. Fixed JSON imports, portrait-aspect selection and expanded pullback; reran successfully.
- Production build passed after the Max implementation. Three.js is split into dynamically imported loader/scene chunks; no500KB chunk warning in that run. Final build rerun at packaging is recorded by the workflow output.

## Browser checks actually performed
Cloud Chrome through cua_repl, desktop viewport approximately1363x936; responsive tests use same-origin iframe viewport harness, not physical-device emulation.

| Check | Observed result |
| --- | --- |
| Current opening | Concept artwork, heading, CTA, status and skip visible; no desktop horizontal overflow |
| Actual WebGL | Browser reports WebGL2 unavailable; fallback displayed, zero canvases and zero long pins |
| Authentic Max portrait | Local WebP loaded with naturalWidth1000; identity/crop inspected desktop and390px phone |
| Skip CTA | Focus moved to #driver; settled destination at expected scroll offset; pin count0 |
| Keyboard skip | First Tab reached skip link; Return focused #driver |
| Retry after renderer failure | Useful status retained; canvases0, pins0; no observed application crash |
| Missing portrait | `?test=portrait-error`: failed image hidden, labelled initials fallback visible, pins0 |
| Reduced-motion branch | `?reduce=1`: control labelled Reduced motion and disabled; final counters4,73,137,50; pins0. This is a forced JS branch, NOT OS-level preference emulation. |
| Counter animation | Observed intermediate values1/16/31/11, then4/72/135/49, then final4/73/137/50. Values remained final after reverse/forward scroll. |
| Results filters | Wins:2 rows(Bahrain,Singapore);DNF:4;podiums:10. All18 in normal view. |
| Responsive width checks | No reported horizontal overflow at320x740,390x844,768x1024,844x390. Settled phone driver crop and tablet results layout visually inspected. Some immediate harness samples occur before lazy-image completion; those0width samples are not claimed image failures or passes. |
| DOM-only camera harness | Actual shared GSAP controller with camera recorder:0→.39→1 on forward/rapid scrolling;reverse1→.78→.39;endpoint5.10,3.00,-7.40;one pin before disposal,zero afterward. No GPU or GLB rendering occurs in this harness. |
| Console | Expected caught WebGL warning. Unrelated Chrome-extension metadata errors excluded. Portrait-failure test deliberately creates one missing-image request. No observed uncaught application error in tested core flows. |

Earlier in the continuation, before the Max-only scope change, all22 archived cards were browser-tested for correct name/number/team and return navigation; all22next and all22previous transitions wrapped correctly. This does not make the archive the current primary product or imply22portraits exist.

## Not verified / unresolved
- Actual GPU scene, lighting, rear/body/halo composition, rendered camera smoothness, resize with a working canvas, full-car visual quality and context loss after successful rendering: blocked by disabled WebGL.
- Simplified asset does not meet high-detail realism/cockpit/steering-wheel requirements; no licensed seated Max driver model exists locally. The implemented pose approaches the external halo; no interior is fabricated.
- OS-level reduced motion, screen readers, no-JS browser mode, real touch input, Safari/Firefox, physical mobile frame rate/GPU memory and network throttling were not tested.
- Timeline/mask/counter behavior was observed in the fallback/DOM paths; these observations are not a real-device performance certification.
- Reference site content and hierarchy were inspected, but its immersive first view stayed largely unrendered in the cloud browser. No complete motion-analysis claim.

## Publication evidence — 27 October 2026
Native Sites publication succeeded for source0a537d49bf78da014bd11d78a2c45c60d131909b, saved version2, deploymentappgdep_6ae0b238191081919e540b8598b2afa0. A subsequent native site read confirmed access_mode public and latest_version_number2.

Public URL: https://f1-beyond-the-cockpit.lemonybirch9.chatgpt.site

Post-deployment browser navigation timed out; the browser-troubleshooting documentation call then also timed out. Browser control was unavailable for the final hosted-page visual inspection. A separate executor HTTP request returned403. Therefore native publication/public-audience state is confirmed; loading the new hosted version visually, its hosted assets and all hosted interactions are NOT independently browser-verified. Local browser tests described above remain valid. No successful hosted-page check is claimed. Release metadata-only documentation is subsequently synchronized with the unchanged checked application build.

# Focused car/camera revision — 27 October 2026

Scope: asset, loading/material adaptation, camera rail, same-stage portrait handoff and corresponding credits/tests. Statistics, career timeline and results content/layouts preserved.

## Actual-file evaluation
Obtained Blender458“F1 2022”2,959,344byteGLB after official SketchfabAPI licence verification. SHA256matches recorded source. Actual decoded48,966triangles/73meshes,73materials; no external resources/texture dependencies. Raw/normalized bounds and cockpit/halo/steering geometry inspected. Source thumbnail inspected; no visible team branding. Model classified medium detail, not photorealistic. See asset register and JSON evidence.

## Checks run
- `npm run check`:passed.
- `npm test`:29passed,0failed. Original12Phase1 tests retained; data/profile tests retained. Existing max-camera test adjusted from global-box exclusion to permit the real open cockpit; stronger actual-triangle travel tests added.
- `npm run build`:passed; asset local in production output.
- New checks verify exact asset bytes/hash/triangles, loading/normalization/material path, camera segments against actual meshes at1,000segments for desktop and portrait layouts, modeled screen as first cockpit sightline hit, continuous/reversible/clamped poses, full-car endpoint frustum, and full-car-before-portrait ordering.
- Initial tests found airbox intersections near camera progress.643desktop/.634portrait. Fixed approach by moving forward over cockpit opening. Initial portrait pullback speed check also failed; adjusted pullback timing/distance and reran successfully. No failure was simply removed from the log.

## Browser checks actually performed
- Normal main-page attempt: browser warning“WebGL2 is not available in this browser”; designed fallback remains usable.
- Dedicated actual-WebGL review page: same context failure; all stage-selection controls disabled, explicit blocked status. No opening/bodywork/cockpit/full-car GPU capture exists. Do not substitute the source thumbnail or concept poster as rendered-stage evidence.
- Shared DOM-only ScrollTrigger harness: at sequence.78 camera progress~.9512 and portrait hidden; at sequence~.936 camera held at1.0/full-car endpoint[4.8,2.8,-7.3], portrait opacity~.448 and mask inset55.2%; source portrait naturalWidth1000. Reverse scrolling returns the portrait to hidden state. These inspect DOM/state only, not GPU geometry.

## Still blocked
All four requested rendered stages, intermediate rendered clipping/framing, material/lighting quality, actual WebGL reverse/rapid-scroll/resize, real-device performance and a visual GPU portrait-handoff evaluation remain unverified. Available browser cannot create WebGL2. Do not mark this revision visually accepted until tested on a capable browser. Dev command `npm run dev`, then open `/qa/car-review.html` to perform the exact four captures and inspect the continuous rail.


# Local Vite import audit — 27 October 2026

- Before changes: clean Git worktree at `43c654a`. Inspected Git history, the prior car-revision diff, all tracked source files, and all four previously produced source ZIPs. None contains the reported imports or `src/ui/router.js`. These modules were not deleted by the car revision; the supplied local error refers to a different source state. The exact origin of that local state cannot be established without its files.
- Existing architecture retained: Max entry `src/max/main.js`, archived driver explorer `src/app/app.js` (grid/profile rendering) plus `src/app/domain.js` (routing), original garage `src/main.js`. No runtime imports or application files required correction in the available checkout.
- Added `tests/vite-imports.test.js`: actual Vite transform/import analysis for every JavaScript module in `src/` and `qa/`, plus HTML entry-point assertions. No empty modules or removed features.
- `npm run check`: passed. `npm test`: 30 passed, 0 failed. `npm run build`: passed for all three production HTML entries. Existing 29 tests preserved.
- Started the documented Vite dev command through the managed preview service at `http://terminal.local:4173/`. Browser opened the Max page and displayed its portrait, statistics, timeline and results. Browser opened `/qa/car-review.html` and executed its module to the explicit WebGL2-unavailable status, rather than a Vite unresolved-import overlay.
- Standalone shell HTTP checks of the preview failed due to the preview network path; browser access succeeded. These shell attempts are not counted as passing HTTP checks.
- Remaining limits: Windows `npm.cmd` could not be executed on this Linux host. Actual GPU car rendering remains unavailable in the cloud browser; no new rendered-stage validation is claimed. This local source repair does not change the public deployment.


# Milestone photographs and cockpit cue — 27 October 2026

- Integrated the owner’s four supplied celebration photos at 2016, 2021, 2023 and 2024, with proportional WebP derivatives, lazy loading, fixed intrinsic dimensions, meaningful alt text and load-error hiding. No photo assigned to 2015. Two branded car images inspected and preserved as composition/geometry references under docs/references; they do not replace or change the identity of the generic GLB.
- Added restrained GSAP image-mask/scale reveals using the existing scoped animation context. Disabled motion bypasses them; context cleanup restores styles. Preserved career text, statistics, results, car geometry and camera poses.
- Added silent “SIMPLY LOVELY.” holographic UI cue: normalized camera progress .58–.64 fade-in, .64–.68 hold, .68–.73 fade-out. Hidden in static/fallback modes and during the portrait handoff. No fabricated radio recording or live telemetry.
- `npm run check`: passed. `npm test`: 32 passed, 0 failed. `npm run build`: passed. Tests retain all prior checks and add asset/year/hash integrity and dashboard cue timing; import-resolution regression test from the local repair is included.
- Browser: all four milestone images actually loaded with expected natural widths (452/1400/1400/1400). Desktop timeline inspected visually. Same-origin iframe layouts inspected at 390×844 and 320×740: respective scrollWidth 375/305, no horizontal overflow. These are viewport checks, not physical-device tests.
- Browser DOM-only shared-animation harness: dashboard pose camera progress .6565, camera approximately [.03,1.11,.16], cue opacity 1/visible. Reverse scrolling to camera progress .4660 hides the cue with opacity 0. This proves DOM/controller timing only. Actual WebGL review retried: WebGL2 remains unavailable, controls disabled. No GPU stage or GPU cue placement is marked visually verified.
- Forced reduced-motion branch visited: control disabled/pressed, photographs and readable content retained. OS-level preference and new photo network failures were not injected in this pass.
- Supplied-photo underlying licences/photographer identities remain unverified and are described accurately in the asset register and visible credits. Integration was explicitly requested by the owner.


# Supplied RB22 integration — 28 October 2026

## Asset and implementation
- Inspected the actual uploaded ZIP (CRC passed), `source/untitled.glb`, embedded material/texture data and actual source geometry before integration. No additional asset was required from the owner. Found matching official Sketchfab API record with exact 281,075 face count, author and CC BY 4.0 grant. Saved licence/provenance evidence and derivative hashes.
- Replaced only the primary cinematic asset with the supplied textured RB22. Original 37,516,152 bytes becomes desktop 10,364,640 / mobile 8,260,012 bytes. All 281,075 triangles, positions, UVs and livery assignments retained. Normal storage and embedded image budgets optimized; source materials tuned without recolouring the livery.
- Nine model-specific camera poses now include a real LCD close-up/hold. Replaced the floating DOM cue with a depth-tested 512×288 texture plane parented to `gp21_LCD.003`, fitted to its actual geometry and facing the driver. Panel coordinates/occlusion/phone view bounds are tested. Old generic rail retained separately for historical asset tests.
- Phone asset selected by width/memory/Save Data, pixel ratio remains capped, visible viewport used for 3D portrait/landscape, and narrow aspect framing adapts further. Fixed a pre-existing 320px surname clipping issue. Retained skip, static/reduced motion, load progress/error/retry, Max portrait, milestone photos, statistics and results.

## Automated checks
- `npm run check`: passed. `npm test`: 40 passed, 0 failed. `npm run build`: passed. Existing 32 tests retained, plus 8 RB22 tests for bytes/geometry/provenance/texture budgets, budget selection, LCD attachment/depth, actual mesh travel, screen sightline/orientation/phone bounds and actual-car endpoint bounds.
- Real RB22 mesh travel sampled at 1,000 segments each for desktop and portrait, with zero surface crossings. LCD/full-car frusta include 1440×900, 390×844, 320×740, 320×844, 360×900, 844×390 and 768×1024 where applicable.
- Initial phone pullback failed the existing continuity-speed threshold. Adjusted pullback timing to .77 and phone endpoint distance; retained the threshold and reran successfully. No failed assertion was weakened.
- Isolated the Vite regression test's cache in a temporary directory after it interfered with the running preview optimizer. Restarted managed preview once after the repair. Actual dev module loading then resumed. No preview workaround or alternate browser infrastructure was introduced.

## Browser checks actually performed
- Both complete optimized GLBs loaded through the actual browser loader, without stripping textures. Desktop and phone each decoded 27 meshes, 281,075 triangles, 23 materials and all 26 textures. Actual LCD controller attached successfully at approximately [0.000168,0.655928,0.420132]. These are browser asset-decoding checks, not GPU rendering checks. `/qa/asset-review.html` explicitly labels that distinction.
- Actual WebGL review retried: browser cannot create WebGL2, explicit rendering-blocked status and disabled view controls. No opening/bodywork/cockpit/full-car WebGL capture is claimed. The model creator's preview is clearly labelled as a static fallback, not app-rendering proof.
- Shared GSAP DOM-only controller: camera progress .6657, pose approximately [0,.74,.13], dashboard setter opacity 1; reverse scroll to progress .4756 sends opacity 0. DOM floating-overlay count is zero. This verifies controller timing, not final GPU text appearance.
- Main landing opens with actual RB22 creator preview loaded (natural width 1920). Phone iframe widths 390 and 320 show no horizontal overflow; 320 client/scroll widths both 305. Landscape 844×390 also reported no overflow. These are browser viewport checks, not physical-device tests.
- Phone skip link moves focus to `#driver` (top15px). Results “Race wins” filter returns 2/18. Forced reduced-motion branch shows disabled/pressed “Reduced motion” control and readable content. Full surname at 320px uses 48px font and fits its 262px text container.

## Remaining verification limits
- GPU lighting/material quality, rendered camera path, real GPU dashboard readability, actual-device FPS/thermal behaviour, OS-level reduced-motion preference and injected model-failure/context-loss on a WebGL-capable browser remain unverified in this environment. Browser WebGL2 is disabled. The screenshot of a static preview or isolated canvas texture is never substituted for a rendered-stage capture.
- No verified seated 3D Max likeness is supplied. Licensed portrait fallback is retained. Owner-supplied milestone-photo original credits/licences remain unverified as previously documented.

# Mobile, achievements and season archive continuation — 31 October 2026

## Inspection and preservation
- Initial Git status was clean at `b73d4c1`. Read all six original documents; no AGENTS.md was found under /workspace. Current Max-focused user instructions supersede the old grid-first scope.
- Preserved both RB22 optimized files, original desktop poses, actual LCD controller, secondary 22-driver archive, prior models/data, existing meaningful tests and all earlier test-log entries.
- New supplied assets inspected directly. Portrait and 2015 photo proportionally WebP compressed; logo transparent padding trimmed and alpha preserved. Rights limitations recorded without inventing licences.

## Automated checks
- `npm run check`: passed (syntax only; no ESLint/TypeScript configuration).
- `npm test`: 48 passed, zero failures. Existing tests retained; milestone expectations extended to 2015. New checks cover all 12 seasons, official evidence/points reconciliation, 2016 team switch, starts versus entries, Sprint/race points, title history, unknowns, asset hashes and full-car margins in mobile drawing areas after HUD reservations.
- `npm run build`: passed, 43 modules and all three production entry points. No unresolved imports. `git diff --check`: passed.
- During development, the first mobile envelope failed real-mesh cockpit collision and the original speed threshold; corrected framing near the cockpit and retained the old pullback envelope, then reran successfully without weakening checks.
- Initial historical join missed Las Vegas because the official local date and structured UTC date differ by a day; corrected and tested. A test's outdated STR team spelling was corrected to the actual official Toro Rosso row.
- Historical totals reconcile to the preserved official career snapshot. Season inputs and raw factual evidence are local; no runtime API dependency.

## Browser checks performed (cloud Chrome)
- Landing and all 12 season selections loaded. Browser confirmed year headings, row counts (19,21,20,21,21,17,22,22,22,24,24,18) and cumulative stars (0 through 2020, then 1/2/3/4/4/4). 2016 Race wins filter showed Spain, Red Bull, 25 GP/25 weekend points.
- Visually inspected the 2023 desktop summary with three stars; phone season panel; the new 2015 milestone with its image (naturalWidth 1600) and large subtle lion; the new helmeted portrait (736 × 1260, object-fit contain).
- Same-origin viewport checks at 320 × 740 and 390 × 844 reported client/scroll widths 305/305 and 375/375 after loading. 844 × 390 landscape reported 829/829. These are browser viewport checks, not real-device emulation or performance tests.
- Forced reduced-motion branch showed disabled “Reduced motion” control and decorative animationName none. This is a JS-branch check, not an OS preference change. Injected portrait error showed hidden failed image and visible labelled fallback.
- Real `/qa/car-review.html` executed without missing-import overlay, but WebGL2 context creation failed; disabled controls and explicit RENDERING BLOCKED message appeared. No GPU stage was visually verified.
- Shared DOM-only GSAP recorder reached cockpit camera progress .6895 with actual hold coordinates about [0,.74,.13] and cue opacity .905; reverse scrolling subsequently reported progress .5467 and cue opacity 0. This checks controller timing only, not the rendered car or dashboard.

## Source archive validation
- Fresh standard-deflate ZIP created from actual project files, excluding node_modules, Git history, hosting identity, credentials, dist and caches. All entry points, modules, local assets, tests, README and docs included.
- CRC/integrity test passed and required entries checked. Extracted to an independent directory; plain `npm ci` succeeded (19 packages), `npm run check` passed, `npm test` passed 48/48 and `npm run build` passed.
- Started the extracted project's documented npm dev script through the managed preview service. Browser loaded the real QA review route to its expected explicit WebGL2 blocker, rather than an import failure. Windows npm.cmd was not executable on this Linux host; Windows commands are documented, not claimed as executed.
- Final archive regeneration incorporates this documentation; final bytes/count/hash are reported in the packaging output.

## Remaining limits
- Actual GPU opening/bodywork/cockpit/full-car visual framing, GPU portrait handoff, real mobile FPS/thermals, hardware browser-toolbar behaviour and OS-level motion preference still require capable hardware. No substitute preview or geometry check is labelled GPU proof.
- Actual model-failure/context-loss browser flows require WebGL2; loader failures remain covered by automated tests. New photo/logo original rights are unverified and disclosed. RB22 CC BY 4.0 attribution remains intact.

# Achievements, typography, portrait and garage review — 31 October 2026

## Current scope and pending work
- Inspected the real Git diff before continuing: unpublished portrait restoration and initial sticky-lion/font edits existed on top of published commit `04f5156c`. Preserved useful edits, then superseded the interim podium portrait with the owner's newly specified white-suit photograph.
- The owner explicitly requires review/acceptance before a new final source ZIP. No new source ZIP is generated or delivered for this review revision. Deployment packaging is only the static hosting build, not a user source ZIP.

## Changes and automated checks
- Continuous achievements backdrop: absolute section track plus a viewport-height sticky lion, clipped to the chapter; soft orange glow and six restrained sparkle points behind all content. Existing five milestone photos and their hashes unchanged.
- Local Michroma radio-inspired UI lettering and Space Grotesk body face, both with verified SIL OFL text/source records. The alphabet screenshot is a reference, not an installable or licensed official F1 font. Large condensed display headings retained.
- Cinematic handoff retains `/portraits/max-helmet.webp`; the following profile uses `/portraits/max-white-suit.webp` (736 × 1308, complete composition). Previous podium portrait preserved for the secondary archive.
- Added optional, modular garage architecture: recessed sign surround, backing/face layers, metal ribs and mounting caps, blue/red light strips and correctly proportioned depth-tested logo plane. All architecture remains at z > 6.5, outside the complete car/camera travel volume. Primary scene and real-WebGL QA opt in; original garage remains unchanged. Logo loading is non-blocking, and late completion/scene disposal is guarded.
- `npm run check` passed. `npm test`: 50 passed, zero failures (existing 48 retained; two additions check physical sign/depth/normal/aspect/clearance and asset/font hashes/licences). `npm run build` passed, 44 modules and three production entries. `git diff --check` passed. No camera poses, car model bytes, dashboard panel or statistics data changed.

## Browser checks actually performed
- Desktop: loaded all five milestones, clicked each year, confirmed the same loaded lion remains in the viewport. At 2015/2016/2021/2023/2024 recorded sticky top 0 / bottom 936 after entering the sticky range. Visually inspected 2015, 2016 and 2024 compositions: logo/glow/sparkle remain behind opaque photos and text, not overlaid on them. Michroma's actual geometric letterforms were visible after font loading; computed timeline heading family is Michroma/Space Grotesk.
- 320 × 740 iframe: visited all five years. Lion visible at each (first chapter entrance top 63/bottom 803, then top 0/bottom 740). Body client/scroll width 305/305 throughout. Visually inspected last two milestones and confirmed the logo is no longer confined to 2015.
- At narrow-phone Statistics, career bottom and statistics top were both 15.34px; lion did not leak into the visible statistics section. Screenshot inspected.
- New profile photograph actually loaded at natural 736 × 1308; object-fit contain retains Max and the car. Blue-background helmet photo remains a separate handoff asset. Narrow-phone composition inspected.
- On the Record: selected 2023 and Race wins, got three championship stars and 19 result rows; client/scroll width 305/305. Existing selector/filter behaviour preserved.
- 390 × 844 forced reduced-motion branch: disabled Reduced motion control, lion/glitter animationName none, lion opacity .27; widths 375/375. Landing/navigation layout inspected without overflow. This is branch testing, not an OS preference change or a physical-device performance test.
- Real `/qa/car-review.html` loads and reports WebGL2 unavailable with disabled view controls. No rendered garage sign or car stage is visually certified. Source geometry/material tests and a projected sign location are not GPU proof.

## Known limits and rights
- The new world-space garage wall's actual GPU lighting, material appearance, logo readability from moving cameras and real-phone performance still require a WebGL2-capable browser. Available cloud browser cannot create the context; the unchanged creator preview is not presented as a rendering of the new wall.
- Logo and new photograph are user supplied, with original rights unverified and accurately disclosed. No event/year is inferred for the photo, and no official affiliation is implied. Font licence files and existing car attribution remain bundled.

# Portrait frame correction — 31 October 2026
- Changed only profile layout CSS: desktop frame uses the supplied photograph's 736:1308 ratio at up to 420px wide, mobile uses the same ratio up to 360px. Removed the blue letterbox background; full image retained without stretching, cropping or asset edits. Repositioned the existing race number beside/below the frame.
- Browser desktop frame measured 420 × 746 with source 736 × 1308; narrow-phone frame 262 × 466, client/scroll widths 305/305. Both inspected visually. Helmeted cinematic image and all other sections unchanged.
- Existing `npm test`: 50 passed; `npm run check`, production build and `git diff --check` passed. No new tests for this reversible CSS-only correction.
- Source ZIP remains on hold pending explicit acceptance. Earlier GPU verification limitations remain unchanged.

# Four stars on the achievements lion — 31 October 2026
- Added four decorative career-title stars immediately above the lion, in a shared proportioned emblem wrapper inside the existing section-contained sticky backdrop. The four stars describe the overall four-title career chapter, not a changing per-year total. Season-selector title counts are unchanged.
- Desktop star/lion gap measured 12px; phone portrait 11px and landscape 10px. Responsive emblem dimensions reserve headroom for stars even in short landscape viewports. Gentle staggered opacity shimmer with a static glow; motion-off and reduced-motion disable shimmer. All decoration remains behind photographs/content and is hidden from the accessibility tree with its parent backdrop.
- Browser desktop inspected at 2021. Phone viewport checks at 320 × 740, 390 × 844 and 844 × 390 confirmed exactly four stars, positive top coordinates, star row within horizontal viewport bounds, shared sticky positioning and client/scroll widths 305/305, 375/375, 829/829. No layout overflow. This does not imply physical-phone performance certification.
- `npm run check`, existing 50 tests, production build and `git diff --check` passed. No car, camera, photo, source data or other section changes. Source ZIP remains on hold until explicit acceptance.


# Approved final source archive — 31 October 2026

- Owner accepted the four-star review version and requested the ZIP with a proper README. No application code or asset bytes changed during final packaging.
- Reworked README with Windows setup, Git and browser-upload instructions, production hosting notes, credits and GPU/data limitations. Preserved previous technical detail in docs/TECHNICAL_GUIDE.md. Updated .gitignore to exclude environment files, provider identity and logs.
- Fresh ZIP uses standard DEFLATE; CRC and required-file checks passed. Excluded dependencies, build output, Git history, hosting identity, credentials and caches.
- Clean extraction: npm ci succeeded (19 packages); npm run check passed; npm test passed 50/50; npm run build passed, all three production entry points. Linux Node 24.22.1 / npm 11.9.0; Windows commands documented but not executed here.
- Default 0.0.0.0 dev binding encounters this sandbox's uv_interface_addresses restriction. npm run dev -- --host 127.0.0.1 --port 5191 --strictPort starts successfully; HTTP 200 checks passed for /, /qa/car-review.html, /src/max/main.js and /qa/car-review.js. The import-analysis test resolves all application/QA JavaScript. This HTTP check does not certify WebGL rendering.
- Existing desktop/mobile browser evidence and WebGL2/GPU limitations remain as recorded above. No new rendered GPU or physical-phone claims.
