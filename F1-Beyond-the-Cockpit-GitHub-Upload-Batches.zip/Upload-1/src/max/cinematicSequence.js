const clamp=value=>Math.max(0,Math.min(1,value));
export function smoothRange(start,end,value){const t=clamp((value-start)/(end-start));return t*t*(3-2*t);}
// Reach and hold the complete car before the portrait enters the same pinned frame.
export function cinematicState(progress){
 const p=clamp(progress),cameraProgress=clamp(p/.82);
 const cockpitCueOpacity=smoothRange(.58,.64,cameraProgress)*(1-smoothRange(.68,.73,cameraProgress));
 return {progress:p,cameraProgress,cockpitCueOpacity,portraitProgress:smoothRange(.88,1,p),introOpacity:1-smoothRange(.04,.22,p)};
}
