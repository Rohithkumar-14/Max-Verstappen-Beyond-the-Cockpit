# Asset register

Checked 2026-10-26. Assets are local; no runtime hotlinks or data API is required.

## Integrated neutral car — PLACEHOLDER, not realism-approved

| Field | Record |
| --- | --- |
| File | public/models/ground-effect-racer.glb |
| Source title | Current ground-effect racer (Formula Race Cars and Grand Prix Circuit) |
| Creator/publisher | 3D Assets / @3dassets; publisher reports AI-assisted generation |
| Source URL | https://3dassets.dev/assets/grand-prix-circuit-and-open-wheel-ground-effect-racer-02c3b491 |
| Download | https://cdn.3dassets.dev/assets/15179/v1/model.glb |
| License | CC0 1.0 Universal, explicitly stated on the asset listing and pack page |
| License URL | https://creativecommons.org/publicdomain/zero/1.0/ |
| Permission scope | Listing explicitly permits modification, redistribution, commercial use and direct browser/CDN loading |
| Attribution | Not required by CC0; voluntarily credited on the prototype |
| License verification | Source listing and official CC0 deed inspected before download. This records the publisher's grant, not an independent authorship warranty. |
| File size | 409,808 bytes |
| SHA-256 | 20a299973369837e8d6a2766729cc37e205ef692e9b7829f151b6e18967086df |
| Format/materials | glTF 2 binary, 8 metallic-roughness PBR materials, no image textures |
| Published triangle count | 9,340 |
| Measured bounds | Approximately 2.062 x 1.160 x 5.415 scene units; +Y up, nose +Z |
| Adaptation | Runtime graphite paint and neutral accent material; normalize to length 5.4; preserve the original GLB |
| Animation | Included wheel animation is NOT played; car remains stationary |
| Evidence | docs/evidence/asset-listing.json (downloaded pack manifest entry) |

### Quality inspection and limitations
The preview and geometry are recognizably Formula-style with wheels, wings, body, floor, halo and cockpit area. Their simplified shapes, limited suspension/aero detail, untextured surfaces and rudimentary cockpit do NOT meet convincing realism or close cockpit shots. No accurate 2026 chassis claim. No team/sponsor identity is applied. The white occupant-like shape is part of the simple asset, not a separately acquired seated driver or an identified real person. GPU visual inspection is blocked in this environment; exterior silhouette was inspected using the source poster and geometry was parsed with Three.js.

A replacement must be a licensed high-detail NEUTRAL car with realistic tires, suspension, diffuser, wings, sidepods, cockpit, halo and steering wheel. Browser distribution and material/optimization rights must be explicit. Recheck license and visible marks before adoption. A branded team car is not an acceptable default shared car.

## Static fallback image
- File: public/images/car-study.webp; 46,968 bytes.
- URL: https://cdn.3dassets.dev/assets/15179/v1/poster.webp
- Creator and license: same asset/publisher, CC0 listing.
- Usage: local static preview; CSS desaturation only. It shows the unmodified source model/materials, not a screenshot of our garage scene. No model loading or WebGL is needed. Source image quality is placeholder-level, not photorealistic.

## Typography
- File: public/fonts/barlow-condensed-bold.ttf; 87,120 bytes; no modifications.
- Creator: The Barlow Project Authors (https://github.com/jpt/barlow).
- License: SIL Open Font License 1.1; copied at docs/licenses/Barlow-OFL.txt. Redistribution/embedding permitted with the license/copyright notice retained. Not sold separately.
- Source declaration: https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700&display=swap
- Download: https://fonts.gstatic.com/s/barlowcondensed/v13/HTxwL3I-JCGChYJ8VI-L6OO_au7B46r2_3E.ttf
- License source: https://raw.githubusercontent.com/google/fonts/main/ofl/barlowcondensed/OFL.txt
- Fallback: local system condensed/sans-serif fonts.

## Original project elements
Garage floor/wall/strips, radial contact shadow, favicon, UI and copy are generated as project source. No third-party garage HDRI or sound assets. The RoomEnvironment utility is provided by Three.js (MIT), not an acquired HDRI. Npm dependency licenses stay in their packages.

## Other candidates investigated, not downloaded
- Sketchfab generic/Formula listings: several CC Attribution candidates appeared in search, but no suitable browser-deliverable asset was acquired and inspected with a complete rights record. No source viewer assets were extracted.
- OpenGameArt “Formula 1 car high poly - uncomplete”: listed CC0 but incomplete and in Blender format; not adopted.
- Paid generic Formula listings: not purchased. Payment and exact web-distribution terms remain unresolved.

## Driver/portrait assets
Phase1 originally acquired none; Max and Fernando portrait additions are recorded below. See DRIVER_REVEAL_PLAN.md for permissions, seated fit, representation labeling, and licensed accurate portrait fallback requirements.

## Original cinematic illustration — 27 October 2026
- File: public/images/garage-concept.webp.
- Type: AI-generated fictional garage/car concept, created with the built-in OpenAI image generation tool for this project. No third-party source image or model was supplied.
- Not a photograph, licensed real-car model, authentic 2026 car, or engineering reference. These limits are visible in the hero and credits.
- Transformation: lossily compressed to WebP quality88 for browser delivery. Original PNG preserved outside the project in generated_images.
- Prompt: “Wide 16:9 cinematic website hero, realistic 3D-style illustration of one unbranded graphite-black Formula-style car, rear three-quarter view in a dark garage; four slick tyres, rear wing, diffuser, carbon body, halo, empty cockpit; car on right two-thirds, dark left negative space; restrained cyan rim and violet reflections; no logos, sponsors, numbers, people, text or UI. Fictional concept, not a specific 2026 F1 car.”
- Rights/provenance: generated output for this project; no third-party stock licence or CC licence claimed. Not a guarantee of exclusive copyright. Public-use treatment is original concept illustration, never a real-driver likeness.
- Failed image load leaves the title, CTA and navigation usable.


## Integrated Max Verstappen editorial portrait

- Local file: `public/portraits/max-verstappen.webp` (1000 × 1076 WebP).
- Source: [Commons individual file and licence](https://commons.wikimedia.org/wiki/File:2024-08-25_Motorsport,_Formel_1,_Gro%C3%9Fer_Preis_der_Niederlande_2024_STP_3973_by_Stepro_(portrait_cropped).jpg).
- Photographer/required attribution: **Steffen Prößdorf**; portrait crop by Bagumba.
- Licence: [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/). Download, browser display, redistribution and modification permitted with attribution, licence link, change notice and share-alike adaptations. This resized WebP adaptation is distributed under CC BY-SA 4.0.
- Content: Max Verstappen, 2024 Dutch Grand Prix podium ceremony, 25 August 2024. Historical editorial photograph, not an official 2026 portrait.
- Modifications: source portrait crop resized from 1380 × 1485 to 1000 × 1076 and converted to WebP.
- Source includes personality/trademark notices and FIA editorial-publication notice; no endorsement or model release is implied.
- Acquisition: direct shell fetch returned 403; browser download succeeded and actual image was visually inspected. Local WebP decoded successfully.
- SHA-256: `244e65cd9fa1363cfe6f2100694bfa496d600d79ac173d2b39162a40ef204acb`.
- Full attribution and preserved earlier portrait: `docs/PORTRAIT_CREDITS.md`.

## Current Max cinematic car — Blender458, 27 October 2026

This replaces the original simplified car ONLY in the Max cinematic experience. The original GLB and Phase1garage remain preserved.

| Field | Verified record |
| --- | --- |
| Asset / creator | “F1 2022” / Blender458 |
| Local file | public/models/blender458-f1-2022.glb |
| Primary creator record | https://api.sketchfab.com/v3/models/f5b9ca6095124bf796934c150d178a02 |
| Creator page | https://sketchfab.com/3d-models/f5b9ca6095124bf796934c150d178a02 |
| Licence | CC BY4.0; official API identifies creator, licenceURL and downloadable status |
| Licence terms | https://creativecommons.org/licenses/by/4.0/ ; attribution, licence link and change notice required; local browser delivery, modification and redistribution permitted |
| Accessible export | https://raw.githubusercontent.com/Pilot123321/RM-RAIN-MASTER/main/public/assets/f1.glb |
| Corroborating provenance | https://github.com/madeinusmate/fix-singapore-gp/blob/main/CREDITS.md and its car preparation script identify Blender458 and the exact source exportSHA1 |
| Measured file size | 2,959,344bytes |
| SHA256 | 8017633e3c697efdfdb8589b697cbab6cb9cb3b898e7cfd3501ae4ac6f17db3d |
| SHA1 | b2125912afce802035d0ae9975bd8701dce78952 |
| Actual geometry | 48,966triangles,73meshes,73materials,71,793expandedposition vertices |
| API geometry count | 49,189faces/26,125vertices; export differs, so actual decoded count is used |
| Dependencies | No textures/images, no external buffers and no required decoder/extensions |
| Raw bounds | min[-.245666,-.011016,-2.252746],max[1.536221,1.065861,2.204794] |
| Raw dimensions | 1.781887 ×1.076877 ×4.457540;Y-up,nose+Z |
| Adaptations | Center X/Z, ground Y, normalize length5.4; neutral navy/graphite PBR finish; screen emissive tint without invented telemetry; original model bytes retained |
| Visible credit | Current main-page Sources & credits names Blender458,source,CCBY4.0 and modifications; Pilot123321 export also acknowledged |
| Evidence | docs/evidence/blender458-sketchfab-api.json and blender458-inspection.json |

### Actual suitability and limitations
The decoded meshes/material groups include rear wing, suspension members, side body, floor/underbody, halo, cockpit tub, leg area, steering-wheel body, screen and separate dials. Steering-wheel geometry accounts for20,655triangles; increased total count is not a claim that the entire exterior is high detail. Neutral unbranded source thumbnail inspected. This is a **medium-detail, untextured2022-inspired model**, a genuine cockpit-geometry upgrade over the9,340triangle placeholder, not a photorealistic or accurate2026RedBull car.

The measured normalized steering-wheel centre is approximately[-.003,.734,.502]. Camera paths are rebuilt against these real component locations. The initial approach intersected the rear airbox; geometric segment testing found it and the approach was corrected over the actual opening. Final camera travel segments avoid the real triangle surfaces; a cockpit sightline hits the modeled screen first. These mathematical checks do not constitute visual WebGL acceptance.

No seated Max model is included or fabricated. No photograph was baked into the cockpit. The real local Max portrait appears separately after the complete-car composition. Texture-level microdetail, deformation-quality cockpit trim and exact2026aerodynamics remain absent. A further premium model would still require author-cleared acquisition and rendered evaluation. Licence/provenance checks record the publisher's grant, not an independent warranty of authorship.

### Other evaluated candidates
- TheoDevF12“F1 2022 Generic”(9b2fc584679e468ca3a7cb98a75857d2): original primaryAPI licenceCCBY-NC-ND. Reuploads markedCCBY do not resolve that restriction. Excluded from modifications/recolouring and not downloaded.
- mpdevteam“Generic2022F1car”(885d67926c1f4397bebd4efd6b5a3f73): primaryAPI lists172,260faces,CCBY and a designed steering wheel. No model acquired; official download requires authenticated access. Size, orientation and actual close-up quality remain unknown. Not integrated.
- timo74“F1-2022”(e3b0f2bfb00d42c98945385a5506141b): primaryAPI lists11,014,400faces andCCBY; impractical unoptimized geometry, no local source file acquired. Not integrated.
- leonmediastore“Formula1GenericRacingCar03”: creator listing describes a262,016triangle middle version, PBR maps and steering wheels. Paid asset, not purchased; browser-extractable redistribution terms not independently cleared. Listing details are not actual-file inspection. Not integrated.


## Owner-supplied references and milestone photographs — 27 October 2026

The owner explicitly supplied six images and requested their use. This is authorization to integrate those uploads; it is not evidence of an open licence. Original photographers, original source URLs, modification permissions and underlying redistribution licences were not supplied and have not been independently verified. No Creative Commons or official-team licence is claimed for them. Visible credits identify the milestone photographs as owner-supplied and state the missing credits/licences.

| Uploaded file | Local derivative/reference | Use |
|---|---|---|
| image.png | docs/references/car-side-reference.png | Side proportions, wings, tyres, halo and bodywork visual reference only |
| image(1).png | docs/references/car-three-quarter-reference.png | Three-quarter composition reference only |
| image(2).png | public/images/milestones/max-2016.webp | 2016 first-victory milestone |
| image(3).png | public/images/milestones/max-2021.webp | 2021 first-title milestone |
| image(4).png | public/images/milestones/max-2023.webp | 2023 record-season milestone |
| image(5).png | public/images/milestones/max-2024.webp | 2024 fourth-title milestone |

Photographs are resized proportionally and WebP-compressed, with original compositions retained. Dimensions, sizes and SHA256 hashes are in docs/evidence/milestone-images.json. No supplied photograph depicts the 2015 debut; that entry remains text-only. The branded reference images do not turn the existing generic GLB into an authentic Red Bull car, do not supply unseen 3D geometry, and are not applied as a fabricated model texture. The neutral, separately licensed model is preserved.


## Current primary car: owner-supplied Red Bull RB22 — 28 October 2026

This supersedes the generic default for the primary Max experience at the owner's explicit request; the two historical models and their tests are preserved.

- Uploaded archive: `2026-redbull-rb22.zip`, valid CRC. Actual model: `source/untitled.glb`, 37,516,152 bytes. SHA256 `16eee6365ce3d77d4e69e5c60a596cbb39b2517461842df9e1fbc3e529f9c71d`.
- Matching source: https://sketchfab.com/3d-models/2026-redbull-rb22-0a3d24a58e0549d591a5a48c22eec383 — title “2026 Redbull RB22”; author Dave Love SketchFab (@Tyler_Dave), https://sketchfab.com/Tyler_Dave.
- Licence verified from the official model API: https://api.sketchfab.com/v3/models/0a3d24a58e0549d591a5a48c22eec383. Exact face count 281,075 matches the upload. API states downloadable, CC Attribution, author credit required, commercial use allowed; licence https://creativecommons.org/licenses/by/4.0/. API record saved in `docs/evidence/rb22-sketchfab-api.json`.
- CC BY 4.0 permits sharing/redistribution and modification with attribution, licence link and change notice. Public-browser bundling of the adapted model is covered by that licence grant. Attribution/source/licence/change notice appear in visible credits and embedded GLB metadata. This is the uploader's licence grant, not independent certification of engineering accuracy or official Red Bull endorsement; trademarks are not separately licensed by Creative Commons.
- Actual geometry: 281,075 triangles, 27 primitives (27 Three.js meshes), 23 materials, 26 embedded images. All textures bundled; no external texture fetches. Node matrix converts native axes to world Y-up and nose +Z; original node transform preserved. Raw world dimensions approximately 1.90976 × 1.18517 × 5.39694. Loader centers XZ, grounds Y and normalizes length to 5.4.
- Real dashboard screen material: `gp21_LCD.003`. Normalized panel centre approximately [0.000168, 0.655928, 0.420132], physical screen approximately 0.0928 × 0.0541 model units before panel margins. The custom message is a separate depth-tested plane parented to this actual screen, 0.0008 units toward the driver, with a 512×288 locally drawn texture. No DOM floating label or invented telemetry is used.
- Adaptations: textures resized/WebP compressed (normal maps remain PNG), normals quantized with KHR_mesh_quantization, body/tyre/glass material tuning, normalization, dashboard panel. Positions/UVs/topology/livery assignments retained. Desktop GLB 10,364,640 bytes; mobile 8,260,012 bytes. Exact derivative hashes and texture sizes: `docs/evidence/rb22-optimized.json`.
- Static fallback is the creator's preview image from the same CC BY model listing, bundled as `public/images/rb22-preview.webp` and credited as a creator preview. It is not a screenshot of this application's WebGL rendering. Earlier AI concept remains a separate closing-section background.
- No verified 3D Max likeness is provided by this upload. Existing licensed historical portrait is retained for the human reveal.

## 31 October 2026 — owner-supplied milestone, lion and portrait

- `public/images/milestones/max-2015.webp`: supplied `image(6).png`, proportionally resized to 1600 × 1065 and WebP compressed. All composition and visible Jamey Price watermarks retained; watermark is a credit clue, not proof of a licence. Used only for the 2015 debut milestone.
- `public/images/max-lion.webp`: supplied `image(7).png`. Transparent padding trimmed, original alpha preserved, proportionally resized to 975 × 1024, WebP compressed. Orange shape unchanged. Used as a decorative, low-opacity achievements background and a small championship badge. CSS supplies glow/glitter; no generated replacement.
- `public/portraits/max-helmet.webp`: supplied `image(8).png`, 736 × 1260, WebP compressed without changing the photograph. Used for the shared cinematic handoff and following Max portrait; the prior licensed portrait is preserved for the secondary archive.
- The mobile WhatsApp screenshot is diagnostic reference only; it is not deployed or included in the source ZIP.
- Original usage licences and photographer information for these new supplied photographs/logo were not provided or independently verified. No Creative Commons grant is asserted. The owner requested their integration and publication. This limitation is visible in the site credits and must remain in redistributions. A third-party watermark must not be removed. The repository has no blanket licence that overrides these rights.
- Exact derivative sizes/hashes are in `docs/evidence/october-updates-assets.json`; milestone hashes remain in `docs/evidence/milestone-images.json`.
- Existing RB22 CC BY 4.0 provenance, model bytes, required creator credit, optimized variants and dashboard texture are unchanged.

### Portrait placement correction — 31 October 2026
The supplied helmeted photograph now appears only in the cinematic handoff after the full-car reveal. The following driver section restores `public/portraits/max-verstappen.webp`, the preserved 2024 Dutch GP podium photograph by Steffen Prößdorf (portrait crop by Bagumba), CC BY-SA 4.0. Source and licence links are restored beside that portrait and in the credits. Neither image's bytes were changed; no additional uploaded asset was needed.

## Achievements/garage review revision — 31 October 2026

This revision supersedes the immediately preceding portrait-placement note: the main driver section now uses the newly supplied white-suit photograph, not the 2024 podium portrait. The blue-background helmet photograph remains only in the cinematic handoff. The licensed podium file is preserved for the secondary archive.

- `public/portraits/max-white-suit.webp`: `image(20261031-055205).png`, 736 × 1308. Complete composition retained; proportionally WebP compressed. No event, year or photographer is inferred. Original usage rights unverified; visible credits disclose the limitation.
- `public/images/oracle-redbull-racing.webp`: `image(20261031-055109).png`, 1000 × 474, alpha preserved, WebP compressed. Used on a depth-tested world-space plane inside the new layered garage architecture. Original proportions/colours retained. User supplied; no independent redistribution or trademark grant asserted, no endorsement implied. Failed load hides only the logo surface.
- `image(20261031-055028).png` and `image(10).png` are alphabet references, not font files or licence evidence; not embedded as fonts.
- Michroma Regular: https://github.com/google/fonts/tree/main/ofl/michroma, copyright The Michroma Project Authors; SIL OFL 1.1, retained in `public/fonts/michroma-OFL.txt`. Font: `michroma-regular.ttf`, 64,344 bytes. Alternative radio-style face, not claimed official F1.
- Space Grotesk variable: https://github.com/google/fonts/tree/main/ofl/spacegrotesk, copyright The Space Grotesk Project Authors; SIL OFL 1.1, retained in `public/fonts/spacegrotesk-OFL.txt`. Font: `space-grotesk-variable.ttf`, 136,676 bytes. Local delivery, font-display swap and system fallbacks.
- Exact derivative hashes and source URLs: `docs/evidence/review-assets.json`, `docs/evidence/typography-fonts.json`.
