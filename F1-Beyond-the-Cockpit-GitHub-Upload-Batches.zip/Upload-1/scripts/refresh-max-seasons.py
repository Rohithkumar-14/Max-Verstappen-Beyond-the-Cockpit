import concurrent.futures,urllib.request,json,re,html,pathlib,time
ROOT=pathlib.Path(__file__).resolve().parents[1]; OUT=ROOT/'docs/evidence/seasons';OUT.mkdir(exist_ok=True)
DATE='2026-10-31'
def fetch(url):
 for attempt in range(3):
  try:return urllib.request.urlopen(url,timeout=45).read().decode()
  except Exception:
   if attempt==2:raise
   time.sleep(1)
def clean(s):return re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',re.sub(r'<svg\b.*?</svg>','',s,flags=re.S)))).strip()
def table(s):
 t=re.findall(r'<table\b.*?</table>',s,re.S)[0]
 return [[clean(c) for c in re.findall(r'<td\b[^>]*>(.*?)</td>',r,re.S)] for r in re.findall(r'<tr\b.*?</tr>',t,re.S) if '<td' in r]
def year(y):
 base=f'https://www.formula1.com/en/results/{y}';ru=base+'/drivers/MAXVER01/max-verstappen';su=base+'/drivers'
 rows=table(fetch(ru)); standings=table(fetch(su));standing=next(r for r in standings if any('Max' in c and 'Verstappen' in c for c in r))
 races=[dict(grandPrix=r[0],date=r[1]+f' {y}',team=r[2],position=r[3],points=float(r[4])) for r in rows]
 api=f'https://api.jolpi.ca/ergast/f1/{y}/drivers/max_verstappen/results/?limit=100';data=json.loads(fetch(api));jr=data['MRData']['RaceTable']['Races']
 assert len(jr)==len(races),(y,len(jr),len(races))
 starts=sum(r['Results'][0]['status'] not in ['Did not start','Did not qualify','Withdrew','Withdrawn'] for r in jr)
 # The official starting-grid archive identifies the driver credited with pole, including Sprint-format 2021 weekends.
 poles=0; grid_sources=[]
 for index,r in enumerate(jr):
  result=r['Results'][0]
  if result['grid']=='1':poles+=1
  # GP-only points and retirement classification from the independent structured archive.
  matching=races[index] # Official local date can differ from UTC, notably Las Vegas.
  if matching:matching.update(racePoints=float(result['points']),status=result['status'],started=result['status'] not in ['Did not start','Did not qualify','Withdrew','Withdrawn'])
 # Verify pole count against official race starting-grid records for every round, including DNS poles.
 # No season-wide starting-grid endpoint exists; use structured GP grid records.
 # This endpoint can default to a single event; do not interpret it as a season-wide pole table.
 points=float(standing[-1]);wins=sum(r['position']=='1' for r in races);podiums=sum(r['position'] in ['1','2','3'] for r in races)
 obj=dict(year=y,position=int(standing[0]),points=points,teams=list(dict.fromkeys(r['team'] for r in races)),wins=wins,podiums=podiums,poles=poles,raceStarts=starts,entries=len(races),championships=sum(t<=y for t in [2021,2022,2023,2024]),complete=y<2026,verifiedAt=DATE,sourceUrl=ru,standingsUrl=su,structuredSourceUrl=api,raceResults=races,notes=['Championship and weekend points include Sprints where applicable. Race points are shown separately.','Pole counts follow recorded Grand Prix P1 grids. Official local race dates are retained; the structured archive may use the following UTC date.'])
 assert sum(r['points'] for r in races)==points,(y,'points mismatch',sum(r['points'] for r in races),points)
 (OUT/f'{y}.json').write_text(json.dumps(dict(officialStandingsRow=standing,officialResultRows=rows,structured=data),indent=2))
 print(y,points,wins,podiums,poles,starts,flush=True);return obj
with concurrent.futures.ThreadPoolExecutor(max_workers=4) as p: result=list(p.map(year,range(2015,2027)))
titles=0
for season in result:
 if season['complete'] and season['position']==1:titles+=1
 season['championships']=titles
(ROOT/'src/data/max-seasons.json').write_text(json.dumps(result,indent=2)+'\n')
