import {populateContent} from '/src/max/content.js';
import {setupAnimations,animationDiagnostics} from '/src/max/animation.js';
import {journeyPose} from '/src/max/cameraPath.js';
populateContent();
document.body.classList.add('has-3d'); // Layout only; no GPU renderer or substitute car image.
const output=document.getElementById('scene-status');
const fakeScene={renderer:{toneMappingExposure:1},invalidate(){},setDashboardCue(p){output.dataset.dashboardOpacity=String(p);},setProgress(p){output.textContent=`DOM QA ONLY / progress ${p.toFixed(4)} / camera ${journeyPose(p,innerWidth/innerHeight<.9,innerWidth/innerHeight).position.map(x=>x.toFixed(2)).join(',')}`;}};
const dispose=setupAnimations({enabled:true,scene:fakeScene,onProgress:p=>{document.querySelector('.journey-progress').setAttribute('aria-valuenow',String(Math.round(p*100)));document.getElementById('journey-fill').style.transform=`scaleX(${p})`;}});
document.getElementById('motion-toggle').addEventListener('click',()=>{dispose();output.textContent=`Disposed / pins ${animationDiagnostics().pins}`;});
document.querySelectorAll('a[href="#driver"]').forEach(link=>link.addEventListener('click',()=>{dispose();}));
