import gsap from 'gsap';
import {ScrollTrigger} from 'gsap/ScrollTrigger';
import {journeyChapter} from './cameraPath.js';
import {cinematicState} from './cinematicSequence.js';
gsap.registerPlugin(ScrollTrigger);
const counted=new WeakSet();
export function setupAnimations({enabled,scene,onProgress}){
 const stage=document.querySelector('#cinema-stage');
 const intro=stage.querySelector('.intro-copy'),handoff=stage.querySelector('.cinematic-handoff');
 const handoffImage=stage.querySelector('.handoff-portrait'),handoffCopy=stage.querySelector('.handoff-copy');
 function resetHandoff(){scene?.setDashboardCue?.(0);if(intro){intro.style.opacity='';intro.style.transform='';intro.style.visibility='';}if(handoff){handoff.style.opacity='';handoff.style.visibility='';}if(handoffImage)handoffImage.style.clipPath='';if(handoffCopy)handoffCopy.style.transform='';}
 resetHandoff();
 let journey=null;
 const context=gsap.context(()=>{
  if(!enabled){scene?.setProgress(1);return;}
  gsap.from('.intro-copy .line-mask>span',{yPercent:105,duration:1,stagger:.13,ease:'power3.out',clearProps:'transform'});
  if(scene){
   const travel={progress:0};
   journey=gsap.timeline({scrollTrigger:{trigger:'#experience',pin:stage,start:'top top',end:()=>`+=${innerWidth<=650?1400:2400}`,scrub:.45,anticipatePin:1,invalidateOnRefresh:true}});
   journey.to(travel,{progress:1,duration:1,ease:'none',onUpdate:()=>{const state=cinematicState(travel.progress);scene.setProgress(state.cameraProgress);scene.renderer.toneMappingExposure=.85+Math.min(1,state.cameraProgress*5)*.25;scene.invalidate();
    scene.setDashboardCue?.(state.cockpitCueOpacity);
    if(intro){intro.style.opacity=String(state.introOpacity);intro.style.visibility=state.introOpacity<.001?'hidden':'visible';intro.style.transform=`translateY(${-35*(1-state.introOpacity)}px)`;}
    if(handoff){handoff.style.visibility=state.portraitProgress>0?'visible':'hidden';handoff.style.opacity=String(state.portraitProgress);}
    if(handoffImage)handoffImage.style.clipPath=`inset(0 0 0 ${100*(1-state.portraitProgress)}%)`;
    if(handoffCopy)handoffCopy.style.transform=`translateY(${25*(1-state.portraitProgress)}px)`;
    onProgress(state.progress,journeyChapter(state.cameraProgress));}});
  }else{
   gsap.to('.concept',{scale:1.06,yPercent:4,ease:'none',scrollTrigger:{trigger:'#experience',start:'top top',end:'bottom top',scrub:.5}});
  }
  gsap.from('.driver-heading .line-mask>span',{yPercent:105,stagger:.12,duration:1,ease:'power3.out',scrollTrigger:{trigger:'#driver',start:'top 80%',once:true},clearProps:'transform'});
  gsap.from('.driver-portrait',{clipPath:'inset(10% 0 15% 0)',scale:.94,duration:1.1,ease:'power2.out',scrollTrigger:{trigger:'.driver-stage',start:'top 85%',once:true},clearProps:'transform,clipPath'});
  gsap.to('.giant-number',{yPercent:-18,ease:'none',scrollTrigger:{trigger:'#driver',start:'top bottom',end:'bottom top',scrub:.7}});
  for(const item of document.querySelectorAll('.timeline-item'))gsap.from(item,{opacity:.3,y:28,duration:.7,ease:'power2.out',scrollTrigger:{trigger:item,start:'top 90%',once:true},clearProps:'all'});
  for(const figure of document.querySelectorAll('.milestone-photo')){
   gsap.from(figure.querySelector('.milestone-image-mask'),{clipPath:'inset(12% 0 0 0)',duration:1.1,ease:'power3.out',scrollTrigger:{trigger:figure,start:'top 88%',once:true},clearProps:'clipPath'});
   gsap.from(figure.querySelector('img'),{scale:1.045,duration:1.35,ease:'power2.out',scrollTrigger:{trigger:figure,start:'top 88%',once:true},clearProps:'transform'});
  }
  for(const element of document.querySelectorAll('[data-counter]')){
   if(counted.has(element))continue;
   const total=Number(element.dataset.counter),value={n:0};
   gsap.to(value,{n:total,duration:1.25,ease:'power2.out',scrollTrigger:{trigger:element,start:'top 95%',once:true},onStart:()=>counted.add(element),onUpdate:()=>element.textContent=String(Math.round(value.n)),onComplete:()=>element.textContent=String(total)});
  }
 },document.querySelector('main'));
 return ()=>{context.revert();resetHandoff();document.querySelectorAll('[data-counter]').forEach(el=>el.textContent=el.dataset.counter);};
}
export function animationDiagnostics(){return {triggers:ScrollTrigger.getAll().length,pins:document.querySelectorAll('.pin-spacer').length};}
export function refreshAnimations(){ScrollTrigger.refresh();}
