// Blender458 model, normalized to length5.4, grounded and centered, nose+Z.
// Measured: rear wing z[-2.70,-2.17], halo x±.38/y[.34,1.07]/z[-.70,.87],
// steering wheel centre[-.003,.734,.502]. Camera rail clears tyre/body surfaces.
export const JOURNEY_POSES = Object.freeze([
 {at:0,name:'REAR WING / DIFFUSER',position:[.25,.82,-4.05],target:[0,.60,-2.22]},
 {at:.18,name:'REAR BODYWORK',position:[1.55,1.02,-2.50],target:[.15,.65,-1.62]},
 {at:.36,name:'SIDE BODYWORK',position:[1.47,1.02,-.75],target:[.14,.60,-.25]},
 {at:.52,name:'HALO APPROACH',position:[.70,1.60,.13],target:[0,.76,.45]},
 {at:.66,name:'COCKPIT / STEERING WHEEL',position:[.03,1.11,.16],target:[-.003,.734,.502]},
 {at:.72,name:'COCKPIT PULLBACK',position:[1.85,2.10,-1.5],target:[0,.64,.15]},
 {at:1,name:'FULL-CAR REVEAL',position:[4.8,2.8,-7.3],target:[0,.64,0]},
]);
export function journeyPose(progress,mobile=false){
 const t=Math.max(0,Math.min(1,progress));
 let i=JOURNEY_POSES.findIndex((p,index)=>index<JOURNEY_POSES.length-1&&t<=JOURNEY_POSES[index+1].at);
 i=Math.max(0,Math.min(JOURNEY_POSES.length-2,i));
 const a=JOURNEY_POSES[i],b=JOURNEY_POSES[i+1];
 const u=(t-a.at)/(b.at-a.at),smooth=u*u*(3-2*u);
 const mix=(x,y)=>x.map((v,k)=>v+(y[k]-v)*smooth);
 const position=mix(a.position,b.position),target=mix(a.target,b.target);
 // Portrait shots retain detail at the cockpit, then back away for a full silhouette.
 if(mobile){const pull=Math.max(0,(t-.66)/.34),factor=1.22+.98*pull*pull*(3-2*pull);position.forEach((v,k)=>position[k]=target[k]+(v-target[k])*factor);}
 return {position,target};
}
export function journeyChapter(progress){return progress<.25?0:progress<.49?1:progress<.77?2:3;}
