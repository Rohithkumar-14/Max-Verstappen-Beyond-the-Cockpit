# Data sources and snapshot boundaries

Verified/retrieved 26 October 2026. This is a bundled, dated snapshot, **not live data**. No API key, browser scraping, or external data call is required at runtime.

## Roster, teams and numbers

- [Official current driver directory](https://www.formula1.com/en/drivers) and [team directory](https://www.formula1.com/en/teams): the 22 current driver seats and team associations.
- [Official 2026 number confirmation, 6 January 2026](https://www.formula1.com/en/latest/article/all-the-2026-f1-driver-numbers-confirmed-in-full.5rh7o9mPntG7NerzVk9onc): racing numbers, including Norris 1, Verstappen 3, Hadjar 6 and Lindblad 41.
- Current-seat selection is not a claim that only 22 people have raced in the season. Substitutes can appear in the official standings. Short team names are editorial display names, not full sponsored entrant names.

## Individual facts

Each official driver profile below was retrieved and its rendered HTML definition-list statistics parsed. Identity was checked against the profile heading. Nationality comes from the profile identity block. Short original biographies and selected career milestones were written from the same profiles; they are not exhaustive career histories. No publisher portrait was copied.

| Driver | Primary profile source |
| --- | --- |
| Lando Norris | https://www.formula1.com/en/drivers/lando-norris |
| Oscar Piastri | https://www.formula1.com/en/drivers/oscar-piastri |
| George Russell | https://www.formula1.com/en/drivers/george-russell |
| Kimi Antonelli | https://www.formula1.com/en/drivers/kimi-antonelli |
| Max Verstappen | https://www.formula1.com/en/drivers/max-verstappen |
| Isack Hadjar | https://www.formula1.com/en/drivers/isack-hadjar |
| Charles Leclerc | https://www.formula1.com/en/drivers/charles-leclerc |
| Lewis Hamilton | https://www.formula1.com/en/drivers/lewis-hamilton |
| Alexander Albon | https://www.formula1.com/en/drivers/alexander-albon |
| Carlos Sainz | https://www.formula1.com/en/drivers/carlos-sainz |
| Fernando Alonso | https://www.formula1.com/en/drivers/fernando-alonso |
| Lance Stroll | https://www.formula1.com/en/drivers/lance-stroll |
| Pierre Gasly | https://www.formula1.com/en/drivers/pierre-gasly |
| Franco Colapinto | https://www.formula1.com/en/drivers/franco-colapinto |
| Esteban Ocon | https://www.formula1.com/en/drivers/esteban-ocon |
| Oliver Bearman | https://www.formula1.com/en/drivers/oliver-bearman |
| Nico Hulkenberg | https://www.formula1.com/en/drivers/nico-hulkenberg |
| Gabriel Bortoleto | https://www.formula1.com/en/drivers/gabriel-bortoleto |
| Sergio Perez | https://www.formula1.com/en/drivers/sergio-perez |
| Valtteri Bottas | https://www.formula1.com/en/drivers/valtteri-bottas |
| Liam Lawson | https://www.formula1.com/en/drivers/liam-lawson |
| Arvid Lindblad | https://www.formula1.com/en/drivers/arvid-lindblad |

## Field definitions

- `season.year`: 2026. `position` and `points`: official season standings position and total season points, including sprint points.
- `season.wins`, `podiums`, `poles`, `races`: explicitly **Grand Prix** figures, not sprint figures. Each driver's race count is not necessarily the championship's completed-round count.
- `career.championships`, `podiums`, `poles`, `entries`, `points`: official career values. Entries are **Grands Prix entered**, not race starts.
- `career.wins`: extracted from “Highest Race Finish: 1 (xN)”. A verified best finish below first yields zero wins; an unreadable value would yield null.
- `history`: selected milestones with year or contextual labels. No implied full year-by-year team history.
- `raceResults`: parsed from each official 2026 “Full season results” page; the exact `resultsUrl` is stored on each driver. Fields are Grand Prix, date, team, race position (including DNF/DNS labels), and weekend points. **The publisher’s Pts column includes Sprint points**, so do not label these race-only points. For example Hamilton’s China row is race position 3 and 21 weekend points. Empty results, if encountered, mean unavailable local data, not proof that no races occurred.
- Teammate comparisons may compare sourced season totals for the two current team drivers. This is **not** a qualifying or race head-to-head comparison; team changes and missed races affect comparability.
- Null means unverified/unavailable. Verified zeros remain zeros. Numeric data is separated from UI in `src/data/drivers.json`.

## Source limitations and observed discrepancies

All individual profiles currently show the 2026 season. Snapshot retrieval is not a guarantee that every publisher page updated simultaneously. No live or comprehensive results API is integrated. The dataset intentionally retains publisher values rather than guessing corrections.

- Sergio Perez is listed 23rd and Valtteri Bottas 22nd in the season standings despite a current grid of 22 seats; substitutions can increase the season's driver count.
- Isack Hadjar's official profile reports 15 Grand Prix races for 2026; do not replace this with 18 merely because other drivers have 18.
- Arvid Lindblad's official profile reports 18 season Grands Prix but 17 career Grands Prix entered. This internal publisher inconsistency is unresolved. Avoid presenting a derived reconciliation or treating this as locally verified race-by-race history.

- The 22 official results pages yielded 383 rows. Some profiles report 18 races while their linked results tables contain 17 rows. Leclerc (table 215 vs profile 233), Gasly (41 vs 42), and Lawson (75 vs 77) also have points-total differences. The profiles expose these limitations via `sourceNotes`; tables must be labelled a potentially incomplete dated snapshot, not reconciled standings.
- Summing weekend points matches the profile season points for the other 19 drivers. This is a consistency check, not independent verification of each classification.

## Refresh procedure

`python scripts/refresh-data.py` fetches the official profiles using Python's standard library. Review the diff, verify the current roster/team assignments/numbers, update the snapshot date, resolve source errors where possible, and rerun site tests before publishing. The script deliberately does not auto-publish or replace biography/history copy. The roster/date in the script are explicit review points, not a claim of automatic freshness. Source layout changes fail rather than silently inventing data.

## Current Max-only presentation
The27October2026 product direction features Max exclusively and retains the26October2026 snapshot. Added timeline facts(2015debut,2016RedBulldebut win,2021first title,2023nineteen wins,2024fourth consecutive title) are supported by his official biography. The preserved multi-driver dataset is archival/reusable; it does not imply the current page offers multi-driver navigation.

## Max season archive — verified 31 October 2026

`src/data/max-seasons.json` contains every season 2015–2026 (251 GP rows). Each season has its official Formula 1 driver-results and final/current driver-standings URLs, a verification date and a Jolpica structured-record URL. Retrieved official rows plus structured race evidence are in `docs/evidence/seasons/{year}.json`.

- Official championship position/points: the Max row of the season driver standings.
- Teams, GP wins and podiums: official driver results (race position 1 / 1–3). Both Toro Rosso and Red Bull are retained in 2016.
- Race starts: structured results excluding DNS/withdrawn/non-qualifying statuses; entries are retained separately. A DNF is still a start. No zero is substituted for an unavailable field.
- Grand Prix points: structured result `points`; weekend points: official driver's result table, including Sprint points where applicable. They are separate columns. The 2021 Belgian GP uses the official reduced points, not a fabricated normal score.
- Poles: recorded GP grid P1s. Counts sum to the official profile career pole total (50); 2023 (12) and 2024 (8) also match Formula 1's end-of-season reports. Sprint pole positions are not added separately. This metric is not a count of Friday qualifying session P1s in every historical Sprint format.
- Cumulative championship stars: completed season standings with championship position 1, accumulated through the selected year. No extra star for 2025 or an incomplete 2026. The official profile confirms four championships.
- Las Vegas official local date can be one day before the structured archive's UTC race date; joins follow the verified chronological race list, retaining Formula 1's local date.
- Season sums reconcile to the preserved official profile snapshot: 73 wins, 137 podiums, 50 poles, 3680.5 points. The archive is a static snapshot, not an API-powered live feed. 2026 remains incomplete.
- Optional `scripts/refresh-max-seasons.py` uses Python's standard library; review sourced data and rerun tests before publishing refreshed snapshots.

Official corroboration: https://www.formula1.com/en/drivers/max-verstappen ; https://www.formula1.com/en/latest/article/end-of-year-report-dominance-from-start-to-finish-as-red-bull-and-verstappen.1UJg61FM0B4pjdmp4ly30a ; https://www.formula1.com/en/latest/article/in-numbers-the-incredible-statistics-behind-verstappens-fourth-consecutive.3RcrhpEkYySfq7YydKbDQM .
