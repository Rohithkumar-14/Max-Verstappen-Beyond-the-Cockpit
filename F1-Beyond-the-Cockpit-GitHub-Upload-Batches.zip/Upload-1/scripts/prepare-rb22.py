"""Prepare the supplied CC BY 4.0 GLB; requires Pillow and NumPy.

Usage: python scripts/prepare-rb22.py /path/to/2026-redbull-rb22.zip
Positions, topology, UVs and livery assignments are retained. Only normal storage
and embedded texture sizes/encoding change. No network or external decoder.
"""
import copy
import hashlib
import io
import json
from pathlib import Path
import struct
import sys
import zipfile
import numpy as np
from PIL import Image

root = Path(__file__).resolve().parents[1]
with zipfile.ZipFile(sys.argv[1]) as archive:
    source = archive.read('source/untitled.glb')
size = struct.unpack_from('<I', source, 12)[0]
original = json.loads(source[20:20 + size])
binary = source[28 + size:]
normal_accessors = {p['attributes']['NORMAL'] for m in original['meshes'] for p in m['primitives']}
normal_images = {original['textures'][m['normalTexture']['index']]['source'] for m in original['materials'] if 'normalTexture' in m}
source_hash = hashlib.sha256(source).hexdigest()
assert source_hash == '16eee6365ce3d77d4e69e5c60a596cbb39b2517461842df9e1fbc3e529f9c71d', 'Unexpected source GLB'
outputs = []

for mobile in [False, True]:
    doc = copy.deepcopy(original)
    replacements = {}
    # Int8 normalized vertex normals with 4-byte stride: no position changes.
    for index in normal_accessors:
        accessor = doc['accessors'][index]
        view = doc['bufferViews'][accessor['bufferView']]
        assert accessor['componentType'] == 5126 and accessor.get('byteOffset', 0) == 0
        values = np.frombuffer(binary, '<f4', accessor['count'] * 3, view.get('byteOffset', 0)).reshape(-1, 3)
        packed = np.zeros((accessor['count'], 4), dtype=np.int8)
        packed[:, :3] = np.rint(np.clip(values, -1, 1) * 127).astype(np.int8)
        replacements[accessor['bufferView']] = packed.tobytes()
        view['byteStride'] = 4
        accessor.update(componentType=5120, normalized=True)
        accessor.pop('min', None)
        accessor.pop('max', None)

    images = []
    for index, image in enumerate(doc['images']):
        view = doc['bufferViews'][image['bufferView']]
        data = binary[view.get('byteOffset', 0):view.get('byteOffset', 0) + view['byteLength']]
        picture = Image.open(io.BytesIO(data)).convert('RGBA')
        if index in normal_images:
            limit = 512 if mobile else 1024
        elif any(word in image['name'] for word in ['paint', 'decal', 'wheel', 'S.png']):
            limit = 1024 if mobile else 2048
        else:
            limit = 512 if mobile else 1024
        picture.thumbnail((limit, limit), Image.Resampling.LANCZOS)
        output = io.BytesIO()
        if index in normal_images:
            picture.save(output, 'PNG', optimize=True)
            image['mimeType'] = 'image/png'
        else:
            picture.save(output, 'WEBP', quality=90 if mobile else 94, method=6, exact=True)
            image['mimeType'] = 'image/webp'
        replacements[image['bufferView']] = output.getvalue()
        images.append({'name': image['name'], 'width': picture.width, 'height': picture.height, 'bytes': len(output.getvalue())})

    for texture in doc['textures']:
        index = texture['source']
        if doc['images'][index]['mimeType'] == 'image/webp':
            texture.pop('source')
            texture.setdefault('extensions', {})['EXT_texture_webp'] = {'source': index}
    doc['extensionsUsed'] = sorted(set(doc.get('extensionsUsed', []) + ['EXT_texture_webp', 'KHR_mesh_quantization']))
    doc['extensionsRequired'] = ['EXT_texture_webp', 'KHR_mesh_quantization']
    doc['asset']['copyright'] = '2026 Redbull RB22 by Dave Love SketchFab (@Tyler_Dave), CC BY 4.0. Adapted: texture optimization, normal quantization.'
    doc['asset']['extras'] = {'source': 'https://sketchfab.com/3d-models/2026-redbull-rb22-0a3d24a58e0549d591a5a48c22eec383', 'license': 'https://creativecommons.org/licenses/by/4.0/'}

    chunks = bytearray()
    for index, view in enumerate(doc['bufferViews']):
        chunks.extend(b'\0' * (-len(chunks) % 4))
        data = replacements.get(index)
        if data is None:
            previous = original['bufferViews'][index]
            start = previous.get('byteOffset', 0)
            data = binary[start:start + previous['byteLength']]
        view['byteOffset'] = len(chunks)
        view['byteLength'] = len(data)
        chunks.extend(data)
    chunks.extend(b'\0' * (-len(chunks) % 4))
    doc['buffers'][0]['byteLength'] = len(chunks)
    header = json.dumps(doc, separators=(',', ':')).encode()
    header += b' ' * (-len(header) % 4)
    result = struct.pack('<III', 0x46546C67, 2, 28 + len(header) + len(chunks)) + struct.pack('<II', len(header), 0x4E4F534A) + header + struct.pack('<II', len(chunks), 0x004E4942) + chunks
    filename = f"redbull-rb22-{'mobile' if mobile else 'desktop'}.glb"
    (root / 'public/models' / filename).write_bytes(result)
    outputs.append({'file': filename, 'bytes': len(result), 'sha256': hashlib.sha256(result).hexdigest(), 'images': images})
    print(filename, len(result), 'bytes')

(root / 'docs/evidence/rb22-optimized.json').write_text(json.dumps({'sourceBytes': len(source), 'sourceSha256': source_hash, 'triangles': 281075, 'outputs': outputs}, indent=2) + '\n')
