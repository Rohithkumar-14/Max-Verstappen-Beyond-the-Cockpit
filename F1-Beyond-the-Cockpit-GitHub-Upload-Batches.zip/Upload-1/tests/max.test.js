import test from 'node:test';
import assert from 'node:assert/strict';
import {journeyPose,journeyChapter,JOURNEY_POSES} from '../src/max/cameraPath.js';
import {max,selectResults,milestones} from '../src/max/content.js';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
test('owner-supplied career photos map to their years and match bundled asset bytes',()=>{
 const evidence=JSON.parse(readFileSync(new URL('../docs/evidence/milestone-images.json',import.meta.url)));
 assert.deepEqual(milestones.filter(m=>m.image).map(m=>m.year),['2015','2016','2021','2023','2024']);
 assert.ok(milestones.find(m=>m.year==='2015').image);
 for(const item of milestones.filter(m=>m.image)){
  const record=evidence.find(r=>r.year===item.year),bytes=readFileSync(new URL(`../public${item.image.src}`,import.meta.url));
  assert.equal(record.file,item.image.src);assert.equal(createHash('sha256').update(bytes).digest('hex'),record.sha256);
  assert.equal(item.image.width,record.width);assert.equal(item.image.height,record.height);
 }
});
test('Max-only content uses the existing verified snapshot and result filters',()=>{assert.equal(max.id,'max-verstappen');assert.equal(max.team,'Red Bull Racing');assert.equal(max.number,3);assert.equal(max.raceResults.length,18);assert.equal(new Set(max.raceResults.map(r=>r.grandPrix)).size,18);assert.equal(selectResults(max.raceResults,'win').length,2);assert.equal(selectResults(max.raceResults,'podium').length,10);assert.equal(selectResults(max.raceResults,'dnf').length,4);assert.equal(max.raceResults.reduce((sum,r)=>sum+r.points,0),max.season.points);});
for(const mobile of [false,true])test(`model-specific camera is continuous and reversible; mobile=${mobile}`,()=>{let previous=journeyPose(0,mobile);for(let i=0;i<=1000;i++){const p=i/1000,pose=journeyPose(p,mobile);assert.ok(pose.position.every(Number.isFinite));const [,y]=pose.position;// Camera may enter the open cockpit; actual mesh-crossing checks live in cinematic-car.test.js.
 assert.ok(y>.7);assert.ok(Math.hypot(...pose.position.map((v,k)=>v-previous.position[k]))<.1);assert.deepEqual(pose,journeyPose(p,mobile));previous=pose;}for(const key of JOURNEY_POSES){const before=journeyPose(key.at-.00001,mobile),after=journeyPose(key.at+.00001,mobile);assert.ok(Math.hypot(...before.position.map((v,k)=>v-after.position[k]))<.001);}assert.deepEqual(journeyPose(-1,mobile),journeyPose(0,mobile));assert.deepEqual(journeyPose(2,mobile),journeyPose(1,mobile));});
test('chapter labels derive from progress in either scroll direction',()=>{assert.equal(journeyChapter(0),0);assert.equal(journeyChapter(.4),1);assert.equal(journeyChapter(.7),2);assert.equal(journeyChapter(1),3);assert.equal(journeyChapter(.4),1);});
test('full-car endpoint fits representative desktop and mobile camera frusta',async()=>{
 const {PerspectiveCamera,Vector3}=await import('three');
 for(const [width,height] of [[1440,900],[390,844],[320,740],[844,390],[768,1024]]){
  const pose=journeyPose(1,width/height<.9),camera=new PerspectiveCamera(38,width/height,.1,60);camera.position.fromArray(pose.position);camera.lookAt(new Vector3(...pose.target));camera.updateMatrixWorld(true);
  for(const x of [-1.08,1.08])for(const y of [0,1.31])for(const z of [-2.7,2.7]){const point=new Vector3(x,y,z).project(camera);assert.ok(Math.abs(point.x)<1&&Math.abs(point.y)<1,`${width}x${height} clips full-car endpoint`);}
 }
});
