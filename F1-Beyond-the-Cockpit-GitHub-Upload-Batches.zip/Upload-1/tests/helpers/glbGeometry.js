// Geometry-only test adapter: Node has no browser image decoder. Leave vertex,
// index, UV, node-transform and buffer bytes intact; omit texture references.
export function geometryOnlyGLB(bytes){
 const length=bytes.readUInt32LE(12),document=JSON.parse(bytes.subarray(20,20+length));
 function strip(value){if(!value||typeof value!=='object')return;for(const key of Object.keys(value)){if(key.endsWith('Texture'))delete value[key];else strip(value[key]);}}
 for(const material of document.materials)strip(material);
 document.images=[];document.textures=[];document.extensionsRequired=document.extensionsRequired.filter(x=>x!=='EXT_texture_webp');
 const header=Buffer.from(JSON.stringify(document)),padding=Buffer.alloc((4-header.length%4)%4,32),binary=bytes.subarray(28+length);
 const result=Buffer.alloc(28+header.length+padding.length+binary.length);result.writeUInt32LE(0x46546c67,0);result.writeUInt32LE(2,4);result.writeUInt32LE(result.length,8);result.writeUInt32LE(header.length+padding.length,12);result.writeUInt32LE(0x4e4f534a,16);header.copy(result,20);padding.copy(result,20+header.length);result.writeUInt32LE(binary.length,20+header.length+padding.length);result.writeUInt32LE(0x004e4942,24+header.length+padding.length);binary.copy(result,28+header.length+padding.length);
 return result;
}
