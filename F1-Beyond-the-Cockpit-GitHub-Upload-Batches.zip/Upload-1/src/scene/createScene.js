import { ACESFilmicToneMapping, Box3, BoxGeometry, CanvasTexture, Color, FogExp2, Mesh, MeshBasicMaterial, MeshStandardMaterial, PerspectiveCamera, PlaneGeometry, PMREMGenerator, Scene, SRGBColorSpace, Vector3, WebGLRenderer, TextureLoader } from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { addLighting } from './lighting.js';
import { disposeObject } from './loadCar.js';
import { cameraLayout, interpolatePose } from './cameraConfig.js';
import { framePose } from './framing.js';
import {createGarageWall,WALL_LOGO_URL} from './garageWall.js';

export function createScene(container, { simulateFailure = false, onContextLost, poseProvider, fitWholeCar = true, brandedGarage = false } = {}) {
  if (simulateFailure) throw new Error('WebGL failure deliberately injected for QA.');
  const renderCanvas = document.createElement('canvas');
  const context = renderCanvas.getContext('webgl2', { antialias: true, alpha: false, powerPreference: 'low-power' });
  if (!context) throw new Error('WebGL 2 is not available in this browser.');
  const renderer = new WebGLRenderer({ canvas: renderCanvas, context, antialias: true, alpha: false });
  renderer.outputColorSpace = SRGBColorSpace;
  renderer.toneMapping = ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.1;
  renderer.setClearColor('#080c10');
  renderer.domElement.setAttribute('aria-hidden', 'true');
  container.append(renderer.domElement);
  const scene = new Scene();
  scene.background = new Color('#080c10'); scene.fog = new FogExp2('#080c10', 0.035);
  const camera = new PerspectiveCamera(38, 1, 0.1, 60);
  const pmrem = new PMREMGenerator(renderer);
  const room = new RoomEnvironment();
  const environment = pmrem.fromScene(room, 0.04);
  scene.environment = environment.texture;
  room.dispose(); pmrem.dispose();
  addLighting(scene);
  const floor = new Mesh(new PlaneGeometry(100, 100), new MeshStandardMaterial({ color: '#151c22', metalness: 0.35, roughness: 0.42 }));
  floor.rotation.x = -Math.PI / 2; floor.position.y = -0.025; scene.add(floor);
  const architecture=brandedGarage?createGarageWall():null;
  if(architecture)scene.add(architecture.group);
  else{
    const wall = new Mesh(new BoxGeometry(18, 6, 0.1), new MeshStandardMaterial({ color: '#131b24', roughness: 0.9 }));
    wall.position.set(0, 3, 7.2); scene.add(wall);
  }
  for (let x = -12; x <= 12; x += 3) {
    const seam = new Mesh(new BoxGeometry(0.009, 0.002, 45), new MeshBasicMaterial({ color: '#27333b' }));
    seam.position.set(x, -0.02, 0); scene.add(seam);
  }
  const canvas = document.createElement('canvas'); canvas.width = canvas.height = 128;
  const ctx = canvas.getContext('2d');
  const gradient = ctx.createRadialGradient(64, 64, 10, 64, 64, 64);
  gradient.addColorStop(0, 'rgba(0,0,0,.85)'); gradient.addColorStop(0.6, 'rgba(0,0,0,.45)'); gradient.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = gradient; ctx.fillRect(0, 0, 128, 128);
  const shadow = new Mesh(new PlaneGeometry(3.6, 7.4), new MeshBasicMaterial({ map: new CanvasTexture(canvas), transparent: true, depthWrite: false }));
  shadow.rotation.x = -Math.PI / 2; shadow.position.y = -0.01; scene.add(shadow);
  let progress = 0; let frame = null; let disposed = false; let visible = true;
  const target = new Vector3();
  let carBounds = null; let dashboard = null;
  function render() {
    frame = null;
    if (disposed || !visible || document.hidden) return;
    renderer.render(scene, camera);
  }
  function invalidate() { if (!disposed && frame === null) frame = requestAnimationFrame(render); }
  function setProgress(value) {
    progress = Math.max(0, Math.min(1, value));
    const aspect = container.clientWidth / Math.max(1, container.clientHeight);
    const pose = poseProvider ? poseProvider(progress, aspect < .9, aspect) : interpolatePose(cameraLayout(container.clientWidth), progress);
    camera.position.fromArray(pose.position); target.fromArray(pose.target); camera.lookAt(target);
    if (carBounds && fitWholeCar) framePose(camera, target, carBounds);
    invalidate();
  }
  function resize() {
    const width = container.clientWidth; const height = container.clientHeight;
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, width <= 600 ? 1.25 : 1.5));
    renderer.setSize(width, height, false); camera.aspect = width / Math.max(1, height);
    camera.updateProjectionMatrix(); setProgress(progress);
  }
  const resizeObserver = new ResizeObserver(resize); resizeObserver.observe(container);
  const intersectionObserver = new IntersectionObserver(([entry]) => { visible = entry.isIntersecting; if (visible) invalidate(); });
  intersectionObserver.observe(container);
  const onVisibility = () => { if (!document.hidden) invalidate(); };
  document.addEventListener('visibilitychange', onVisibility);
  const onLost = (event) => { event.preventDefault(); onContextLost?.(); };
  renderer.domElement.addEventListener('webglcontextlost', onLost);
  resize();
  if(architecture){
    const texture=new TextureLoader().load(WALL_LOGO_URL,loaded=>{
      if(disposed){loaded.dispose();return;}
      loaded.colorSpace=SRGBColorSpace;loaded.anisotropy=2;
      architecture.setLogo(loaded);invalidate();
    },undefined,error=>{
      if(!disposed)console.warn('[Garage] Wall logo unavailable; framed architecture retained.',error?.message??'Image request failed.');
    });
    // Attach pending texture so normal scene cleanup also covers an in-flight request.
    architecture.logo.material.map=texture;
  }
  return {
    scene, camera, renderer, setProgress, invalidate,
    setCar(car, options = {}) { scene.add(car); dashboard = options.dashboard ?? null; carBounds = new Box3().setFromObject(car); setProgress(progress); },
    setDashboardCue(opacity) { dashboard?.setOpacity(opacity); invalidate(); },
    get progress() { return progress; },
    dispose() {
      if (disposed) return;
      disposed = true;
      if (frame !== null) cancelAnimationFrame(frame);
      resizeObserver.disconnect(); intersectionObserver.disconnect();
      document.removeEventListener('visibilitychange', onVisibility);
      renderer.domElement.removeEventListener('webglcontextlost', onLost);
      disposeObject(scene); environment.dispose(); renderer.dispose();
      renderer.forceContextLoss(); renderer.domElement.remove();
    },
  };
}
