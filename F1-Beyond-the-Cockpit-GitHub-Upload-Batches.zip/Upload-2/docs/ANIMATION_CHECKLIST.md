# Animation checklist — Max-only direction

Updated27October2026. Current product supersedes the22-driver primary UI; archive/source preserved. Checkpoint before substantial changes: e5d604c.

| Sequence | Implemented behavior | Dependencies/fallback | Verification boundary |
| --- | --- | --- | --- |
| Opening | Masked heading; controlled exposure emerges during camera progress | Blender458 medium-detail CC BY4.0 GLB; labelled original concept image if unavailable | Opening/fallback visually inspected; GPU lighting not verified |
| Rear → bodywork | One normalized, pinned/scrubbed camera timeline | Seven model-specific pose arrays; car stationary | Math continuity/clearance tests pass; actual ScrollTrigger progress checked in DOM harness |
| Cockpit approach | View aimed into the actual modeled cockpit | Modeled wheel/screen/dials; medium-detail trim; no seated Max model | Implemented camera pose only; no rendered cockpit claim |
| Full-car pullback | Smooth pullback; extra portrait-aspect distance | Responsive perspective camera | Endpoint frustum tests pass for five aspect ratios; no GPU visual pass |
| Transition to Max | Scene releases into adjoining oversized name and masked portrait section | Authentic local historical Max image; initials on failure | Portrait loaded and visual crop inspected; fallback/skip path tested |
| Name/portrait reveal | Clipped line movement, restrained image mask/scale | Disabled with static/reduced motion | Browser reveal observed; settled layouts inspected |
| Career | Progressive line markers and milestone entrances | Always-present semantic text | Content/layout inspected; no physical-device motion/FPS measurement |
| Counters | Once-on-entry count-up; final values remain accessible; cleanup restores totals | Final values immediate in reduced/static mode | See test log for actual observed browser tests |
| Results | Working all/podium/wins/DNF filter | Bundled dated table, sources visible | Data/filter tests and browser counts checked |
| Navigation | Section anchors, skip focus, active section indicator | No animation required | Browser section navigation and skip checked |
| Closing | Reused original artwork and return-to-start link | Static image/background | Composition inspected; no copied reference assets |

## Reference study
https://landonorris.com/ was inspected through retrieved page content and the browser. Observable ideas: large driver typography, compact navigation, track/off-track editorial progression, image-led hierarchy and a clear driver identity. Its immersive first view did not fully render in this cloud browser, so no claim of complete reference motion analysis. No source code or proprietary imagery copied. Original navy/red treatment and Max content were implemented locally.

## Resource/accessibility strategy
Three.js is dynamically imported. Pixel ratio caps, demand rendering, visibility pause, local compact assets, no heavy postprocessing and deterministic camera calculations remain. One GSAP context owns/cleans each animation setup. Skip and static/reduced-motion modes remove the long pin. Actual OS-level reduced motion and real GPU/device performance require external verification.

## Focused car/camera revision — 27 October 2026
- Main model replaced with the inspected Blender4582022-inspired CC BY4.0GLB; medium detail, genuine modeled cockpit/wheel, not photorealistic. Original asset remains in the preserved garage.
- Rear close-up→rear-quarter rail→forward side-body travel→above-halo approach→actual steering-wheel target→full-car pullback. Seven model-specific poses; portrait-aspect pullback checked mathematically.
- Complete car reached at normalized sequence progress.82 and held. Portrait stays hidden through.88, then masks into the same pinned frame. Intro copy exits early to expose close geometry. Portal uses the same licensed Max image and navy background as the next driver section; no extra likeness or asset invented.
- Camera+portrait states derive from current progress; reverse scrolling restores the mask and car state. Context cleanup resets styles. Existing skip/reduced-motion paths bypass the long pin.
- Actual-triangle segment tests and cockpit sightline tests pass. Browser DOM-controller mask/progression checks pass. **Real WebGL visual stage checks remain BLOCKED**: renderer creation returns noWebGL2 in available cloudChrome. None of the opening/body/cockpit/full-car stages is marked visually verified.
- `/qa/car-review.html` is a dev-only actual-render review page with Opening/Bodywork/Cockpit/Fullcar buttons and a continuous path slider. It disables controls on WebGL failure. Use a WebGL2-capable physical browser for the outstanding four captures.


## RB22 update — 28 October 2026
- Primary car now uses the supplied textured RB22; generic camera rail retained in `src/max/genericCameraPath.js` only for historical tests.
- Camera nodes: low rear wing/diffuser → rear three-quarter → side bodywork → halo → over cockpit → LCD close-up → LCD hold → pullback → complete car. Camera .64–.72 holds on the actual display. Message fades in .58–.64, holds through .68, fades out by .73, with the same pure reversible sequence state.
- Full car is reached at overall .82; portrait begins after .88. Existing same-frame handoff, stats, timeline, results, skip and reduced-motion controls retained.
- Mathematical real-mesh camera travel, LCD sightline, readable text orientation, phone screen bounds and full-car bounds checked by tests. Full desktop/mobile GLBs and all 26 textures decoded in the browser without a GPU.
- Actual WebGL still blocked in the available browser. Opening/bodywork/cockpit/full-car GPU appearance, texture/material lighting, real GPU smoothness, mobile FPS and thermal behavior remain unverified. Neither the creator's preview nor the dashboard texture canvas is a rendered-stage capture.

## 31 October mobile and editorial update

- Desktop pose arrays and dashboard hold unchanged. Mobile rear/flank distances increased; cockpit remains on the original clear route. The first new mobile envelope failed collision/speed checks; corrected before release.
- Header and bottom HUD occupy reserved mobile drawing space. Ready-state loading/status text is hidden; credits, chapter label and skip remain grouped. Phone landscape uses a shorter header/HUD. `100svh` avoids browser-toolbar clipping and resize observers recalculate aspect.
- The actual car mesh/frustum tests establish geometric clearance and full-car margins; they do not establish GPU lighting or perceived shot quality.
- New logo uses CSS glow and occasional three-point glitter. Season panel has a short native opacity/position transition. Reduced-motion and motion-off modes disable decorative animations.
- Real WebGL2 stages still need a compatible GPU browser/physical phone review. No GPU stage screenshot should be claimed from this environment.

### Achievements sticky-background revision
The complete chapter has an absolutely positioned backdrop track and a viewport-height sticky child. `overflow: clip` confines it without introducing a new scroll container. The lion stays behind content through all five milestones and releases with the chapter. Logo opacity pulses slowly; six small radial points vary gently as glitter. Reduced motion/motion-off keeps a static glow. New garage sign is static world architecture, not a HUD overlay; no camera poses were changed. Real GPU sign appearance remains dependent on a WebGL2-capable review.
