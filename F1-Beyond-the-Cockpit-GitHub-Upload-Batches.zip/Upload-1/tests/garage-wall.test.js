import test from 'node:test';
import assert from 'node:assert/strict';
import {Box3,DataTexture,Vector3} from 'three';
import {readFileSync} from 'node:fs';
import {createHash} from 'node:crypto';
import {createGarageWall,WALL_LOGO_ASPECT} from '../src/scene/garageWall.js';
import {disposeObject} from '../src/scene/loadCar.js';
import {maxPortrait} from '../src/max/content.js';
test('physical garage sign preserves logo aspect, depth and clears the complete car area',()=>{
 const wall=createGarageWall();wall.group.updateMatrixWorld(true);
 assert.ok(wall.group.children.length<30);assert.ok(wall.group.getObjectByName('recess-surround'));assert.ok(wall.group.getObjectByName('sign-face'));assert.ok(wall.group.getObjectByName('mounting-cap'));
 const bounds=new Box3().setFromObject(wall.group);assert.ok(bounds.min.z>6.5);
 assert.ok(Math.abs(wall.logo.geometry.parameters.width/wall.logo.geometry.parameters.height-WALL_LOGO_ASPECT)<1e-8);
 assert.equal(wall.logo.material.depthTest,true);assert.equal(wall.logo.material.toneMapped,false);
 assert.equal(wall.logo.visible,false);wall.setLogo(new DataTexture());assert.equal(wall.logo.visible,true);
 const normal=new Vector3(0,0,1).transformDirection(wall.logo.matrixWorld);assert.ok(normal.z<-.99);
 wall.group.traverse(node=>{if(node.isMesh){assert.equal(node.castShadow,false);assert.equal(node.receiveShadow,false);}});disposeObject(wall.group);
});
test('supplied wall/portrait assets and local font licences match recorded evidence',()=>{
 for(const file of ['review-assets.json','typography-fonts.json']){
  const rows=JSON.parse(readFileSync(new URL('../docs/evidence/'+file,import.meta.url)));
  for(const row of rows){const bytes=readFileSync(new URL('../public'+row.file,import.meta.url));assert.equal(bytes.length,row.bytes);assert.equal(createHash('sha256').update(bytes).digest('hex'),row.sha256);}
 }
 assert.equal(maxPortrait.src,'/portraits/max-white-suit.webp');
});
