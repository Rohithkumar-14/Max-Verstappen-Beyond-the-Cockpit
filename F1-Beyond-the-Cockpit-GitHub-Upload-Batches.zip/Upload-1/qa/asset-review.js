import {Vector3} from 'three';
import {loadCar,disposeObject} from '/src/scene/loadCar.js';
import {REDBULL_DESKTOP,REDBULL_MOBILE,finishRedBullMaterial} from '/src/scene/carAsset.js';
import {attachDashboard} from '/src/scene/dashboard.js';
const report=document.querySelector('#report'),query=new URLSearchParams(location.search);
const asset=query.get('budget')==='mobile'?REDBULL_MOBILE:REDBULL_DESKTOP;
let car;
try{
 car=await loadCar({asset,finishMaterial:finishRedBullMaterial,onProgress:(loaded,total)=>report.textContent=`${asset.budget}: ${loaded} / ${total??'?'} bytes`});
 const materials=new Set(),textures=new Set();let triangles=0,meshes=0;
 car.traverse(node=>{if(!node.isMesh)return;meshes++;triangles+=(node.geometry.index?.count??node.geometry.attributes.position.count)/3;materials.add(node.material);for(const item of Object.values(node.material))if(item?.isTexture)textures.add(item);});
 const dashboard=attachDashboard(car);dashboard.setOpacity(1);car.updateMatrixWorld(true);
 document.querySelector('#texture').append(dashboard.panel.material.map.image);
 report.textContent=JSON.stringify({status:'Decoded successfully — no GPU render claimed',budget:asset.budget,meshes,triangles,materials:materials.size,textures:textures.size,decodedImages:[...textures].map(t=>({name:t.name,width:t.image.width,height:t.image.height})),dashboardParent:dashboard.screen.material.name,dashboardPosition:dashboard.panel.getWorldPosition(new Vector3()).toArray()},null,2);
}catch(error){report.textContent=`FAILED: ${error.message}`;console.error(error);}
window.addEventListener('pagehide',()=>{if(car)disposeObject(car);});
