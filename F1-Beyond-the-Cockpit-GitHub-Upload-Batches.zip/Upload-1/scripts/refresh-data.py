"""Fetch factual F1 profile snapshots; no images or publisher prose are copied.
Run manually, review all changed values before publication. Python standard library only.
"""
import concurrent.futures, html, json, pathlib, re, urllib.request
ROOT = pathlib.Path(__file__).resolve().parents[1]
DATE = '2026-10-26'
ROSTER = [
('lando-norris','Lando Norris',1,'McLaren'),('oscar-piastri','Oscar Piastri',81,'McLaren'),
('george-russell','George Russell',63,'Mercedes'),('kimi-antonelli','Kimi Antonelli',12,'Mercedes'),
('max-verstappen','Max Verstappen',3,'Red Bull Racing'),('isack-hadjar','Isack Hadjar',6,'Red Bull Racing'),
('charles-leclerc','Charles Leclerc',16,'Ferrari'),('lewis-hamilton','Lewis Hamilton',44,'Ferrari'),
('alexander-albon','Alexander Albon',23,'Williams'),('carlos-sainz','Carlos Sainz',55,'Williams'),
('fernando-alonso','Fernando Alonso',14,'Aston Martin'),('lance-stroll','Lance Stroll',18,'Aston Martin'),
('pierre-gasly','Pierre Gasly',10,'Alpine'),('franco-colapinto','Franco Colapinto',43,'Alpine'),
('esteban-ocon','Esteban Ocon',31,'Haas F1 Team'),('oliver-bearman','Oliver Bearman',87,'Haas F1 Team'),
('nico-hulkenberg','Nico Hulkenberg',27,'Audi'),('gabriel-bortoleto','Gabriel Bortoleto',5,'Audi'),
('sergio-perez','Sergio Perez',11,'Cadillac'),('valtteri-bottas','Valtteri Bottas',77,'Cadillac'),
('liam-lawson','Liam Lawson',30,'Racing Bulls'),('arvid-lindblad','Arvid Lindblad',41,'Racing Bulls')]
def clean(s):
 return re.sub(r'\s+', ' ', html.unescape(re.sub('<[^>]+>', ' ', s))).strip()
def fetch(row):
 id,name,number,team = row
 url = 'https://www.formula1.com/en/drivers/' + id
 req = urllib.request.Request(url, headers={'User-Agent':'BeyondTheCockpit student research'})
 s = urllib.request.urlopen(req, timeout=45).read().decode()
 title = clean(re.search(r'<h1\b[^>]*>(.*?)</h1>', s, re.S).group(1))
 assert name.split()[-1].lower() in title.lower(), (id,title)
 values = {clean(k):clean(v) for k,v in re.findall(r'<dt\b[^>]*>(.*?)</dt>\s*<dd\b[^>]*>(.*?)</dd>',s,re.S)}
 def num(key):
  val=values.get(key,''); m=re.fullmatch(r'(\d+(?:\.\d+)?)(?:st|nd|rd|th)?',val)
  return float(m[1]) if m and '.' in m[1] else int(m[1]) if m else None
 finish=values.get('Highest Race Finish',''); m=re.fullmatch(r'1 \(x(\d+)\)',finish)
 wins=int(m[1]) if m else 0 if re.match(r'\d+ \(x\d+\)',finish) else None
 plain=clean(re.sub(r'<script\b.*?</script>','',s,flags=re.S))
 bio=plain.split('Place of Birth',1)[-1].split('Related Videos',1)[0]
 pathlib.Path('/tmp/f1-bios').mkdir(exist_ok=True)
 pathlib.Path('/tmp/f1-bios',id+'.txt').write_text(bio)
 header=clean(s[s.find('<h1'):s.find('Shop now',s.find('<h1'))])
 match=re.search(r'Flag of .*? (United Kingdom|Netherlands|Australia|Italy|France|Monaco|Thailand|Spain|Canada|Argentina|Germany|Brazil|Mexico|Finland|New Zealand) ',header)
 nationality=match[1] if match else None
 d={'id':id,'fullName':name,'number':number,'team':team,'nationality':nationality,'sourceUrl':url,'verifiedAt':DATE,
 'bio':'','career':{'championships':num('World Championships'),'wins':wins,'podiums':num('Podiums'),'poles':num('Pole Positions'),'entries':num('Grands Prix Entered'),'points':num('Career Points')},
 'season':{'year':2026,'position':num('Season Position'),'points':num('Season Points'),'wins':num('Grand Prix Wins'),'podiums':num('Grand Prix Podiums'),'poles':num('Grand Prix Poles'),'races':num('Grand Prix Races')},'history':[],'raceResults':[]}
 links = re.findall(r'<a\b[^>]*href="([^"]+)"[^>]*>(.*?)</a>',s,re.S)
 result = next((href for href,label in links if 'Full season results' in clean(label)),None)
 d['resultsUrl'] = ('https://www.formula1.com'+result if result and result.startswith('/') else result)
 d['sourceNotes'] = []
 if id == 'arvid-lindblad': d['sourceNotes'].append('The official profile lists 18 season Grands Prix but 17 career entries. This publisher discrepancy has not been reconciled.')
 if id == 'isack-hadjar': d['sourceNotes'].append('The official profile reports 15 Grand Prix races for this season; totals are not normalized to other drivers’ race counts.')
 if id in ('sergio-perez','valtteri-bottas'): d['sourceNotes'].append('Season standings can include substitute drivers beyond the 22 current seats.')
 assert all(v is not None for v in d['season'].values()),(id,values)
 return d
def fetch_results(d):
 if not d.get('resultsUrl'): return d
 s=urllib.request.urlopen(d['resultsUrl'],timeout=45).read().decode()
 tables=re.findall(r'<table\b.*?</table>',s,re.S)
 if not tables: raise ValueError('No results table: '+d['id'])
 rows=[]
 for row in re.findall(r'<tr\b.*?</tr>',tables[0],re.S):
  cells=re.findall(r'<td\b[^>]*>(.*?)</td>',row,re.S)
  if not cells: continue
  assert len(cells)==5,(d['id'],cells)
  values=[clean(re.sub(r'<svg\b.*?</svg>','',c,flags=re.S)) for c in cells]
  gp,date,team,pos,points=values
  assert re.fullmatch(r'\d+(?:\.\d+)?',points),(d['id'],values)
  rows.append({'grandPrix':gp,'date':date+' 2026','team':team,'position':pos,'points':float(points) if '.' in points else int(points)})
 d['raceResults']=rows
 if len(rows) != d['season']['races']:
  d['sourceNotes'].append(f"The official results table contains {len(rows)} rows while the profile reports {d['season']['races']} season races; this local table may be incomplete.")
 if sum(r['points'] for r in rows) != d['season']['points']:
  d['sourceNotes'].append('The official results-table points do not yet match the profile season total. Both are shown as retrieved; this snapshot is not a reconciled live feed.')
 return d

if __name__=='__main__':
 with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
  data=list(pool.map(fetch,ROSTER))
  data=list(pool.map(fetch_results,data))
 path=ROOT/'src/data/drivers.json'
 if path.exists():
  previous={d['id']:d for d in json.loads(path.read_text())}
  for d in data:
   for key in ('bio','history'): d[key]=previous.get(d['id'],{}).get(key,d[key])
 path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')
 print('Fetched',len(data),'official driver profiles. Review snapshot before publishing.')
