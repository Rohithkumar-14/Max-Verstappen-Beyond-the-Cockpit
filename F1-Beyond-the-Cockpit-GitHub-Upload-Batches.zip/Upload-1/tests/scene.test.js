import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { Box3, PerspectiveCamera, Vector3 } from 'three';
import { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';
import { framePose } from '../src/scene/framing.js';
import { CAMERA_PATH, cameraLayout, interpolatePose } from '../src/scene/cameraConfig.js';

const bytes = await readFile(new URL('../public/models/ground-effect-racer.glb', import.meta.url));
const arrayBuffer = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
const gltf = await new GLTFLoader().parseAsync(arrayBuffer, '');
const bounds = new Box3().setFromObject(gltf.scene);
const size = bounds.getSize(new Vector3());
const center = bounds.getCenter(new Vector3());
const normalized = new Box3(new Vector3(-size.x / 2, 0, -size.z / 2), new Vector3(size.x / 2, size.y, size.z / 2));
normalized.min.multiplyScalar(5.4 / size.z); normalized.max.multiplyScalar(5.4 / size.z);

test('licensed GLB parses with finite bounds and four named wheel assemblies', () => {
  assert.ok(size.z > 5 && size.z < 6);
  assert.ok(size.x > 2 && size.y > 1);
  const names = [];
  gltf.scene.traverse(node => { names.push(node.name); });
  for (const name of ['wheel-front-right','wheel-front-left','wheel-rear-right','wheel-rear-left']) assert.ok(names.includes(name), name);
  assert.ok(Number.isFinite(center.y));
});

test('asset uses metallic-roughness PBR materials and needs no external images', () => {
  const jsonLength = bytes.readUInt32LE(12);
  const json = JSON.parse(bytes.subarray(20, 20 + jsonLength));
  assert.equal(json.asset.version, '2.0');
  assert.equal(json.images?.length ?? 0, 0);
  assert.ok(json.materials.every(material => material.pbrMetallicRoughness));
});

for (const [width, height] of [[1440,900],[390,844],[320,740],[844,390],[768,1024]]) {
  test(`camera framing and clearance throughout ${width}x${height} path`, () => {
    const layout = cameraLayout(width);
    const camera = new PerspectiveCamera(38, width / height, .1, 60);
    for (let i = 0; i <= 100; i++) {
      const pose = interpolatePose(layout, i / 100);
      camera.position.fromArray(pose.position); camera.lookAt(new Vector3().fromArray(pose.target));
      framePose(camera, new Vector3().fromArray(pose.target), normalized);
      assert.ok(!normalized.containsPoint(camera.position), `camera inside car at ${i}%`);
      for (const x of [normalized.min.x, normalized.max.x]) for (const y of [normalized.min.y, normalized.max.y]) for (const z of [normalized.min.z, normalized.max.z]) {
        const point = new Vector3(x,y,z).project(camera);
        assert.ok(Math.abs(point.x) < .99 && Math.abs(point.y) < .99 && Math.abs(point.z) < 1, `car clips at ${i}%: ${JSON.stringify(point)}`);
      }
    }
  });
}

test('camera pose is reversible and clamped at timeline endpoints', () => {
  for (const layout of Object.keys(CAMERA_PATH)) {
    assert.deepEqual(interpolatePose(layout, -1), CAMERA_PATH[layout].rear);
    assert.deepEqual(interpolatePose(layout, 2), CAMERA_PATH[layout].rearQuarter);
    const forward = Array.from({length:101},(_,i) => interpolatePose(layout,i/100));
    const backward = Array.from({length:101},(_,i) => interpolatePose(layout,(100-i)/100)).reverse();
    assert.deepEqual(forward,backward);
  }
});
