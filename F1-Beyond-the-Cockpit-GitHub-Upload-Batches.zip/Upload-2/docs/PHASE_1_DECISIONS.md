# Phase 1 implementation decisions

## Instruction audit
Read PROJECT_BRIEF.md, DESIGN.md, ANIMATION_PLAN.md, DATA_SCHEMA.md, ASSETS.md and QA_CHECKLIST.md from the updated uploaded archive before Phase 1 changes. No AGENTS.md was supplied in the archive or found at the project root or applicable parent directories. Do not claim its instructions were read.

The latest user instructions override the documents where needed:
- A single neutral, generic Formula-style car is shared across all eventual driver profiles; no default branded team car.
- The future primary driver reveal is a seated 3D driver in helmet, suit and gloves. A licensed, accurate portrait is the fallback, not the primary approach.
- Phase 1 is only the garage and rear-to-rear-quarter camera move. Driver selection, statistics, race results, comparisons, cockpit journey and driver reveal are deferred.
- If no suitable realistic asset is found, a clearly marked placeholder is allowed. The full-project checklist is not the Phase 1 completion checklist.
- The latest user instruction permits a placeholder scene without matched licensed photorealistic renders. This supersedes the 2.5D-render suggestion in ANIMATION_PLAN.md and ASSETS.md.

## Existing scaffold
The earlier incomplete scaffold had no main JS implementation, included broad driver-grid content, and used a lime palette. It was not a working scene. index.html and src/style.css were narrowed to Phase 1 and the documented cyan palette. Preliminary profile data, portrait downloads and scraper were moved outside the checkout and are not shipped. No profile statistics or unlicensed portraits are used.

## Asset decision
A legally documented, neutral GLB was found and integrated, but its geometry is too simplified to meet the requested convincing-realism/close-shot standard. It is a pipeline placeholder. The label appears on the page and in the asset register. The realism milestone remains OPEN.

## Technical approach
- Vite, vanilla ES modules, Three.js, GSAP and ScrollTrigger; exact dependency versions plus package-lock.json.
- One perspective camera, unanimated car, one configurable scroll timeline.
- Rear and rear-quarter position/target pairs in src/scene/cameraConfig.js.
- Native page scrolling, no smooth-scroll library, no backend.
- Dark procedural garage, key/fill/cyan rim light, static contact-shadow texture; no real-time shadow maps or bloom.
- Demand-driven rendering; cap DPR at 1.5 desktop / 1.25 narrow mobile. Stop drawing offscreen and while the document is hidden.
- Poster + readable notes remain available without WebGL. No long pin in fallback, static, or reduced-motion mode.
- Skip destroys the local timeline, removes its pin spacer, moves to the notes and transfers focus. No body scroll lock.
- Read-only window.__garage.snapshot() diagnostics; no fake telemetry on the page.

## Static-scene gate and verification limitation
The static asset was parsed with Three.js and its geometry/materials/orientation and camera frustum were checked before adding ScrollTrigger. The cloud browser has WebGL disabled, so GPU rendering could not be verified. The static visual gate remains unpassed, not silently approved. The camera module is implemented behind successful scene/model initialization, and tested independently through a DOM-only scroll harness. Do not equate that with a visually tested 3D journey.

## Next blocking asset
An appropriately licensed high-detail neutral GLB with realistic tires, diffuser, suspension, front/rear wings, open cockpit, halo and detailed steering wheel. Test that static model on a WebGL-capable desktop and phone before extending the camera path.
