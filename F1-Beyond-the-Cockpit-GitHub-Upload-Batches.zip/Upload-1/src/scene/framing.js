import { Vector3 } from 'three';

// Keep the complete asset in frame, including narrow tablets and rotated phones.
export function framePose(camera, target, bounds) {
  const corners = [];
  for (const x of [bounds.min.x, bounds.max.x])
    for (const y of [bounds.min.y, bounds.max.y])
      for (const z of [bounds.min.z, bounds.max.z]) corners.push(new Vector3(x, y, z));
  for (let attempt = 0; attempt < 6; attempt++) {
    camera.lookAt(target); camera.updateMatrixWorld(true);
    let required = 1;
    for (const corner of corners) {
      const point = corner.clone().project(camera);
      required = Math.max(required, Math.abs(point.x) / 0.86, Math.abs(point.y) / 0.86);
    }
    if (required <= 1) break;
    camera.position.sub(target).multiplyScalar(required * 1.02).add(target);
  }
  camera.lookAt(target); camera.updateMatrixWorld(true);
}
