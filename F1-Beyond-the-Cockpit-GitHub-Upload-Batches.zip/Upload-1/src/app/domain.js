export const teamColors = {McLaren:'#ff9c51',Mercedes:'#57dfc7',Ferrari:'#ff5d68','Red Bull Racing':'#769bff',Williams:'#6ba9ff','Aston Martin':'#6dc9a5',Alpine:'#e89aca',Haas:'#c9d1dc','Haas F1 Team':'#c9d1dc',Audi:'#ed807b',Cadillac:'#c5bca9','Racing Bulls':'#a2bfff'};
export const escapeHTML = value => String(value ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
export function resolveRoute(hash, drivers) {
 const path=hash.replace(/^#\/?/,'').split('/');
 if(!path[0]) return {page:'home'};
 if(['grid','credits'].includes(path[0])) return {page:path[0]};
 if(path[0]==='driver') { const driver=drivers.find(d=>d.id===path[1]); return driver?{page:'driver',driver}:{page:'missing'}; }
 return {page:'missing'};
}
export function filterDrivers(drivers,query='',team='all') { return drivers.filter(d=>(team==='all'||d.team===team)&&`${d.fullName} ${d.number} ${d.team}`.toLowerCase().includes(query.trim().toLowerCase())); }
export function neighbors(drivers,id) { const i=drivers.findIndex(d=>d.id===id); return {previous:drivers[(i-1+drivers.length)%drivers.length],next:drivers[(i+1)%drivers.length]}; }
export const metric = value => value===null||value===undefined?'—':String(value);
