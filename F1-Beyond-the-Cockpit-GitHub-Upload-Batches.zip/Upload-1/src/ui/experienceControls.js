export function bindExperienceControls({ media, onRetry, onToggle, onSkip, onReplay, onPreferenceChange }) {
  const bindings = [
    [document.getElementById('retry'), 'click', onRetry],
    [document.getElementById('motion-toggle'), 'click', onToggle],
    [document.getElementById('skip'), 'click', onSkip],
    [document.getElementById('replay'), 'click', onReplay],
    [media, 'change', onPreferenceChange],
  ];
  bindings.forEach(([target, type, listener]) => target.addEventListener(type, listener));
  return () => bindings.forEach(([target, type, listener]) => target.removeEventListener(type, listener));
}
