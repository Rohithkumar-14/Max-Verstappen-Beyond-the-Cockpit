import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { Box3, Vector3 } from 'three';
import { loadCar, disposeObject } from '../src/scene/loadCar.js';

test('model load failure returns a meaningful rejected promise', async () => {
  await assert.rejects(loadCar({ simulateFailure: true }), /failure deliberately injected/);
});
test('HTTP error and Vite HTML fallback are rejected before GLB parsing', async (t) => {
  const fetchMock = t.mock.method(globalThis, 'fetch', async () => new Response('', { status: 404 }));
  await assert.rejects(loadCar({}), /HTTP 404/);
  fetchMock.mock.mockImplementation(async () => new Response('<html>', { headers: { 'content-type': 'text/html' } }));
  await assert.rejects(loadCar({}), /HTML instead of a GLB/);
});
test('a real GLB response loads, reports progress and normalizes onto the garage floor', async (t) => {
  const bytes = await readFile(new URL('../public/models/ground-effect-racer.glb', import.meta.url));
  t.mock.method(globalThis, 'fetch', async () => new Response(bytes, { headers: { 'content-length': String(bytes.byteLength) } }));
  let received = 0;
  const car = await loadCar({ onProgress: loaded => { received = loaded; } });
  const bounds = new Box3().setFromObject(car);
  const size = bounds.getSize(new Vector3());
  assert.equal(received, bytes.byteLength);
  assert.ok(Math.abs(size.z - 5.4) < .0001);
  assert.ok(Math.abs(bounds.min.y) < .0001);
  assert.ok(Math.abs(bounds.getCenter(new Vector3()).x) < .0001);
  disposeObject(car);
});
test('aborted model loading does not return an attachable scene', async (t) => {
  const bytes = await readFile(new URL('../public/models/ground-effect-racer.glb', import.meta.url));
  t.mock.method(globalThis, 'fetch', async () => new Response(bytes));
  await assert.rejects(loadCar({ signal: AbortSignal.abort() }), { name: 'AbortError' });
});
