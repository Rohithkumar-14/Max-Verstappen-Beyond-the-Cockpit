import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
gsap.registerPlugin(ScrollTrigger);
export function animatePage(root,enabled) {
 if(!enabled) return ()=>{};
 const context=gsap.context(()=>{
  const visual=root.querySelector('.hero-visual');
  if(visual) gsap.to(visual,{scale:1.09,yPercent:8,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:.5}});
  const progress=root.querySelector('.journey-fill');
  if(progress) gsap.to(progress,{scaleX:1,ease:'none',scrollTrigger:{trigger:'.hero',start:'top top',end:'bottom top',scrub:true}});
  const reveal=root.querySelector('.profile-hero');
  if(reveal) gsap.from(reveal,{opacity:.3,y:20,duration:.55,ease:'power2.out',clearProps:'all'});
 },root);
 return ()=>context.revert();
}
