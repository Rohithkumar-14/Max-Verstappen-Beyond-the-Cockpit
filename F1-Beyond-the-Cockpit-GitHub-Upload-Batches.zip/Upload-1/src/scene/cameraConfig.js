// Relative to the fixed, normalized car. Nose points +Z.
// Later phases can append chapters after rearQuarter; do not animate the car.
export const CAMERA_PATH = Object.freeze({
  desktop: {
    rear: { position: [0.3, 1.25, -8.4], target: [0, 0.62, -0.45] },
    rearQuarter: { position: [5.6, 2.5, -7.0], target: [0, 0.6, 0] }, scrollDistance: 1450,
  },
  mobile: {
    rear: { position: [0.4, 1.75, -12.6], target: [0, 2.7, -0.4] },
    rearQuarter: { position: [7.1, 3.5, -10.4], target: [0, 2.65, 0] }, scrollDistance: 850,
  },
});
export function cameraLayout(width) { return width <= 600 ? 'mobile' : 'desktop'; }
export function interpolatePose(layout, progress) {
  const { rear, rearQuarter } = CAMERA_PATH[layout];
  const t = Math.max(0, Math.min(1, progress));
  const mix = (from, to) => from.map((value, index) => value + (to[index] - value) * t);
  return { position: mix(rear.position, rearQuarter.position), target: mix(rear.target, rearQuarter.target) };
}
