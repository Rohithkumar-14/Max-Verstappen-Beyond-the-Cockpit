export const CINEMATIC_CAR = Object.freeze({
 url:'/models/blender458-f1-2022.glb',quality:'medium-detail',creator:'Blender458',license:'CC-BY-4.0',
 source:'https://sketchfab.com/3d-models/f5b9ca6095124bf796934c150d178a02',
 sha256:'8017633e3c697efdfdb8589b697cbab6cb9cb3b898e7cfd3501ae4ac6f17db3d',
});
export function finishCinematicMaterial(material){
 const name=material.name;
 const paint=/^(Rear_wing|front_body|front_nose|front_wing|main_body|side_body|top_wings|intake_side)/.test(name);
 if(paint){material.color.set('#29384e');material.metalness=.65;material.roughness=.31;}
 else if(name==='tyre'){material.color.set('#171a1e');material.metalness=0;material.roughness=.94;}
 else if(name==='screen'){material.color.set('#08121e');material.emissive.set('#10283b');material.emissiveIntensity=.35;material.roughness=.36;}
 else if(/dial|^material$/.test(name)){material.roughness=.45;material.metalness=.15;}
 else{material.color.set(/halo|cockpit|leg_area|steering/.test(name)?'#141b26':'#303642');material.metalness=.3;material.roughness=.5;}
 material.envMapIntensity=.9;
}

const redBullBase = {name:'redbull-rb22',quality:'textured third-party RB22',creator:'Dave Love SketchFab (@Tyler_Dave)',license:'CC-BY-4.0',source:'https://sketchfab.com/3d-models/2026-redbull-rb22-0a3d24a58e0549d591a5a48c22eec383'};
export const REDBULL_DESKTOP = Object.freeze({...redBullBase,url:'/models/redbull-rb22-desktop.glb',budget:'desktop'});
export const REDBULL_MOBILE = Object.freeze({...redBullBase,url:'/models/redbull-rb22-mobile.glb',budget:'mobile'});
export function selectRedBullAsset({width=1440,memory=8,saveData=false}={}){
 return width<=900||memory<=4||saveData?REDBULL_MOBILE:REDBULL_DESKTOP;
}
export function finishRedBullMaterial(material){
 // Preserve every supplied livery/tyre/control texture and its UVs.
 material.envMapIntensity=.85;
 if(material.name.startsWith('redbull_paint')){material.metalness=.35;material.roughness=.28;}
 if(material.name.startsWith('sidewall')){material.metalness=0;material.roughness=.86;}
 if(material.name.startsWith('glass')){material.transparent=true;material.opacity=.35;material.depthWrite=false;}
}
