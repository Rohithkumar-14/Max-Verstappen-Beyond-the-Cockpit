# QA and acceptance checklist

## Core experience
- [ ] Opening hero has a designed loading state.
- [ ] Rear, side, cockpit, full-car, and driver reveal sequence exists.
- [ ] Forward and reverse scrolling scrub one coherent timeline.
- [ ] Camera has no abrupt jumps at keyframes.
- [ ] Driver selection updates name, number, team accent, portrait, and stats.
- [ ] Profile remains usable when animation is skipped.

## Roster and data
- [ ] All 22 drivers and team associations verified against a current reliable source.
- [ ] Season stats and career stats are separate.
- [ ] Unknown values display as unavailable, not fake zeros.
- [ ] Source and update context are visible.
- [ ] Failed API requests do not break navigation or animation.

## Assets and licensing
- [ ] Car model license permits intended use.
- [ ] Portraits, logos, liveries, and sponsor marks are appropriately licensed.
- [ ] No generic model is falsely described as an authentic 2026 team car.
- [ ] Broken assets show a designed fallback.

## Accessibility
- [ ] Keyboard navigation works.
- [ ] Controls have accessible names.
- [ ] Text contrast is sufficient.
- [ ] `prefers-reduced-motion` is respected.
- [ ] Animation can be skipped.
- [ ] Sound is not forced on.

## Performance
- [ ] Desktop and mobile widths tested.
- [ ] Slow network tested.
- [ ] Models and textures optimized.
- [ ] WebGL failure shows a fallback.
- [ ] No horizontal overflow on mobile.
- [ ] No uncaught console errors in core flows.

## Release rule
Do not mark a check passed unless it was actually tested. Record failed checks and known limitations before deployment.
