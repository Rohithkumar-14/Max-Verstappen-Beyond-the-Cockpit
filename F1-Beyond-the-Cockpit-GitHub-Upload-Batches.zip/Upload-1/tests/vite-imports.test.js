import test from 'node:test';
import assert from 'node:assert/strict';
import { readdir, readFile, mkdtemp, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createServer } from 'vite';

async function modules(directory) {
  const paths = [];
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = `${directory}/${entry.name}`;
    if (entry.isDirectory()) paths.push(...await modules(path));
    else if (entry.name.endsWith('.js')) paths.push(path);
  }
  return paths;
}

test('Vite resolves every application and dev-only QA module, with the intended HTML entry points', async () => {
  // Syntax checks alone cannot detect missing imports. Use Vite's actual import
  // analysis, including QA modules excluded from the production build.
  // Never replace the live dev server's optimized-dependency cache during tests.
  const cacheDir = await mkdtemp(join(tmpdir(), 'f1-vite-imports-'));
  const server = await createServer({ cacheDir, server: { middlewareMode: true, watch: null }, logLevel: 'silent' });
  try {
    const entries = {
      'index.html': '/src/max/main.js',
      'explorer.html': '/src/app/app.js',
      'garage.html': '/src/main.js',
      'qa/car-review.html': '/qa/car-review.js',
    };
    for (const [html, entry] of Object.entries(entries)) {
      assert.ok((await readFile(html, 'utf8')).includes(`src="${entry}"`), `${html} entry point`);
    }
    for (const path of [...await modules('src'), ...await modules('qa')]) {
      const result = await server.transformRequest(`/${path}`);
      assert.ok(result?.code, `Vite must transform ${path}`);
    }
  } finally {
    await server.close();
    await rm(cacheDir, { recursive: true, force: true });
  }
});
