# Portrait credits and verification

The active continuation is focused on Max Verstappen. Earlier roster data and the Fernando Alonso photograph are preserved; this document does not claim that all 22 portraits are integrated.

## Max Verstappen — integrated local portrait

- Photograph: Max Verstappen at the Dutch Grand Prix podium ceremony, 25 August 2024.
- Photographer and required attribution: **Steffen Prößdorf**.
- [Source and copyright licence declaration](https://commons.wikimedia.org/wiki/File:2024-08-25_Motorsport,_Formel_1,_Gro%C3%9Fer_Preis_der_Niederlande_2024_STP_3973_by_Stepro_(portrait_cropped).jpg).
- Licence: [Creative Commons Attribution-ShareAlike 4.0](https://creativecommons.org/licenses/by-sa/4.0/).
- The Commons portrait crop was made by Bagumba. Any delivered resize, crop or format conversion is identified as an adaptation and distributed under CC BY-SA 4.0. The licence permits copying, website redistribution and modification with attribution, licence link, change notice and share-alike terms.
- The source identifies Max Verstappen and records 1,380 × 1,485 pixels. Its copyright declaration and author were checked directly on the individual Commons file page.
- Source includes an FIA accreditation notice allowing editorial publication and a personality-rights notice. This historical photo is used to illustrate an independent driver profile. It is not a 2026 official portrait and does not imply endorsement, sponsor affiliation or a model release.
- Direct container download returned HTTP 403; browser download succeeded. The actual image was inspected by the implementing agent. Local file: `public/portraits/max-verstappen.webp`, resized to 1000 × 1076 and converted to WebP; this adaptation is licensed CC BY-SA 4.0. The local WebP was decoded successfully.
- SHA-256: `244e65cd9fa1363cfe6f2100694bfa496d600d79ac173d2b39162a40ef204acb`.

## Preserved Fernando Alonso photograph

- File: `public/portraits/fernando-alonso.webp`.
- Photograph: Fernando Alonso at the 2008 Canadian Grand Prix, in Renault clothing.
- Photographer and required attribution: **Mark McArdle**.
- [Source and licence declaration](https://commons.wikimedia.org/wiki/File:Fernando_Alonso_2008.jpg).
- [Original publisher's image](https://live.staticflickr.com/3015/2565102461_e6e6625002_o.jpg).
- Licence: [Creative Commons Attribution-ShareAlike 2.0](https://creativecommons.org/licenses/by-sa/2.0/).
- Changes: resized to a maximum of 900 pixels and converted to WebP. This adaptation is distributed under CC BY-SA 2.0.
- Actual downloaded pixels were visually inspected and the output was decoded successfully. This historical image is retained from the earlier grid scope; it is not a current-season team portrait.

## Fallback and asset policy

No synthetic face or unrelated person substitutes for a driver. When a permitted portrait is absent or fails to load, the interface must display its documented text/initials fallback. Candidate research alone is never marked integrated. Photographer credits, source links, licence links and change notices must accompany published images, including copied source distributions.
