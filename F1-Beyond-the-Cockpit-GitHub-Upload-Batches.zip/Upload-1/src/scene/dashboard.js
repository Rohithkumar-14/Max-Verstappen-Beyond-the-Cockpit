import {Box3,CanvasTexture,Matrix4,Mesh,MeshBasicMaterial,PlaneGeometry,SRGBColorSpace,Vector3} from 'three';

export const SCREEN_MATERIAL='gp21_LCD.003';
export function createDashboardTexture(){
 const canvas=document.createElement('canvas');canvas.width=512;canvas.height=288;
 const context=canvas.getContext('2d');
 context.fillStyle='#020b0c';context.fillRect(0,0,512,288);
 context.strokeStyle='#46dde8';context.lineWidth=3;context.strokeRect(12,12,488,264);
 context.textAlign='center';context.textBaseline='middle';
 context.fillStyle='#71eaf0';context.font='bold 24px monospace';context.fillText('MAX / VERSTAPPEN',256,50);
 context.fillStyle='#efffff';context.font='bold 64px sans-serif';context.fillText('SIMPLY',256,124);context.fillText('LOVELY.',256,196);
 const texture=new CanvasTexture(canvas);texture.colorSpace=SRGBColorSpace;texture.name='Simply Lovely dashboard display';
 return texture;
}

// Derive the panel from the actual screen geometry, in its local coordinate frame.
// The label is a depth-tested mesh parented to that screen, never a DOM overlay.
export function dashboardLayout(screen){
 screen.updateWorldMatrix(true,false);
 const geometry=screen.geometry;geometry.computeBoundingBox();
 const center=geometry.boundingBox.getCenter(new Vector3());
 const normal=new Vector3().fromBufferAttribute(geometry.attributes.normal,0).normalize();
 const inverse=new Matrix4().copy(screen.matrixWorld).invert();
 const up=new Vector3(0,1,0).transformDirection(inverse);
 up.addScaledVector(normal,-up.dot(normal)).normalize();
 const right=new Vector3().crossVectors(up,normal).normalize();
 const position=new Vector3();let left=Infinity,rightEdge=-Infinity,bottom=Infinity,top=-Infinity;
 for(let i=0;i<geometry.attributes.position.count;i++){
  position.fromBufferAttribute(geometry.attributes.position,i).sub(center);
  const x=position.dot(right),y=position.dot(up);left=Math.min(left,x);rightEdge=Math.max(rightEdge,x);bottom=Math.min(bottom,y);top=Math.max(top,y);
 }
 return {center,normal,up,right,width:(rightEdge-left)*.96,height:(top-bottom)*.94};
}

export function attachDashboard(car,{createTexture=createDashboardTexture}={}){
 let screen;car.traverse(node=>{if(node.isMesh&&node.material?.name===SCREEN_MATERIAL)screen=node;});
 if(!screen)throw new Error('The RB22 steering-wheel display was not found.');
 const layout=dashboardLayout(screen);
 const material=new MeshBasicMaterial({map:createTexture(),transparent:true,opacity:0,depthWrite:false,depthTest:true,toneMapped:false,polygonOffset:true,polygonOffsetFactor:-1,polygonOffsetUnits:-1});
 const panel=new Mesh(new PlaneGeometry(layout.width,layout.height),material);panel.name='dashboard-simply-lovely';
 panel.position.copy(layout.center).addScaledVector(layout.normal,.0008);
 panel.quaternion.setFromRotationMatrix(new Matrix4().makeBasis(layout.right,layout.up,layout.normal));
 panel.visible=false;screen.add(panel);
 return {screen,panel,setOpacity(value){const opacity=Math.max(0,Math.min(1,value));panel.visible=opacity>.001;material.opacity=opacity;}};
}
