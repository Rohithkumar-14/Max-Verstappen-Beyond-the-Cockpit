# Cinematic animation plan

## Target
A convincing camera journey around a realistic F1 car, not a mechanical simulator.

## Preferred implementation
- Use GSAP ScrollTrigger to pin the cinematic section and scrub a master timeline.
- If a suitable GLB/GLTF model supports the needed angles, use Three.js to animate camera position and target.
- If no suitable model is available initially, use matched licensed renders and 2.5D crossfades/parallax. Document that this version cannot reveal unseen angles.
- Do not build a detailed engine cutaway unless a suitable asset exists and it fits the scope.

## Sequence (initial timing targets)
1. **Rear hero (0–15%)**: low camera behind car; reveal wing, tires, diffuser, garage lights.
2. **Side inspection (15–40%)**: glide along bodywork; show restrained labels for wheel, suspension, aero surfaces.
3. **Cockpit approach (40–60%)**: approach cockpit; reveal steering wheel, display, helmet, driver.
4. **Full-car reveal (60–75%)**: pull back to a full-car composition.
5. **Driver reveal (75–90%)**: transition to driver portrait or licensed 3D driver asset.
6. **Profile transition (90–100%)**: display identity, season summary, and profile navigation.

## Camera notes
- Define keyframes as camera position plus look-at target.
- Interpolate smoothly; avoid jumps and arbitrary unrelated coordinates.
- Keep car and driver as separate scene objects where practical.
- Synchronize callouts and HUD transitions to timeline progress.
- Reverse scrolling must reverse the animation cleanly.
- Driver changes should update content and reset or smoothly transition the scene.

## Interaction
Native scrolling is primary. Include skip and direct profile navigation. Mouse/touch camera controls are optional. Do not require webcam/hand tracking in v1.

## Acceptance
Forward/reverse scrolling is smooth; no abrupt camera jumps; callouts appear at the right points; driver selection updates profile; reduced-motion mode skips the cinematic sequence; missing model/WebGL shows a designed fallback.
