# Data schema

## Principles
- Keep roster separate from UI components.
- Separate season stats from career stats.
- Include source metadata and season/round or retrieval timestamp for sourced stats.
- Missing values are `null`, not fabricated zeroes.
- Verify the 2026 roster and team associations before release.

## Driver object (documentation example)
```js
const driver = {
  id: "stable-driver-id",
  fullName: "Driver Full Name",
  displayName: "Display Name",
  number: null,
  nationality: null,
  teamId: "team-id",
  teammateId: null,
  portrait: { src: null, alt: "Driver portrait", license: null, sourceUrl: null },
  season: {
    year: 2026, championshipPosition: null, points: null, wins: null,
    podiums: null, poles: null, fastestLaps: null, raceStarts: null,
    completedRounds: null, updatedAt: null, sourceName: null,
    sourceUrl: null, status: "unavailable"
  },
  career: {
    championships: null, wins: null, podiums: null, poles: null,
    raceStarts: null, firstSeason: null, teams: [],
    updatedAt: null, sourceName: null, sourceUrl: null, status: "unavailable"
  },
  raceResults: [],
  qualifyingResults: []
};
```

## Team object
```js
const team = {
  id: "team-id",
  name: "Team Name",
  accentColor: "#00d5ff",
  carName: null,
  logo: { src: null, license: null, sourceUrl: null }
};
```

## Race result
```js
const raceResult = {
  season: 2026, round: null, grandPrix: null, date: null,
  gridPosition: null, finishPosition: null, points: null,
  status: "unavailable", sourceName: null, sourceUrl: null, retrievedAt: null
};
```

## UI rules
- Display `—` or “Not available” for unknown stats.
- Show “Updated through Round N” or a timestamp when possible.
- Distinguish race wins from sprint wins.
- Do not combine scoring formats without documenting the method.
- Make source attribution accessible from the profile.
