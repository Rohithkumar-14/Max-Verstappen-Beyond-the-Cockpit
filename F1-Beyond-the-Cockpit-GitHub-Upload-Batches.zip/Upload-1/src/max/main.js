import {populateContent,renderResults,renderSeason} from './content.js';
import {setupAnimations,animationDiagnostics,refreshAnimations} from './animation.js';
import {journeyPose} from './cameraPath.js';
import {selectRedBullAsset,finishRedBullMaterial} from '../scene/carAsset.js';
import {attachDashboard} from '../scene/dashboard.js';
const carAsset=selectRedBullAsset({width:innerWidth,memory:navigator.deviceMemory??8,saveData:navigator.connection?.saveData??false});
const $=id=>document.getElementById(id);
const media=matchMedia('(prefers-reduced-motion: reduce)');
const query=new URLSearchParams(location.search);
const reduced=()=>media.matches||query.has('reduce');
let staticMode=query.has('static')||(!!location.hash&&location.hash!=='#experience');
let scene=null,abort=null,timer=null,generation=0,disposeAnimation=()=>{};
let sceneState='loading',progress=0;
const chapterNames=['REAR ASSEMBLY','BODYWORK','COCKPIT / STEERING WHEEL','FULL-CAR REVEAL'];
function updateProgress(value,index=0){progress=value;document.querySelector('.journey-progress').setAttribute('aria-valuenow',String(Math.round(value*100)));$('journey-fill').style.transform=`scaleX(${value})`;$('chapter-label').textContent=value>.88?'05 / THE HUMAN':`0${index+1} / ${chapterNames[index]}`;}
function updateMode(){
 disposeAnimation();const disabled=staticMode||reduced();
 document.body.classList.toggle('static-mode',disabled);
 $('motion-toggle').textContent=reduced()?'Reduced motion':disabled?'Motion off':'Motion on';
 $('motion-toggle').setAttribute('aria-pressed',String(disabled));
 $('motion-toggle').disabled=reduced();
 try {disposeAnimation=setupAnimations({enabled:!disabled,scene,onProgress:updateProgress});}
 catch(error){console.warn('[Max experience] Animation disabled:',error.message);disposeAnimation=()=>{};document.body.classList.add('static-mode');scene?.setProgress(1);}
 if(disabled&&scene)updateProgress(1,3);
 if(!scene){updateProgress(0);$('chapter-label').textContent='STATIC RB22 PREVIEW';}
 
 refreshAnimations();
}
function fallback(message){
 scene?.dispose();scene=null;sceneState='fallback';document.body.dataset.sceneState='fallback';document.body.classList.remove('has-3d');$('webgl-scene').hidden=true;
 $('scene-status').textContent=message;
 $('scene-description').textContent='Static creator preview of the supplied RB22 model · CC BY 4.0.';
 $('retry-scene').hidden=false;updateMode();
}
async function loadScene(){
 const current=++generation;abort?.abort();clearTimeout(timer);disposeAnimation();scene?.dispose();scene=null;
 abort=new AbortController();sceneState='loading';$('scene-status').textContent='Preparing the camera study…';$('retry-scene').hidden=true;
 try{
  const [{createScene},{loadCar,disposeObject}]=await Promise.all([import('../scene/createScene.js'),import('../scene/loadCar.js')]);
  if(current!==generation)return;
  $('webgl-scene').hidden=false;
  scene=createScene($('webgl-scene'),{simulateFailure:query.get('test')==='webgl-error',poseProvider:journeyPose,fitWholeCar:false,brandedGarage:true,onContextLost:()=>{abort.abort();fallback('3D interrupted. The static RB22 preview and driver story remain available.');}});
  timer=setTimeout(()=>abort.abort(new Error('Model request timed out.')),45000);
  const car=await loadCar({asset:carAsset,finishMaterial:finishRedBullMaterial,signal:abort.signal,simulateFailure:query.get('test')==='model-error',onProgress:(loaded,total)=>{if(current!==generation)return;$('scene-status').textContent=total?`Loading car asset: ${Math.min(100,Math.round(100*loaded/total))}%`:`Loading car asset: ${Math.round(loaded/1024)} KB`;}});
  clearTimeout(timer);if(current!==generation){disposeObject(car);return;}
  scene.setCar(car,{dashboard:attachDashboard(car)});document.body.classList.add('has-3d');sceneState='ready';document.body.dataset.sceneState='ready';
  $('scene-status').textContent=`RB22 ready · ${carAsset.budget} textures · scroll to explore`;
  $('scene-description').textContent='Third-party Red Bull RB22 model · Dave Love SketchFab · CC BY 4.0.';
  updateMode();
 }catch(error){if(current!==generation)return;clearTimeout(timer);console.warn('[Max experience]',error.message);fallback('3D unavailable. The static RB22 preview and Max’s story remain available.');}
}
function skipJourney(){staticMode=true;updateMode();$('driver').scrollIntoView({behavior:'instant'});$('driver').focus({preventScroll:true});}
populateContent({simulatePortraitFailure:query.get('test')==='portrait-error'});
const onMotion=()=>{staticMode=!staticMode;updateMode();};
const onPreference=()=>updateMode();
const onFilter=event=>{renderResults(event.target.value);refreshAnimations();};
$('motion-toggle').addEventListener('click',onMotion);
$('retry-scene').addEventListener('click',loadScene);
$('result-filter').addEventListener('change',onFilter);
const onSeason=event=>{renderSeason(event.target.value);refreshAnimations();};
$('season-selector').addEventListener('change',onSeason);
$('season-results').addEventListener('toggle',refreshAnimations);
media.addEventListener('change',onPreference);
const skipLinks=[...document.querySelectorAll('a[href="#driver"]')];
const onSkip=event=>{event.preventDefault();history.pushState(null,'','#driver');skipJourney();};
skipLinks.forEach(link=>link.addEventListener('click',onSkip));
const navObserver=new IntersectionObserver(entries=>{for(const entry of entries)if(entry.isIntersecting)document.querySelectorAll('.masthead nav a').forEach(link=>link.setAttribute('aria-current',String(link.hash===`#${entry.target.id}`)));},{rootMargin:'-20% 0px -55% 0px'});
document.querySelectorAll('main>section[id]').forEach(section=>navObserver.observe(section));
function dispose(){generation++;abort?.abort();clearTimeout(timer);disposeAnimation();scene?.dispose();scene=null;}
window.addEventListener('pagehide',dispose);
window.addEventListener('pageshow',event=>{if(event.persisted)loadScene();});
if(import.meta.hot)import.meta.hot.dispose(()=>{dispose();navObserver.disconnect();media.removeEventListener('change',onPreference);$('motion-toggle').removeEventListener('click',onMotion);$('retry-scene').removeEventListener('click',loadScene);$('result-filter').removeEventListener('change',onFilter);$('season-selector').removeEventListener('change',onSeason);$('season-results').removeEventListener('toggle',refreshAnimations);skipLinks.forEach(link=>link.removeEventListener('click',onSkip));});
window.__maxExperience={snapshot:()=>({sceneState,progress,staticMode,reducedMotion:reduced(),assetBudget:carAsset.budget,camera:scene?.camera.position.toArray()??null,...animationDiagnostics()})};
updateMode();loadScene();
