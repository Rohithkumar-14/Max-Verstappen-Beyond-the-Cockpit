# Design system — F1 Beyond the Cockpit

## Art direction
Premium motorsport broadcast meets futuristic engineering HUD. Realistic car visuals first; UI effects second.

## Palette
- Near-black / charcoal background.
- Telemetry cyan as primary accent.
- Restrained violet or magenta as secondary accent.
- White and cool-gray text.
- Team accent colours may change by selected driver.
- Do not rely on colour alone to communicate meaning.

## Typography
- Bold condensed racing-inspired headings.
- Legible sans-serif body text.
- Monospaced numbers, lap times, positions, and telemetry.
- Avoid tiny HUD labels.

## Layout
- Cinematic hero dominates the opening viewport.
- HUD panels must not obscure the car or driver's face.
- Driver profile: name, number, team, nationality, season summary, career summary, race history.
- Persistent controls: driver/team selector, scroll progress, skip animation, optional mute.
- On mobile, simplify HUD panels and shorten the animation.

## Motion
- One coherent scroll-scrubbed timeline.
- Smooth interpolation between camera positions and look-at targets.
- Support reverse scrolling.
- Respect `prefers-reduced-motion`; provide a static hero and direct profile access.
- Sound is optional and muted by default.

## States
Loading, model unavailable, data loading, data unavailable, stale/cached data, no race results yet, reduced-motion mode, and WebGL unavailable.

## Avoid
Generic card-grid landing page as the main experience, excessive bloom, unreadable neon text, fake telemetry, invented stats, and broken image placeholders.
