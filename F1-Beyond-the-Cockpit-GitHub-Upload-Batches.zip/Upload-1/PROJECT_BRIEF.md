# F1 — Beyond the Cockpit
## Project brief

### Goal
Build a premium cinematic website for exploring the 22 drivers on the 2026 Formula 1 grid. The experience should feel like entering a futuristic garage, inspecting a realistic race car, and meeting the selected driver.

### Core journey
1. Open behind a realistic F1-style car in a dark garage.
2. Scroll toward the rear wing and diffuser.
3. Travel along the car with restrained technical callouts.
4. Move toward the cockpit, steering wheel, and driver.
5. Pull back to reveal the whole car, then reveal the selected driver.
6. Show season statistics, career history, race results, and teammate comparisons.

### Visual direction
Futuristic telemetry, neon cyan accents, subtle violet/magenta accents, team-specific highlights, near-black backgrounds, crisp typography, and restrained holographic panels. Keep the car as the focal point.

### Scope
- 22 verified drivers and 11 teams.
- Reusable driver profiles.
- Season stats and career history.
- Responsive desktop/mobile layouts.
- Scroll-controlled camera journey with reverse scrolling.
- Skip-animation option and reduced-motion mode.

### Technical baseline
- Vite + vanilla JavaScript modules.
- GSAP + ScrollTrigger for scroll timelines.
- Use a licensed realistic car model if available. Use Three.js only if genuine 3D camera movement is needed.
- Keep roster and statistics separate from UI code.
- A backend is not required for the first prototype unless the selected data source requires one.

### Rules
- Never invent statistics or label a generic model as an authentic 2026 team car.
- Distinguish season stats from career stats and show source/update context.
- Failed stats requests must not break the site shell or profile navigation.
- Use assets only when their licenses permit the intended use.
