// User-supplied textured RB22; node transform retained, normalized to length5.4.
// Nose +Z. Actual LCD centre approximately [.00018,.6559,.4209].
export const JOURNEY_POSES = Object.freeze([
 {at:0,name:'REAR WING / DIFFUSER',position:[.65,.90,-4.10],target:[0,.58,-2.10]},
 {at:.18,name:'REAR BODYWORK',position:[1.60,1.00,-2.80],target:[.05,.55,-1.70]},
 {at:.36,name:'SIDE BODYWORK',position:[1.40,.95,-.80],target:[.25,.52,-.45]},
 {at:.52,name:'HALO APPROACH',position:[1.0,1.40,.10],target:[0,.75,.37]},
 {at:.60,name:'OVER THE COCKPIT',position:[0,1.05,-.02],target:[.00018,.6559,.4209]},
 {at:.64,name:'STEERING-WHEEL DISPLAY',position:[.00018,.74,.13],target:[.00018,.6559,.4209]},
 {at:.72,name:'DASHBOARD HOLD',position:[.00018,.74,.13],target:[.00018,.6559,.4209]},
 {at:.77,name:'COCKPIT PULLBACK',position:[1.75,1.8,-1.1],target:[0,.60,.15]},
 {at:1,name:'FULL-CAR REVEAL',position:[4.8,2.7,-7.3],target:[0,.60,0]},
]);
export function journeyPose(progress,mobile=false,aspect=.432){
 const t=Math.max(0,Math.min(1,progress));
 let i=JOURNEY_POSES.findIndex((p,index)=>index<JOURNEY_POSES.length-1&&t<=JOURNEY_POSES[index+1].at);
 i=Math.max(0,Math.min(JOURNEY_POSES.length-2,i));
 const a=JOURNEY_POSES[i],b=JOURNEY_POSES[i+1];
 const u=(t-a.at)/(b.at-a.at),smooth=u*u*(3-2*u);
 const mix=(x,y)=>x.map((v,k)=>v+(y[k]-v)*smooth);
 const position=mix(a.position,b.position),target=mix(a.target,b.target);
 // Mobile has its own restrained framing envelope. Keep the actual LCD hold intact.
 // A narrow drawing area needs more stand-off along the flank, not just at the reveal.
 if(mobile){
  const keys=[[0,2.0],[.18,1.8],[.36,2.15],[.52,1.7],[.60,1.35],[.64,1.35],[.72,1.35],[.77,1.4],[1,2.0]];
  let j=Math.max(0,keys.findIndex((k,n)=>n<keys.length-1&&t<=keys[n+1][0]));
  const [a0,f0]=keys[j],[a1,f1]=keys[j+1];const v=(t-a0)/(a1-a0),ease=v*v*(3-2*v);
  const narrow=Math.max(1,.432/Math.max(.2,aspect));
  const pull=Math.max(0,(t-.72)/.28);
  const factor=(t>=.72?1.35+.65*pull*pull*(3-2*pull):f0+(f1-f0)*ease)*narrow;
  position.forEach((v,k)=>position[k]=target[k]+(v-target[k])*factor);
 }
 return {position,target};
}
export function journeyChapter(progress){return progress<.25?0:progress<.49?1:progress<.77?2:3;}
