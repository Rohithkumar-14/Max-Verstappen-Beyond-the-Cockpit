import test from 'node:test';
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import {seasons,getSeason,championshipLabel,seasonSummary} from '../src/max/seasons.js';
import {max,selectResults} from '../src/max/content.js';
test('all twelve seasons have sourced standings and race results with reconciled points',()=>{
 assert.deepEqual(seasons.map(s=>s.year),Array.from({length:12},(_,i)=>2015+i));
 for(const s of seasons){
  assert.match(s.sourceUrl,new RegExp(`/results/${s.year}/drivers/`));assert.match(s.verifiedAt,/^2026-10-31$/);
  assert.equal(s.raceResults.reduce((sum,r)=>sum+r.points,0),s.points);
  assert.equal(s.entries,s.raceResults.length);assert.equal(s.raceStarts,s.raceResults.filter(r=>r.started).length);
  assert.equal(selectResults(s.raceResults,'win').length,s.wins);assert.equal(selectResults(s.raceResults,'podium').length,s.podiums);
  const evidence=JSON.parse(readFileSync(new URL(`../docs/evidence/seasons/${s.year}.json`,import.meta.url)));
  assert.equal(s.points,Number(evidence.officialStandingsRow.at(-1)));
  assert.equal(s.position,Number(evidence.officialStandingsRow[0]));
 }
});
test('team switch, DNS starts, and Sprint versus race points remain distinct',()=>{
 const s=getSeason(2016);assert.equal(s.teams.length,2);assert.match(s.raceResults[0].team,/Toro Rosso/);assert.match(s.raceResults[4].team,/Red Bull/);
 const y=getSeason(2015);assert.equal(y.entries,19);assert.equal(y.raceStarts,19);
 const sprint=getSeason(2023).raceResults.find(r=>r.grandPrix==='Austria');assert.equal(sprint.points,34);assert.equal(sprint.racePoints,26);
 assert.ok(getSeason(2025).entries>=getSeason(2025).raceStarts);
});
test('title stars reflect completed championship history, not the selected year alone',()=>{
 for(const s of seasons){const expected=seasons.filter(p=>p.year<=s.year&&p.complete&&p.position===1).length;assert.equal(s.championships,expected);}
 assert.equal(getSeason(2020).championships,0);assert.equal(getSeason(2021).championships,1);assert.equal(getSeason(2023).championships,3);assert.equal(getSeason(2024).championships,4);
 assert.match(championshipLabel(getSeason(2023)),/3 World Championships through 2023/);assert.equal(getSeason(2026).complete,false);
});
test('unknown summary fields stay unavailable and nonexistent seasons are not fabricated',()=>{
 assert.equal(getSeason(2014),undefined);assert.equal(seasonSummary({}).every(([,value])=>value===undefined),true);
});
test('production markup has accessible selector, native disclosure, supplied portrait and no floating dashboard cue',()=>{
 const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
 assert.match(html,/id="season-selector" aria-controls="season-panel"/);assert.match(html,/<details id="season-results"/);assert.match(html,/\/portraits\/max-helmet.webp/);assert.doesNotMatch(html,/cockpit-cue/);
 const css=readFileSync(new URL('../src/max/max.css',import.meta.url),'utf8');assert.match(css,/prefers-reduced-motion/);assert.match(css,/safe-area-inset-bottom/);
});

test('historical season totals reconcile with the preserved official career snapshot',()=>{
 assert.equal(seasons.reduce((n,s)=>n+s.wins,0),max.career.wins);
 assert.equal(seasons.reduce((n,s)=>n+s.podiums,0),max.career.podiums);
 assert.equal(seasons.reduce((n,s)=>n+s.poles,0),max.career.poles);
 assert.equal(seasons.reduce((n,s)=>n+s.points,0),max.career.points);
});
test('all new image assets match their inspected local evidence',async()=>{
 const {createHash}=await import('node:crypto');
 const evidence=JSON.parse(readFileSync(new URL('../docs/evidence/october-updates-assets.json',import.meta.url)));
 for(const row of evidence){const bytes=readFileSync(new URL(`../public${row.file}`,import.meta.url));assert.equal(bytes.length,row.bytes);assert.equal(createHash('sha256').update(bytes).digest('hex'),row.sha256);assert.match(row.rights,/not independently verified/);}
});
