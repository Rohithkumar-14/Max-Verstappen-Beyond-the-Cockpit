import { defineConfig } from 'vite';

export default defineConfig({
  build: { rollupOptions: { input: { main: 'index.html', explorer: 'explorer.html', garage: 'garage.html' } } },
  server: { host: '0.0.0.0', allowedHosts: ['terminal.local'] },
});
