# F1 — Beyond the Cockpit

A dedicated Max Verstappen editorial experience built with Vite, vanilla JavaScript, Three.js and GSAP ScrollTrigger. The current product direction supersedes the earlier22-driver experience; its reusable code/data and tests remain preserved in source and in checkpoint commit `e5d604c`.

## Run
Requires Node22.12+ and npm. No API keys or backend.

```sh
npm ci
npm run dev
npm run check
npm test
npm run build
```

Vite prints the local URL. Production output is `dist/`. `check` is a JavaScript syntax check; ESLint and TypeScript are not configured.

### Windows: unresolved legacy driver imports
Extract the complete current ZIP into a new folder instead of merging it into an older project. Keep the older folder as a backup. In the extracted folder containing `package.json`, run `npm.cmd ci`, then `npm.cmd run dev`. Requires Node 22.12 or later. Open the URL Vite prints; append `/qa/car-review.html` for the car review.

The intended HTML entry points are `index.html` → `src/max/main.js`, `explorer.html` → `src/app/app.js`, and `garage.html` → `src/main.js`. The preserved explorer implements its grid and profiles in `src/app/app.js`, with routing helpers in `src/app/domain.js`. This repository does not use `src/ui/router.js`, `driverGrid.js`, or `driverProfile.js`. Errors referencing those modules indicate a source copy differing from this archive; do not fix them with empty modules. `npm test` now runs Vite import analysis across all source and QA JavaScript modules to detect unresolved imports beyond syntax checks.

## Current experience
- The opening loads the owner-supplied textured Red Bull RB22 model by Dave Love SketchFab (@Tyler_Dave), CC BY 4.0. Nine geometry-specific poses cover rear wing/diffuser, bodywork travel, halo approach, the actual steering-wheel LCD, a readable cockpit hold, and full-car pullback. Native scrolling drives one reversible GSAP timeline. This is a third-party representation, not an official engineering asset.
- The car is stationary. Lighting/exposure, typography masks, portrait mask, restrained parallax and career reveals support the sequence. No heavy postprocessing or real-time shadow maps.
- The supplied helmeted Max photograph is used only in the cinematic reveal, with its unverified usage rights disclosed. The following driver section uses the supplied white-suit photograph on the white Red Bull car; it is distinct from the helmeted reveal. Biography and career/2026 totals retain the 26 October 2026 snapshot; the season explorer adds 2015–2026 official standings and 251 race rows verified on 31 October 2026. Results filters genuinely filter the data. Counter animation retains accessible final values and does not restart after being viewed.
- Skip focuses the driver section and releases camera pinning. Motion off and system reduced-motion preferences provide a direct static experience. Failed WebGL/model loading shows the credited static RB22 creator preview and keeps the content/navigation available.

## Honest limits
The current model has its supplied Red Bull livery, cockpit and wheel, but its engineering accuracy is not independently certified. No verified seated Max likeness is supplied; the supplied authentic photographs remain the human reveal, with their rights limitations disclosed. A credited creator preview of this same model replaces the opening on WebGL failure. That still image is not presented as an animated 3D camera journey. The older generic models and their tests remain in source. See docs/ASSET_REGISTER.md for provenance and adaptations.

The cloud browser has WebGL disabled. DOM-only ScrollTrigger and mathematical camera/frustum tests do not prove GPU-rendered visual quality, actual camera smoothness or device performance. See `docs/TEST_LOG.md` and `docs/ANIMATION_CHECKLIST.md` for exact evidence and outstanding device checks.

## Source layout
- `src/max/main.js`: current application lifecycle, motion/skip/loading/fallback controls.
- `src/max/cameraPath.js`: RB22 camera positions, targets, cockpit hold and aspect-aware phone pullback.
- `src/max/animation.js`: scoped GSAP timelines, reveals and counters.
- `src/max/content.js`: Max data selection and semantic content rendering.
- `src/scene/`: retained renderer/loader/lighting plus `dashboard.js`, which attaches a depth-tested text panel to the real LCD mesh.
- `src/data/`: sourced roster/statistics/results and individually tracked portraits; non-Max data retained as archive.
- `src/app/`: preserved reusable multi-driver explorer. `explorer.html` is a secondary archive page, absent from current primary navigation.
- `garage.html`: preserved Phase1 garage study.
- `public/`: local model, artwork, portraits and font.
- `tests/`: retained Phase1/data tests plus Max content/camera/frustum tests.

## Assets and data
Archived Max portrait: Steffen Prößdorf, CC BY-SA4.0, 2024 Dutch Grand Prix. The resized/compressed WebP adaptation retains that licence and archive credits. This licensed podium portrait remains in the secondary archive. The cinematic reveal uses the supplied blue-background helmet photo, and the main driver section uses the supplied white-suit/car photograph. Their original photographer/licences remain unverified and are disclosed in the page credits. See `docs/PORTRAIT_CREDITS.md` and `docs/ASSET_REGISTER.md`. Barlow font is SIL OFL1.1; licence text retained. Third-party dependencies retain package licences.

Data sources, metric meanings and source discrepancies are documented in `docs/DATA_SOURCES.md`. Qualifying positions are unavailable in the fetched result table and omitted. Weekend points include Sprint points. Refresh data manually with `python scripts/refresh-data.py`, review the diff and rerun checks before publication. Never label this snapshot live.

## QA routes
Dev-only harnesses are not part of the production build:
- `/qa/responsive.html`: same-origin iframe viewport checks, not physical-device emulation.
- `/qa/car-review.html`: actual RB22 WebGL four-view review and continuous camera slider; controls remain disabled if rendering fails. `?budget=mobile` selects the phone asset.
- `/qa/asset-review.html?budget=desktop` or `?budget=mobile`: real GLB and texture decoding without a GPU. Explicitly separate from visual rendering checks.
- `/qa/max-motion.html`: actual shared GSAP controller with a DOM-only camera recorder; no GPU/model validation.
- `/qa/scroll.html`: preserved Phase1 ScrollTrigger controller harness.
- `/?static=1`: force static mode.
- `/?reduce=1`: exercise the reduced-motion JS branch; does not change the OS preference.
- `/?test=webgl-error`, `/?test=model-error`, `/?test=portrait-error`: injected failure paths. Model failure is reached only on a WebGL-capable browser.

Read-only `window.__maxExperience.snapshot()` exposes scene status, progress and trigger counts for local diagnostics. No telemetry is implied.

## Deployment
The maintained Sites checkout retains its identity in `.openai/hosting.json`; that provider identity is omitted from the portable source ZIP. Publish the exact checked build. Another static host can serve the complete `dist/` folder without runtime configuration. Anchor navigation supports direct section access. Audience and deployment are separate; see `docs/DEPLOYMENT.md` for the confirmed release state.


## Career photos and cockpit cue
Five owner-supplied images accompany the 2015, 2016, 2021, 2023 and 2024 milestones. They load lazily, preserve their compositions, reveal on scroll and disappear cleanly if loading fails. The earlier car reference images remain in `docs/references/`. The newly supplied RB22 GLB now replaces the generic model in the primary experience. See the asset register for the owner-supplied images’ unverified underlying credits/licences.

“SIMPLY LOVELY.” is now a silent, depth-tested 3D panel parented to `gp21_LCD.003`, sized from the actual display geometry; the floating HTML overlay was removed. During the dashboard approach it fades in at camera progress .58–.64, holds through .68 and fades out by .73. It does not appear during the portrait reveal, static mode or the production WebGL fallback. The pure sequence is deterministic when scrolling backward. The geometry tests verify its parent, dimensions, orientation, occlusion sightline and phone framing. The DOM-only harness validates controller timing; only a WebGL-capable browser can validate the final GPU appearance.


## RB22 optimization
The uploaded `source/untitled.glb` is 37,516,152 bytes with 281,075 triangles, 27 render meshes/primitives, 23 materials and 26 embedded images. `scripts/prepare-rb22.py <uploaded.zip>` reproducibly builds the two local variants (optional build tooling: Python, Pillow, NumPy). Vertex positions, UVs, topology and livery assignments remain intact; normals use normalized byte storage and textures are resized/compressed. Modern WebGL2/WebP-capable browsers need no external runtime decoder.

Desktop: 10,364,640 bytes, up to 2048px maps. Phone: 8,260,012 bytes, up to 1024px maps. At widths ≤900px, reported memory ≤4GB, or Save Data, the phone variant is selected. Estimated decoded RGBA texture payload is 104.5 MiB desktop versus 29.5 MiB phone, before mipmaps/driver overhead. These are calculated budgets, not measured FPS. Resize recalculates framing; 3D uses the visible viewport in portrait and landscape. Model load timeout is 45 seconds, with progress and a static preview while loading.

## October 2026 continuation

The main Max experience now includes the 2015 photo, owner-supplied orange lion, a helmeted portrait, and an On the Record selector for 2015–2026. Select a season to see its team(s), standings, points, GP wins/podiums/poles/starts, cumulative championship stars and expandable race results. Filters apply to the selected season. GP and weekend points are separate; weekend totals include Sprints. 2026 is a dated, incomplete snapshot verified on 31 October 2026. Historical rows and standing evidence are retained in `docs/evidence/seasons/`; optional manual refresh: `python scripts/refresh-max-seasons.py` (review every change before publishing).

The desktop camera keyframes and actual LCD dashboard remain unchanged. Mobile framing backs away along the rear/flank, reserves vertical drawing space for the header/HUD, and retains the existing dashboard hold and final pullback timing. This is not a claim of real-phone GPU or FPS certification; see TEST_LOG.

### Run the extracted ZIP on Windows

Install Node.js 22.12 or newer. Extract the ZIP completely, open a terminal in the folder containing `package.json`, then run:

```powershell
npm.cmd ci
npm.cmd run dev
```

Open the local Vite URL printed by the command. For validation:

```powershell
npm.cmd run check
npm.cmd test
npm.cmd run build
```

`/qa/car-review.html` is available only on the development server; it requires WebGL2 and does not pretend a blocked renderer succeeded. Production builds contain the main experience, driver explorer and garage; development QA routes are intentionally excluded. `npm run build` produces static output in `dist/`. Serve the project through Vite, not by double-clicking `index.html`.

### Put the source on GitHub

1. Create an empty GitHub repository.
2. Extract the source ZIP and upload its contents so `package.json`, `index.html`, `src/`, `public/`, `tests/` and `docs/` are at the repository root. GitHub's web upload supports dragging the extracted folders; do not upload just the ZIP if you want readable source.
3. Keep `.gitignore`. Do not commit `node_modules`, credentials or build caches. The provided archive omits the original site's hosting identity; configure your own host independently.
4. The model files are below GitHub's individual-file limit. Keep asset attribution and rights notes. Do not mark every asset MIT/CC0; licences differ and the owner-supplied photos/logo have unverified redistribution rights.
5. GitHub stores the code; a normal repository URL does not itself serve the Vite website. Use a static host configured for `npm ci`, `npm run build`, output `dist`. GitHub Pages under a repository subpath needs an appropriate Vite base and matching asset paths; the ZIP is immediately runnable at an origin root.

## Achievements and garage review update

The complete achievements chapter now owns a viewport-sticky lion backdrop, clipped to that chapter. Orange glow and sparse sparkle stay behind all five milestones; reduced motion retains a static glow. Michroma supplies radio-inspired UI/milestone lettering and Space Grotesk supplies body text; both are local SIL OFL fonts with their licence texts retained. Michroma is an alternative inspired by the supplied alphabet reference, not an official Formula 1 font.

The main car scene and actual-WebGL car-review route opt into a layered garage wall sign: recessed backing, metal mounting/frame details, blue/red edge lighting and the supplied Oracle Red Bull Racing logo. The sign is actual world geometry with a depth-tested, correctly proportioned logo surface. Logo load failure retains the architecture and does not reject the car scene. The original garage page keeps its prior environment. A static creator preview remains the WebGL fallback and does not claim to depict the updated wall.

The owner accepted the review changes on 31 October 2026 and authorised the final source archive. See README.md for portable setup and upload instructions.
