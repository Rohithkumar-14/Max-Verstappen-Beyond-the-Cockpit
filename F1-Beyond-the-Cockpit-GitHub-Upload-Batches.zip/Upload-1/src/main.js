import { bindExperienceControls } from './ui/experienceControls.js';
import { createScene } from './scene/createScene.js';
import { createCameraJourney } from './scene/cameraJourney.js';
import { loadCar, disposeObject } from './scene/loadCar.js';

const $ = (id) => document.getElementById(id);
const query = new URLSearchParams(location.search);
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
const state = { status: 'loading', scene: null, car: null, mode: reducedMotion.matches ? 'static' : 'motion', progress: 0 };
let generation = 0;
let controller;
let activeJourney = null;
let timeout;
function setStatus(kind, title, detail) {
  state.status = kind; $('loading').dataset.state = kind;
  $('load-title').textContent = title; $('load-detail').textContent = detail;
  $('retry').hidden = kind !== 'error';
}
function showFallback(title, detail) {
  activeJourney?.dispose(); activeJourney = null;
  state.scene?.dispose(); state.scene = null; state.car = null;
  document.body.classList.add('is-fallback', 'is-static');
  $('fallback').hidden = false; $('scene').setAttribute('aria-hidden', 'true');
  $('motion-toggle').disabled = true; $('motion-toggle').textContent = 'Static preview';
  $('motion-toggle').setAttribute('aria-pressed', 'true'); $('scroll-instruction').hidden = true;
  setStatus('error', title, detail); updateProgress(0);
  $('progress-label').textContent = 'STATIC ASSET PREVIEW';
}
function updateProgress(progress) {
  state.progress = progress;
  const percent = Math.round(progress * 100);
  $('scroll-progress').setAttribute('aria-valuenow', String(percent));
  $('progress-fill').style.transform = `scaleX(${progress})`;
  $('progress-text').textContent = `${String(percent).padStart(3, '0')} / 100`;
  $('progress-label').textContent = progress > 0.6 ? 'REAR THREE-QUARTER' : 'REAR VIEW';
}
function updateMode() {
  if (state.status === 'error') {
    updateProgress(0); $('progress-label').textContent = 'STATIC ASSET PREVIEW'; return;
  }
  const isStatic = state.mode === 'static' || reducedMotion.matches || query.has('static');
  document.body.classList.toggle('is-static', isStatic);
  $('motion-toggle').setAttribute('aria-pressed', String(isStatic));
  $('motion-toggle').textContent = isStatic ? 'Resume camera motion' : 'Use static view';
  $('motion-toggle').disabled = reducedMotion.matches || query.has('static');
  $('motion-toggle').title = reducedMotion.matches ? 'Your system reduced-motion preference is respected.' : '';
  activeJourney?.dispose(); activeJourney = null;
  state.scene?.setProgress(isStatic ? 1 : 0); updateProgress(isStatic ? 1 : 0);
  if (state.status === 'ready' && isStatic) setStatus('ready', 'Static garage view', 'Motion is off. Scroll directly to the project notes.');
  if (state.status === 'ready' && !isStatic) {
    setStatus('ready', 'Garage ready', 'Simplified licensed asset · realistic model pending');
    activeJourney = createCameraJourney({
      section: $('experience'), stage: $('stage'),
      onProgress: (progress) => { state.scene?.setProgress(progress); updateProgress(progress); },
    });
  }
}
async function boot() {
  const current = ++generation;
  controller?.abort(); clearTimeout(timeout); activeJourney?.dispose(); activeJourney = null;
  state.scene?.dispose(); state.scene = null; state.car = null;
  controller = new AbortController();
  document.body.classList.remove('is-fallback'); $('fallback').hidden = true; $('scene').removeAttribute('aria-hidden');
  $('scroll-instruction').hidden = false; $('motion-toggle').disabled = false;
  setStatus('loading', 'Preparing the garage', 'Loading the neutral car asset…');
  try {
    state.scene = createScene($('scene'), {
      simulateFailure: query.get('test') === 'webgl-error',
      onContextLost: () => {
        controller.abort(); console.warn('[Garage] WebGL context lost. Static fallback enabled.');
        showFallback('3D graphics interrupted', 'The static preview is available. Retry to restore the scene.');
      },
    });
    timeout = setTimeout(() => controller.abort(new Error('Car loading timed out after 15 seconds.')), 15000);
    const car = await loadCar({ signal: controller.signal, simulateFailure: query.get('test') === 'model-error', onProgress: (loaded, total) => {
      if (current !== generation) return;
      $('load-detail').textContent = total ? `Car asset ${Math.min(100, Math.round(loaded / total * 100))}%` : `Car asset ${Math.round(loaded / 1024)} KB downloaded`;
    } });
    clearTimeout(timeout);
    if (current !== generation) { disposeObject(car); return; }
    state.car = car; state.scene.setCar(car); state.scene.invalidate();
    setStatus('ready', 'Garage ready', 'Simplified licensed asset · realistic model pending'); updateMode();
  } catch (error) {
    if (current !== generation) return;
    clearTimeout(timeout); console.warn('[Garage] Scene unavailable:', error.message);
    showFallback('3D scene unavailable', 'Use the static preview and project notes. You can retry the scene.');
  }
}
const unbindControls = bindExperienceControls({
  media: reducedMotion,
  onRetry: boot,
  onToggle: () => { state.mode = state.mode === 'static' ? 'motion' : 'static'; updateMode(); },
  onSkip: () => {
    state.mode = 'static'; updateMode();
    $('milestone').scrollIntoView({ behavior: 'instant', block: 'start' });
    $('milestone').focus({ preventScroll: true });
  },
  onReplay: () => {
    if (state.status === 'ready' && !reducedMotion.matches && !query.has('static')) { state.mode = 'motion'; updateMode(); }
    window.scrollTo({ top: 0, behavior: 'instant' }); $('skip').focus({ preventScroll: true });
  },
  onPreferenceChange: () => { state.mode = reducedMotion.matches ? 'static' : 'motion'; updateMode(); },
});
if (import.meta.hot) import.meta.hot.dispose(() => {
  unbindControls(); controller?.abort(); clearTimeout(timeout); activeJourney?.dispose(); state.scene?.dispose();
});
window.addEventListener('pageshow', (event) => { if (event.persisted) boot(); });
window.addEventListener('pagehide', () => { controller?.abort(); clearTimeout(timeout); activeJourney?.dispose(); state.scene?.dispose(); });
window.__garage = { snapshot: () => ({ status: state.status, mode: state.mode, progress: state.progress, camera: state.scene?.camera.position.toArray() ?? null, assetQuality: 'placeholder', draws: state.scene?.renderer.info.render.calls ?? null }) };
updateMode(); boot();
