import seasons from '../data/max-seasons.json' with {type:'json'};
export {seasons};
export const getSeason=year=>seasons.find(season=>season.year===Number(year));
export function championshipLabel(season){return `${season.championships} World Championship${season.championships===1?'':'s'} through ${season.year}${season.complete?'':' (snapshot)'}`;}
export function seasonSummary(season){return [['Championship position',season.position],['Championship points',season.points],['Grand Prix wins',season.wins],['Podiums',season.podiums],['Pole positions',season.poles],['Race starts',season.raceStarts]];}
export function seasonOptions(){return [...seasons].reverse().map(s=>`<option value="${s.year}">${s.year}${s.complete?'':' · snapshot'}</option>`).join('');}
